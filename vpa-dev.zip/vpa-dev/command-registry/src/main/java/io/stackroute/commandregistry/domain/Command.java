package io.stackroute.commandregistry.domain;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;
import java.util.UUID;

@Document
public class Command {

    @Id
    private UUID commandId;
    private String command;
    private List<String> params;
    private String description;
    private Object paramBody;

    public Command() {
    }

    public UUID getCommandId() {
        return commandId;
    }

    public void setCommandId(UUID commandId) {
        this.commandId = commandId;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public List<String> getParams() {
        return params;
    }

    public void setParams(List<String> params) {
        this.params = params;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Object getParamBody() {
        return paramBody;
    }

    public void setParamBody(Object paramBody) {
        this.paramBody = paramBody;
    }

    public Command(UUID commandId, String command, List<String> params, String description, Object paramBody) {
        this.commandId = commandId;
        this.command = command;
        this.params = params;
        this.description = description;
        this.paramBody = paramBody;
    }
}
