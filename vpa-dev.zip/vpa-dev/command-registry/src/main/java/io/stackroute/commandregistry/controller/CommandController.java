package io.stackroute.commandregistry.controller;

import io.stackroute.commandregistry.domain.Command;
import io.stackroute.commandregistry.service.CommandService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/command")
public class CommandController {
    @Autowired
    CommandService commandService;


     ResponseEntity responseEntity;

    @PostMapping("/add")
    public ResponseEntity<?> addCommand(@RequestBody Command command){
        commandService.addCommand(command);
        responseEntity= new ResponseEntity<String>("Command Added successfully", HttpStatus.OK);
        return responseEntity;
    }
    @DeleteMapping("/delete")
    public ResponseEntity<?> deleteCommand(@RequestBody String command){
        responseEntity =new ResponseEntity<String>(commandService.deleteCommand(command), HttpStatus.OK);
        return responseEntity;
    }
    @GetMapping("/getall")
    public ResponseEntity<?> getCommand(){
        responseEntity= new ResponseEntity<List<Command>>(commandService.getAllCommands(), HttpStatus.OK);
        return responseEntity;
    }

    @PutMapping("/update/{commandId}")
    public ResponseEntity<?> updateCommand(@RequestBody Command command, @PathVariable UUID commandId){
        responseEntity =new ResponseEntity<Command>(commandService.updateCommand(command, commandId), HttpStatus.OK);
        return responseEntity;
    }

    @PostMapping("/execute")
    public ResponseEntity<?> executeCommand(@RequestBody Command command){
        System.out.println("executing...");
        responseEntity = new ResponseEntity<Object>(commandService.executeCommand(command), HttpStatus.OK);
        System.out.println("executed.");
        return responseEntity;
    }


}
