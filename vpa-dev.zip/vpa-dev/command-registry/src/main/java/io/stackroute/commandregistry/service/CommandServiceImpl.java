package io.stackroute.commandregistry.service;

import com.fasterxml.uuid.Generators;
import io.stackroute.commandregistry.domain.Command;
import io.stackroute.commandregistry.repository.CommandRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.UUID;

@Service
public class CommandServiceImpl implements CommandService{

    @Autowired
    CommandRepository commandRepository;

    @Autowired
    RestTemplate restTemplate;

    @Override
    public List<Command> getAllCommands() {
        return commandRepository.findAll();
    }

    @Override
    public Command addCommand(Command command) {
        command.setCommandId(Generators.timeBasedGenerator().generate());
        commandRepository.save(command);
        return command;
    }

    @Override
    public Command updateCommand(Command command, UUID commandId) {

        Command  command1 = commandRepository.findByCommandId(commandId);
        command1.setCommand(command.getCommand());
        command1.setParams(command.getParams());
        command1.setDescription(command.getDescription());
        return command1;
    }

    @Override
    public String deleteCommand(String command) {
        Command command1 = commandRepository.getCommandByName(command);
        commandRepository.delete(command1);
        return "Deleted";
    }

    @Override
    public Object executeCommand(Command command) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> entity = new HttpEntity<Object>(command.getParamBody(),httpHeaders);
        Object object = restTemplate.exchange(("http://localhost:8086/" + command.getCommand()),HttpMethod.POST, entity, Object.class).getBody();
        System.out.println(object);
        return object;
    }
}
