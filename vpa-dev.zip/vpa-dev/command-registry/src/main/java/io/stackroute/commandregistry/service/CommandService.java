package io.stackroute.commandregistry.service;

import io.stackroute.commandregistry.domain.Command;

import java.util.List;
import java.util.UUID;

public interface CommandService {

    List<Command> getAllCommands();

    Command addCommand(Command command);

    Command updateCommand(Command command, UUID commandId);

    String deleteCommand(String command);


    Object executeCommand(Command command);
}
