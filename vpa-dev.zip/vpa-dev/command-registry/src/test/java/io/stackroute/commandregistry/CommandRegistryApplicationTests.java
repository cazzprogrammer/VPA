package io.stackroute.commandregistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommandRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
