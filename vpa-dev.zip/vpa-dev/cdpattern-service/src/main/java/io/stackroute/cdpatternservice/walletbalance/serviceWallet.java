package io.stackroute.cdpatternservice.walletbalance;

import io.stackroute.cdpatternservice.assetdetails.domainAsset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class serviceWallet {

    @Autowired
    RestTemplate restTemplate;


    public domainWallet getWalletBalance(String username) {
        String WALLET_URL = "http://15.206.48.113:8086/payment/wallet/userId";
//        WALLET_URL = "http://172.23.234.75:8086/payment/wallet/userId";
        HttpHeaders httpHeaders = new HttpHeaders();
//        httpHeaders.setBasicAuth("write access token here");
        httpHeaders.set("userId", username);
        HttpEntity<Object> entity = new HttpEntity<Object>(httpHeaders);
        return restTemplate.exchange(WALLET_URL, HttpMethod.GET, entity, domainWallet.class).getBody();
    }
}
