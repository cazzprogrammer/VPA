package io.stackroute.cdpatternservice.assetdetails;

import java.util.UUID;

public class paramAsset {
    private UUID id;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}
