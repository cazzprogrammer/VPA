package io.stackroute.cdpatternservice.assetdetails;

import io.stackroute.cdpatternservice.invoice.domainInvoice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@Service
public class serviceAsset {

    @Autowired
    RestTemplate restTemplate;

    public domainAsset getAsset(UUID id) {
        String ASSET_URL=""; //write asset url here
        HttpHeaders httpHeaders =new HttpHeaders();
//        httpHeaders.setBasicAuth("write access token here");  //like we did in github
        HttpEntity<String> entity =new HttpEntity<String>(httpHeaders);
        return restTemplate.exchange(ASSET_URL, HttpMethod.GET,entity, domainAsset.class).getBody();
    }

    public List<domainAsset> getAssets() {
        String ASSETS_URL="";
        HttpHeaders httpHeaders = new HttpHeaders();
        //        httpHeaders.setBasicAuth("write access token here");  //like we did in github
        HttpEntity<String> entity =new HttpEntity<String>(httpHeaders);
        domainAsset[] AssetsList = restTemplate.exchange(ASSETS_URL,HttpMethod.GET,entity,domainAsset[].class).getBody();
        return Arrays.asList(AssetsList);
    }
}
