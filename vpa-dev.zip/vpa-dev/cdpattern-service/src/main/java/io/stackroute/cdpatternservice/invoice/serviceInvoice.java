package io.stackroute.cdpatternservice.invoice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;

@Service
public class serviceInvoice {

    @Autowired
    RestTemplate restTemplate;

    public domainInvoice getInvoice(String username) {
        String INVOICE_URL = "http://15.206.48.113:8086/payment/transaction/user";
//        INVOICE_URL = "http://172.23.234.75:8086/payment/transaction/user";
        HttpHeaders httpHeaders = new HttpHeaders();
        System.out.println(username);
//        httpHeaders.set/BasicAuth("write access token here");  //like we did in github
        httpHeaders.set("userID", username);
        HttpEntity<String> entity = new HttpEntity<String>(httpHeaders);
        domainInvoice[] invoices = restTemplate.exchange(INVOICE_URL, HttpMethod.GET, entity, domainInvoice[].class).getBody();
//        System.out.println(InvoiceList);
//        do invoiceList = Arrays.asList(invoices);
        assert invoices != null;
        return invoices[invoices.length - 1];
//        for (int i = 0; i < invoiceList.size(); i++) {
//            System.out.println(invoiceList.get(i));
//        }
//        return null;
//        return invoiceList.get(0);  //change output data type of getInvoices() method to domainInvoice, if you are sending only one invoice.
//        return Arrays.asList(InvoiceList);


    }
}
