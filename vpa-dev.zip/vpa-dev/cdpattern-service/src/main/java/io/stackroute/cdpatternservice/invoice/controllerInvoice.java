package io.stackroute.cdpatternservice.invoice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/cmd")
public class controllerInvoice {

    @Autowired
    serviceInvoice invoice;

    ResponseEntity responseEntity;

    @PostMapping("/invoice")
    public ResponseEntity<?> getUserInvoice(@RequestBody paramInvoice paramInvoiceName) {
//        System.out.println(paramInvoiceName);
        responseEntity=new ResponseEntity<domainInvoice>(invoice.getInvoice(paramInvoiceName.getUserId()), HttpStatus.OK);
        return responseEntity;
    }
}
