package io.stackroute.cdpatternservice.assetdetails;

import java.util.UUID;

public class domainAsset {
    private String name;
    private String assetKey;
    //write properties of asset corresponding to uuid

}
