package io.stackroute.cdpatternservice.github;

public class paramGithub {
   public String username="thakurtejveer";

//    public String getUsername() {
//        return username;
//    }
//
//    public void setUsername(String username) {
//        this.username = "thakurtejveer";
//    }
}
