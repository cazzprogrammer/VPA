package io.stackroute.cdpatternservice.neareststation;

public class domainStation {
    private String stationName;
    private String stationLocation;
}
