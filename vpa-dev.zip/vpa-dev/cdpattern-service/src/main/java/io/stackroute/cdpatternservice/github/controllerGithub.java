package io.stackroute.cdpatternservice.github;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value="/github")
public class controllerGithub {

    @Autowired
    serviceGithub githubinfo;

    ResponseEntity responseEntity;

    paramGithub paramGithubName=new paramGithub();

    @PostMapping("/user")
    public ResponseEntity<?> getUserInfo() {
//        System.out.println(paramGithubName.username);
        responseEntity = new ResponseEntity<domainGithub>(githubinfo.getUserInfo(paramGithubName.username), HttpStatus.OK);
        return responseEntity;
    }
}
