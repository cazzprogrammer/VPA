package io.stackroute.cdpatternservice.walletbalance;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class domainWallet {
    private String userID;
    private Integer balance;
}
