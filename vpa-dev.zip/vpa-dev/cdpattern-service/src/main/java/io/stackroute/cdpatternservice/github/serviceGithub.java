package io.stackroute.cdpatternservice.github;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class serviceGithub {

    @Autowired
    RestTemplate restTemplate;

    public domainGithub getUserInfo(String username) {
//        System.out.println(username);
        String GITHUB_URL="https://api.github.com/users/"+username;
        HttpHeaders httpHeaders=new HttpHeaders();
        System.out.println(GITHUB_URL);
//        httpHeaders.setBasicAuth("write auth token here");

        HttpEntity<String> entity =new HttpEntity<String>(httpHeaders);
//        System.out.println(restTemplate.exchange(GITHUB_URL, HttpMethod.GET,entity,domainGithub.class).getBody());
        return restTemplate.exchange(GITHUB_URL, HttpMethod.GET,entity,domainGithub.class).getBody();
    }
}
