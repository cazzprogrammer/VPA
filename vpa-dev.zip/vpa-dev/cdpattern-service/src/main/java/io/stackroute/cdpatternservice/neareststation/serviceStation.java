package io.stackroute.cdpatternservice.neareststation;

import io.stackroute.cdpatternservice.invoice.domainInvoice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;

@Service
public class serviceStation {

    @Autowired
    RestTemplate restTemplate;
    public List<domainStation> getStations(String username, String userLocation) {
        String STATION_URL="";   //write invoice url here.. as of now for Yulu only
        HttpHeaders httpHeaders =new HttpHeaders();
//        httpHeaders.setBasicAuth("write access token here");  //like we did in github, if required
        HttpEntity<String> entity =new HttpEntity<String>(httpHeaders);
        domainStation[] StationList =  restTemplate.exchange(STATION_URL, HttpMethod.GET,entity,domainStation[].class).getBody();
        return Arrays.asList(StationList);
    }
}
