package io.stackroute.cdpatternservice.github;

public class domainGithub {
    private String login;
    int id;

    public domainGithub(String login, int id) {
        this.login = login;
        this.id = id;
    }

    @Override
    public String toString() {
        return "domainGithub{" +
                "login='" + login + '\'' +
                ", id=" + id +
                '}';
    }

    public domainGithub() {
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
