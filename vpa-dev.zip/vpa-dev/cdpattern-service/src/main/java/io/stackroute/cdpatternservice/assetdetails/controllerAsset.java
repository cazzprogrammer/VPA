package io.stackroute.cdpatternservice.assetdetails;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value="/#")
public class controllerAsset {

    @Autowired
    serviceAsset asset;

    ResponseEntity responseEntity;

    @PostMapping("/asset")
    public ResponseEntity<?> getAssets (@RequestBody paramAsset paramAssetName) {
        return responseEntity=new ResponseEntity<domainAsset>(asset.getAsset(paramAssetName.getId()), HttpStatus.OK);
    }
    @PostMapping("/assets")
    public ResponseEntity<?> getAssets (  ) {
        return responseEntity = new ResponseEntity<List<domainAsset>>(asset.getAssets(),HttpStatus.OK);
    }
}
