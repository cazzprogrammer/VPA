package io.stackroute.cdpatternservice.neareststation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/#")
public class controllerStation {

    @Autowired
    serviceStation station;

    ResponseEntity responseEntity;

    @PostMapping("/stations")
    public ResponseEntity<domainStation> getStations (@RequestBody paramStation paramStationName) {
        responseEntity =new ResponseEntity<List<domainStation>>(station.getStations(paramStationName.getUsername(), paramStationName.getUserLocation()), HttpStatus.OK);
        return responseEntity;
    }
}
