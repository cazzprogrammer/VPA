package io.stackroute.ticketservice.service;

import io.stackroute.ticketservice.exception.TicketNotFoundException;
import io.stackroute.ticketservice.model.Ticket;
import org.springframework.data.domain.Page;

import java.util.List;
import java.util.UUID;

public interface TicketService {


    List<Ticket> getAllTickets(Integer pageLimit, Integer pageNum) throws TicketNotFoundException;

    Ticket getTicketByID(UUID ID) throws TicketNotFoundException;

    Ticket addTicket(Ticket ticket);

    Ticket updateTicket(Ticket ticket) throws TicketNotFoundException;

    List<Ticket> getUnresolved() throws TicketNotFoundException;

    List<Ticket> getResolvedByBOT() throws TicketNotFoundException;

    List<Ticket> getResolvedByCSR() throws TicketNotFoundException;

    List<Ticket> getReviewedByDEV() throws TicketNotFoundException;

    List<Ticket> getToBeReviewed() throws TicketNotFoundException;

    String deleteTicket(Ticket ticket) throws TicketNotFoundException;

    String deleteTicketByID(UUID id) throws TicketNotFoundException;
}
