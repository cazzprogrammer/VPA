package io.stackroute.ticketservice.service;

import io.stackroute.ticketservice.exception.TicketNotFoundException;
import io.stackroute.ticketservice.model.Ticket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class Consumer {

    private Producer producer;
    private TicketService ticketService;
    private final Logger logger = LoggerFactory.getLogger(Consumer.class);

    @Autowired
    public Consumer(Producer producer, TicketService ticketService) {
        this.producer = producer;
        this.ticketService = ticketService;
    }

    @KafkaListener(topics = "generated-ticket", groupId = "group_id11")
    public void consume(Ticket message) {
        logger.info(String.format("#### -> Consumed message -> %s", message));
        Ticket ticket = ticketService.addTicket(message);
        if( ticket.getStatus() == Ticket.status.UNRESOLVED ){
            producer.sendMessageToCSR(ticket);
        }
//        else{
            producer.sendMessageToReport(ticket);
//        }
        System.out.println("----------------- RECEIVED FROM BOT -----------------");
    }

    @KafkaListener(topics = "resolved-ticket", groupId = "group_id11")
    public void consume1(Ticket message) throws IOException, TicketNotFoundException {
        logger.info(String.format("#### -> Consumed message -> %s", message));
        Ticket ticket = ticketService.getTicketByID(message.getID());
        ticket.setStatus(message.getStatus());
        ticket.setResolvedBy(message.getResolvedBy());
        ticket.setResolvedOn(message.getResolvedOn());
        ticket.setLastUpdateBy(message.getLastUpdateBy());
        ticket.setLastUpdateOn(message.getLastUpdateOn());
        ticket.setInteractions(message.getInteractions());
        ticket = ticketService.updateTicket(ticket);
        producer.sendMessageToReport(ticket);
        System.out.println("------------ RECEIVED FROM CSR ---------------------");
    }
}
