package io.stackroute.ticketservice.service;

import io.stackroute.ticketservice.model.Ticket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class Producer {

    private static final Logger logger = LoggerFactory.getLogger(Producer.class);
    private static final String TOPIC = "unresolved-ticket";
    private static final String TOPIC01 = "ticket-reports";

    @Autowired
    private KafkaTemplate<String, Ticket> kafkaTemplate;
    private KafkaTemplate<String, Ticket> kafkaTemplate1;
    public void sendMessageToCSR(Ticket message) {
        logger.info(String.format("#### -> Producing message to CSR-> %s", message));
        this.kafkaTemplate.send(TOPIC, message);
    }

    public void sendMessageToReport(Ticket message) {
        this.kafkaTemplate.send(TOPIC01, message);
        logger.info(String.format("#### -> Producing message to REPORT-> %s", message));
    }
}