package io.stackroute.ticketservice.repository;

import com.mongodb.client.MongoClient;
import io.stackroute.ticketservice.model.Ticket;

import org.springframework.boot.convert.Delimiter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface TicketRepository extends MongoRepository<Ticket, UUID> {

//    @Aggregation("{$limit:?0},{$skip:?1}")
//    List<Ticket> findAll(Integer pageLimit, Integer pageNum);

//    Page<Ticket> findAll(Pageable pageable);

    Ticket findByID(UUID ID);

    List<Ticket> findByStatus(Ticket.status status);

    @Query("{ resolvedBy: BOT }")
    List<Ticket> getResolvedByBOT();

    @Query("{ resolvedBy: CSR }")
    List<Ticket> getResolvedByCSR();

    @Query("{ lastUpdateBy: CSR }")
    List<Ticket> getToBeReviewed();

    @Query("{ 'interactions.with': DEV }")
    List<Ticket> getReviewedByDEV();

    void deleteByID(UUID ID);
}
