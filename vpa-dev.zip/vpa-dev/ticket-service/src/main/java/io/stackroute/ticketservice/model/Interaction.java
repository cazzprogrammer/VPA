package io.stackroute.ticketservice.model;

import java.time.LocalDateTime;

public class Interaction {

    public Interaction() {
    }

    private with with;

    public enum with {
        BOT,
        CSR,
        DEV,
        ADMIN
    }

    private String username;
    private String summary;
    private LocalDateTime catchTime;
    private LocalDateTime releaseTime;

    public Interaction.with getWith() {
        return with;
    }

    public void setWith(Interaction.with with) {
        this.with = with;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public LocalDateTime getCatchTime() {
        return catchTime;
    }

    public void setCatchTime(LocalDateTime catchTime) {
        this.catchTime = catchTime;
    }

    public LocalDateTime getReleaseTime() {
        return releaseTime;
    }

    public void setReleaseTime(LocalDateTime releaseTime) {
        this.releaseTime = releaseTime;
    }

}
