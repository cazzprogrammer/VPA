package io.stackroute.ticketservice.controller;

import io.stackroute.ticketservice.exception.TicketNotFoundException;
import io.stackroute.ticketservice.model.Ticket;
import io.stackroute.ticketservice.service.Consumer;
import io.stackroute.ticketservice.service.TicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/tickets")
public class TicketController {

    @Autowired
    TicketService ticketService;

    ResponseEntity responseEntity;

    // Get all tickets
    @GetMapping("/all")
    public ResponseEntity<?> getAllTickets(@RequestParam(required = false) Integer pageLimit, @RequestParam(required = false) Integer pageNum) throws TicketNotFoundException {
        responseEntity = new ResponseEntity<List<Ticket>>(ticketService.getAllTickets(pageLimit, pageNum), HttpStatus.OK);
        return responseEntity;
    }

    // Get tickets without bot
    @Autowired
    Consumer consumer;

    @PostMapping("/automode")
    public void autoTicket(@RequestBody Ticket ticket){
        consumer.consume(ticket);
    }

    // Get all unresolved tickets
    @GetMapping("/unresolved")
    public ResponseEntity<?> getUnresolvedTickets() throws TicketNotFoundException {
        responseEntity = new ResponseEntity<List<Ticket>>(ticketService.getUnresolved(), HttpStatus.OK);
        return responseEntity;
    }

    // Get all tickets resolved by bot
    @GetMapping("/byBOT")
    public ResponseEntity<?> getResolvedByBOT() throws TicketNotFoundException {
        responseEntity = new ResponseEntity<List<Ticket>>(ticketService.getResolvedByBOT(), HttpStatus.OK);
        return responseEntity;
    }

    // Get all tickets resolved by CSR
    @GetMapping("/byCSR")
    public ResponseEntity<?> getResolvedByCSR() throws TicketNotFoundException {
        responseEntity = new ResponseEntity<List<Ticket>>(ticketService.getResolvedByCSR(), HttpStatus.OK);
        return responseEntity;
    }

    // Get all tickets reviewed by DEV
    @GetMapping("/byDEV")
    public ResponseEntity<?> getResolvedByDEV() throws TicketNotFoundException {
        responseEntity = new ResponseEntity<List<Ticket>>(ticketService.getReviewedByDEV(), HttpStatus.OK);
        return responseEntity;
    }

    // Get tickets yet to be reviewed (by DEV or ADMIN)
    @GetMapping("/review")
    public ResponseEntity<?> getToBeReviewed() throws TicketNotFoundException {
        responseEntity = new ResponseEntity<List<Ticket>>(ticketService.getToBeReviewed(), HttpStatus.OK);
        return responseEntity;
    }

    // Get a ticket by ID
    @GetMapping("/id/{ID}")
    public ResponseEntity<?> getTicketById(@PathVariable UUID ID) throws TicketNotFoundException {
        responseEntity = new ResponseEntity<Ticket>(ticketService.getTicketByID(ID), HttpStatus.OK);
        return responseEntity;
    }

    // Add a new ticket
    @PostMapping("/add")
    public ResponseEntity<?> addTicket(@RequestBody Ticket ticket) {
        responseEntity = new ResponseEntity<Ticket>(ticketService.addTicket(ticket), HttpStatus.OK);
        return responseEntity;
    }

    // Update an existing ticket
    @PutMapping("/update")
    public ResponseEntity<?> updateTicket(@RequestBody Ticket ticket) throws TicketNotFoundException {
        responseEntity = new ResponseEntity<Ticket>(ticketService.updateTicket(ticket), HttpStatus.OK);
        return responseEntity;
    }

    // Delete an existing ticket
    @DeleteMapping("/delete")
    public ResponseEntity<?> deleteTicket(@RequestBody Ticket ticket) throws TicketNotFoundException {
        responseEntity = new ResponseEntity<String>(ticketService.deleteTicket(ticket), HttpStatus.OK);
        return responseEntity;
    }

    // Delete an existing ticket
    @DeleteMapping("/delete/id/{ID}")
    public ResponseEntity<?> deleteTicketByID(@PathVariable UUID ID) throws TicketNotFoundException {
        responseEntity = new ResponseEntity<String>(ticketService.deleteTicketByID(ID), HttpStatus.OK);
        return responseEntity;
    }

}
