package io.stackroute.reportservice.model;

import java.time.LocalDateTime;
import java.util.Date;

public class Interaction {
    public Interaction() {
    }

    public Interaction(Interaction.with with, String username, String summary, Date catchTime, Date releaseTime) {
        this.with = with;
        this.username = username;
        this.summary = summary;
        this.catchTime = catchTime;
        this.releaseTime = releaseTime;
    }

    public Interaction(Interaction.with with) {
        this.with = with;
    }

    private with with;

    public enum with {
        BOT,
        CSR,
        DEV,
        ADMIN
    }

    private String username;
    private String summary;
    private Date catchTime;
    private Date releaseTime;

    public Interaction.with getWith() {
        return with;
    }

    public void setWith(Interaction.with with) {
        this.with = with;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public Date getCatchTime() {
        return catchTime;
    }

    public void setCatchTime(Date catchTime) {
        this.catchTime = catchTime;
    }

    public Date getReleaseTime() {
        return releaseTime;
    }

    public void setReleaseTime(Date releaseTime) {
        this.releaseTime = releaseTime;
    }

//    BOT
//    BOT
//    answer
//    dateTime

//    CSR
//    csr id
//    answer
//    catchTime
//    releaseTime

//    DEV
//    dev id
//    reviewed
//    dataTime

//    ADMIN
//    admin id
//    reviewed
//    dataTime


}
