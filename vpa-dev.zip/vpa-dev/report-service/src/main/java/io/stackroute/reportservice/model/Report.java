package io.stackroute.reportservice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Document
@Data
public class Report {

    @Id
    private UUID reportID;

    private UUID ticketID;            // ticketId

    private String query;       // the query the user asks

    private String intent;      // the intent inferred by bot

    private String raisedBy;    // the user who asked the query
    private Date createdOn;    // when was this ticket created


    private List<Interaction> interactions; // log of interactions with the ticket (csr/admin/dev)


    private type type;  // type of query asked by user

    public enum type {
        QUERY,
        TASK
    }

    private String feedback;

    private int rating;

    private String commandUsed;

    private status status;  // is the ticket resolved or not

    public enum status {
        RESOLVED,
        UNRESOLVED
    }

    private lastUpdateBy lastUpdateBy;  // who made the last update to the ticket

    public enum lastUpdateBy {
        BOT,
        CSR,
        DEV,
        ADMIN
    }

    private Date lastUpdateOn; // when was the ticket last updated

    private resolvedBy resolvedBy; // who resolved the ticket

    public enum resolvedBy {
        BOT,
        CSR,
        DEV,
        ADMIN
    }

    private Date resolvedOn;   // when was the ticket resolved

    public UUID getReportID() {
        return reportID;
    }

    public void setReportID(UUID reportID) {
        this.reportID = reportID;
    }

    public UUID getTicketID() {
        return ticketID;
    }

    public void setTicketID(UUID ticketID) {
        this.ticketID = ticketID;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String getIntent() {
        return intent;
    }

    public void setIntent(String intent) {
        this.intent = intent;
    }

    public String getRaisedBy() {
        return raisedBy;
    }

    public void setRaisedBy(String raisedBy) {
        this.raisedBy = raisedBy;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public List<Interaction> getInteractions() {
        return interactions;
    }

    public void setInteractions(List<Interaction> interactions) {
        this.interactions = interactions;
    }

    public Report.type getType() {
        return type;
    }

    public void setType(Report.type type) {
        this.type = type;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getCommandUsed() {
        return commandUsed;
    }

    public void setCommandUsed(String commandUsed) {
        this.commandUsed = commandUsed;
    }

    public Report.status getStatus() {
        return status;
    }

    public void setStatus(Report.status status) {
        this.status = status;
    }

    public Report.lastUpdateBy getLastUpdateBy() {
        return lastUpdateBy;
    }

    public void setLastUpdateBy(Report.lastUpdateBy lastUpdateBy) {
        this.lastUpdateBy = lastUpdateBy;
    }

    public Date getLastUpdateOn() {
        return lastUpdateOn;
    }

    public void setLastUpdateOn(Date lastUpdateOn) {
        this.lastUpdateOn = lastUpdateOn;
    }

    public Report.resolvedBy getResolvedBy() {
        return resolvedBy;
    }

    public void setResolvedBy(Report.resolvedBy resolvedBy) {
        this.resolvedBy = resolvedBy;
    }

    public Date getResolvedOn() {
        return resolvedOn;
    }

    public void setResolvedOn(Date resolvedOn) {
        this.resolvedOn = resolvedOn;
    }
}

