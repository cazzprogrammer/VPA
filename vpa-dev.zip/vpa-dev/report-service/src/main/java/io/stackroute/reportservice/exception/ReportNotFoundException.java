package io.stackroute.reportservice.exception;

public class ReportNotFoundException extends Exception {

    private String message;

    public ReportNotFoundException(String message) {
        super(message);
        this.message=message;
    }
}
