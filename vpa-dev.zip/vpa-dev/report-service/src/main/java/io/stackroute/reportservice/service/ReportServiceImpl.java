package io.stackroute.reportservice.service;

import com.fasterxml.uuid.Generators;
import io.stackroute.reportservice.exception.ReportNotFoundException;
import io.stackroute.reportservice.model.Interaction;
import io.stackroute.reportservice.model.Report;
import io.stackroute.reportservice.model.Ticket;
import io.stackroute.reportservice.repository.ReportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class ReportServiceImpl implements ReportService {

    @Autowired
    ReportRepository reportRepository;

    // Get all reports

    public List<Report> getAllReports() throws ReportNotFoundException {
        List<Report> allReports = reportRepository.findAll();
        if (allReports.size() == 0) {
            throw new ReportNotFoundException("No Reports available!");
        }
        return allReports;
    }

    // Get all resolved Reports

    public List<Report> getResolved() throws ReportNotFoundException {
        List<Report> resolvedReports = reportRepository.findByStatus(Report.status.RESOLVED);
        if (resolvedReports.size() == 0) {
            throw new ReportNotFoundException("No resolved reports available!");
        }
        return resolvedReports;
    }

    // Get all Reports resolved by bot

    public List<Report> getResolvedByBOT() throws ReportNotFoundException {
        List<Report> resolvedByBOT = reportRepository.getResolvedByBOT();
        if (resolvedByBOT.size() == 0) {
            throw new ReportNotFoundException("No Reports available!");
        }
        return resolvedByBOT;
    }

    // Get all Reports resolved by CSR

    public List<Report> getResolvedByCSR() throws ReportNotFoundException {
        List<Report> resolvedByCSR = reportRepository.getResolvedByCSR();
        if (resolvedByCSR.size() == 0) {
            throw new ReportNotFoundException("No Reports available!");
        }
        return resolvedByCSR;
    }


    // Get num of reports resolved by a particular CSR

    public List<Report> getResolvedByCSR_ID(String employeeID) {
        List<Report> resolvedByCSR_ID = reportRepository.getResolvedByCSR_ID(employeeID);
        return resolvedByCSR_ID;
    }

    // Get all Reports reviewed by DEV

    public List<Report> getReviewedByDEV() throws ReportNotFoundException {
        List<Report> reviewedByDEV = reportRepository.getReviewedByDEV();
        if (reviewedByDEV.size() == 0) {
            throw new ReportNotFoundException("No Reports available!");
        }
        return reviewedByDEV;
    }

//    Get Reports yet to be reviewed (by DEV or ADMIN)

//    public List<Report> getToBeReviewed() throws ReportNotFoundException {
//        List<Report> toBeReviewed = reportRepository.getToBeReviewed();
//        if (toBeReviewed.size() == 0) {
//            throw new ReportNotFoundException("No Reports available!");
//        }
//        return toBeReviewed;
//    }

//    Get a Report by ID

    public Report getReportById(UUID ID) throws ReportNotFoundException {
        Report Report = reportRepository.findByReportID(ID);
        if (Report == null) {
            throw new ReportNotFoundException("Report not found!");
        }
        return Report;
    }

    // Get count of reports solved by CSR in array format
//    
//    public int[] getCountPerHourByCsr() {
//        List<Report> report = reportRepository.findByTicketResolvedOn(LocalDate.now());
//        int[] countCSR=new int[24];
//        if(report.size() != 0) {
//            for(Report temp:report) {
//                if(temp.getResolvedBy() == Report.resolvedBy.CSR)
//                    countCSR[Instant.ofEpochMilli(temp.getResolvedOn().getTime())
//                            .atZone(ZoneId.systemDefault())
//                            .toLocalDateTime().getHour()]++;
//            }
//        }
//        return countCSR;
//    }

//    // Get count of reports solved by bot in array format
//    
//    public int[] getCountPerHourByBot() {
//        List<Report> report = reportRepository.findByTicketResolvedOn(LocalDate.now());
//        int[] countBOT=new int[24];
//        if(report.size() != 0) {
//            for(Report temp:report) {
//                if(temp.getResolvedBy() == Report.resolvedBy.BOT)
//                    countBOT[Instant.ofEpochMilli(temp.getResolvedOn().getTime())
//                            .atZone(ZoneId.systemDefault())
//                            .toLocalDateTime().getHour()]++;
//            }
//        }
//        return countBOT;
//    }

    // Add a new Report
    public Report addReport(Ticket ticket) {
        Report report = new Report();
        report.setTicketID(ticket.getID());
        report.setResolvedOn(Date.from(ticket.getResolvedOn().atZone(ZoneId.systemDefault()).toInstant()));
        report.setReportID(Generators.timeBasedGenerator().generate());
        report.setQuery(ticket.getQuery());
        report.setIntent(ticket.getIntent());
        report.setRaisedBy(ticket.getRaisedBy());
        report.setCreatedOn(Date.from(ticket.getCreatedOn().atZone(ZoneId.systemDefault()).toInstant()));
        report.setInteractions(ticket.getInteractions());

        if (ticket.getType().equals(Ticket.type.QUERY)) ;
        {
            report.setType(Report.type.QUERY);
        }
        if (ticket.getStatus() == Ticket.status.RESOLVED) {
            report.setStatus(Report.status.RESOLVED);
        } else {
            report.setStatus(Report.status.UNRESOLVED);
        }

        if (ticket.getLastUpdateBy() == Ticket.lastUpdateBy.BOT) {
            report.setLastUpdateBy(Report.lastUpdateBy.BOT);
        } else if (ticket.getLastUpdateBy() == Ticket.lastUpdateBy.CSR) {
            report.setLastUpdateBy(Report.lastUpdateBy.CSR);
        } else if (ticket.getLastUpdateBy() == Ticket.lastUpdateBy.ADMIN) {
            report.setLastUpdateBy(Report.lastUpdateBy.ADMIN);
        } else {
            report.setLastUpdateBy(Report.lastUpdateBy.DEV);
        }
        report.setLastUpdateOn(Date.from(ticket.getLastUpdateOn().atZone(ZoneId.systemDefault()).toInstant()));

        if (ticket.getResolvedBy() == Ticket.resolvedBy.BOT) {
            report.setResolvedBy(Report.resolvedBy.BOT);

        } else {
            report.setResolvedBy(Report.resolvedBy.CSR);
        }

        report.setResolvedOn(Date.from(ticket.getResolvedOn().atZone(ZoneId.systemDefault()).toInstant()));

        reportRepository.save(report);
        return report;
    }

    // Update an existing Report



    public List<Report> listOfReports(Date from, Date to) {
        List<Report> reports = reportRepository.getReportsBetween(from, to);
        return reports;
    }


    public List<Report> listOfReportsResolvedByCsr(Date from, Date to) {

        List<Report> list = reportRepository.getResolvedByCSRTimeFrame(from, to);
        return list;
    }


    public List<Report> listOfReportsResolvedByACsr(String username, Date from, Date to) {
        List<Report> list = reportRepository.getReportsBetween(from, to);
        List<Report> list1 = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getInteractions().size() >= 2) {
                if (list.get(i).getInteractions().get(1).getUsername().compareTo(username) == 0) {
                    list1.add(list.get(i));
                }
            }
        }

        return list1;
    }

    String getAlphaNumericString(int n) {

        // chose a Character random from this String
        String AlphaNumericString = "AB CDE FGHIJ KLMNOP QRSTUV WXYZ" + "0123456789" + "abcdef ghijkl mnopq r stuv xyz";

        // create StringBuffer size of AlphaNumericString
        StringBuilder sb = new StringBuilder(n);

        for (int i = 0; i < n; i++) {

            int index = (int) (AlphaNumericString.length() * Math.random());

            // add Character one by one in end of sb
            sb.append(AlphaNumericString.charAt(index));
        }

        return sb.toString();
    }

    public Date getRandomDateBetween(Date startDate, Date endDate) {
       return new Date(ThreadLocalRandom.current().nextLong(startDate.getTime(), endDate.getTime()));
    }



    public List<Report> addRandomReports(Integer number) {
        int i;
//        UUID csrIds[] = new UUID[10];
//        for (i = 0; i < 10; i++) {
//            csrIds[i] = Generators.timeBasedGenerator().generate();
//        }

        String[] csrIds = {"ela", "charles"};
        Random random = new Random();
        List<Report> reports = new ArrayList<>();
        for (int j = 0; j < number; j++) {

            Report report = new Report();
            Random rand = new Random();
            report.setTicketID(Generators.timeBasedGenerator().generate());
            report.setReportID(Generators.timeBasedGenerator().generate());
            report.setQuery(getAlphaNumericString(100));

            report.setIntent(getAlphaNumericString(10));
            report.setRaisedBy(getAlphaNumericString(10));

            Date endDate = new Date();
            Date startDate = new Date();
            startDate.setMonth(endDate.getMonth() - 6);
            report.setCreatedOn(getRandomDateBetween(startDate, endDate));
            System.out.println("created On" + report.getCreatedOn());

            Date resolvedCSRDate = new Date();
            resolvedCSRDate.setHours(report.getCreatedOn().getHours() + 6);
            resolvedCSRDate.setDate(report.getCreatedOn().getDate());
            resolvedCSRDate.setMonth(report.getCreatedOn().getMonth());


            if (rand.nextDouble() > 0.2) {
                report.setStatus(Report.status.RESOLVED);
            } else {
                report.setStatus(Report.status.UNRESOLVED);
            }

            if (report.getStatus() == Report.status.RESOLVED) {

                if (rand.nextDouble() > 0.3) {
                    report.setResolvedBy(Report.resolvedBy.BOT);
                } else {
                    report.setResolvedBy(Report.resolvedBy.CSR);
                }
            }
            List<Interaction> interactions = new ArrayList<>();


            if (report.getResolvedBy() == Report.resolvedBy.BOT) {
                interactions.add(new Interaction(Interaction.with.BOT));
                report.setResolvedOn(report.getCreatedOn());
                report.setLastUpdateOn(report.getResolvedOn());
                report.setLastUpdateBy(Report.lastUpdateBy.BOT);
                report.setInteractions(interactions);
            } else if (report.getResolvedBy() == Report.resolvedBy.CSR || report.getResolvedBy() == null) {
                interactions.add(new Interaction(Interaction.with.BOT));
                report.setLastUpdateOn(getRandomDateBetween(report.getCreatedOn(), resolvedCSRDate));
                interactions.add(new Interaction(Interaction.with.CSR, csrIds[random.nextInt(csrIds.length)], getAlphaNumericString(100), getRandomDateBetween(report.getCreatedOn(), report.getLastUpdateOn()), report.getLastUpdateOn()));
                if(report.getResolvedBy() == Report.resolvedBy.CSR) {
                    report.setResolvedOn(report.getLastUpdateOn());
                }
                report.setLastUpdateBy(Report.lastUpdateBy.CSR);
                report.setInteractions(interactions);
            }

            report.setType(Report.type.QUERY);
//            report.setType(Report.type.TASK);
            reportRepository.save(report);
            reports.add(report);
//
        }
        return reports;
    }
}