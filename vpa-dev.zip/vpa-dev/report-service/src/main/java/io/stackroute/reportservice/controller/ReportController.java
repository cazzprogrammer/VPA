package io.stackroute.reportservice.controller;

import io.stackroute.reportservice.exception.ReportNotFoundException;
import io.stackroute.reportservice.model.Report;
import io.stackroute.reportservice.model.Ticket;
import io.stackroute.reportservice.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@Controller
@RestController
@CrossOrigin(value = "*")
@RequestMapping(value = "/reports")
public class ReportController {
    ResponseEntity responseEntity;

    @Autowired
    ReportService reportService;


    @GetMapping("/getRandomData")
        List<Report> addRandomReports(@RequestParam(required = false) Integer number){
        if(number == null){
            number = 1;
        }
//        return new ResponseEntity<List<Report>>(reportService.addRandomReports(number), HttpStatus.OK);
    return reportService.addRandomReports(number);
    }


    @PostMapping(value = "/add")
    ResponseEntity<?> addReport(@RequestBody Ticket ticket) throws ReportNotFoundException {
        responseEntity = new ResponseEntity<Report>(reportService.addReport(ticket), HttpStatus.OK);
        return responseEntity;
    }

    @GetMapping(value = "/all")
    ResponseEntity<?> getAllReports() throws ReportNotFoundException {
        responseEntity = new ResponseEntity<List<Report>>(reportService.getAllReports(), HttpStatus.OK);
        return responseEntity;
    }

    // get list of reports by a specific csr
    @GetMapping("/getReportsByCsrId/{empID}")
    public ResponseEntity<?> getReportByCsrId(@PathVariable String empID) throws ReportNotFoundException {
        responseEntity = new ResponseEntity<List<Report>>(reportService.getResolvedByCSR_ID(empID), HttpStatus.OK);
        return responseEntity;
    }


    // get list of reports resolved by csr between specific date
    @GetMapping("/getCsrReports")
    public List<Report> getReportsBetween(@RequestParam String fromDate, @RequestParam String toDate) {
        Date _toDate = new Date(Long.parseLong(toDate));
        Date _fromDate = new Date(Long.parseLong(fromDate));
        return reportService.listOfReportsResolvedByCsr(_fromDate, _toDate);
    }

    // get list of all reports resolved by either bot or csr resolved
    @GetMapping("/getAllReports")
    public  List<Report> getAllReportsBetween(@RequestParam String fromDate, @RequestParam String toDate){
        Date _toDate = new Date(Long.parseLong(toDate));
        Date _fromDate = new Date(Long.parseLong(fromDate));
        return reportService.listOfReports(_fromDate, _toDate);
    }
}
