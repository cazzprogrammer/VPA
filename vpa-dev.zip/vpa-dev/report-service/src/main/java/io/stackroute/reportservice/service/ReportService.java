package io.stackroute.reportservice.service;

import io.stackroute.reportservice.exception.ReportNotFoundException;
import io.stackroute.reportservice.model.Report;
import io.stackroute.reportservice.model.Ticket;

import java.util.Date;
import java.util.List;
import java.util.UUID;

public interface ReportService {

    List<Report> getAllReports() throws ReportNotFoundException;

    Report getReportById(UUID ID) throws ReportNotFoundException;


    Report addReport(Ticket Report);

//    Report updateReport(Report Report) throws ReportNotFoundException;

    List<Report> getResolved() throws ReportNotFoundException;

    List<Report> getResolvedByBOT() throws ReportNotFoundException;

    List<Report> getResolvedByCSR() throws ReportNotFoundException;

    List<Report> getResolvedByCSR_ID(String employeeID);

    List<Report> getReviewedByDEV() throws ReportNotFoundException;

//    String deleteReport(Report Report) throws ReportNotFoundException;

    List<Report> listOfReports(Date from, Date to);
    List<Report> listOfReportsResolvedByCsr(Date from, Date to);
    List<Report> listOfReportsResolvedByACsr(String employeeId,Date from, Date to);


    List<Report> addRandomReports(Integer number);
}


/*
* who the csr is with a specific id
* assigned date,
* resolved at */

/* redundancy
*
* services are running or not ?
* */