 package io.stackroute.reportservice.repository;

import io.stackroute.reportservice.model.Report;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Repository
public interface ReportRepository extends MongoRepository<Report, UUID> {


    List<Report> findAll();

    Report findByReportID(UUID ID);

    List<Report> findByStatus(Report.status status);

//    List<Report> findByTicketResolvedOn(LocalDate ticketResolvedOn);

    @Query("{ resolvedBy: BOT }")
    List<Report> getResolvedByBOT();

    @Query("{ resolvedBy: CSR }")
    List<Report> getResolvedByCSR();

    @Query("{ $and: [ { resolvedBy: CSR }, { 'interactions.employeeID': ?0 } ] }")
    List<Report> getResolvedByCSR_ID(String employeeID);

    @Query("{ $and: [ { resolvedBy: CSR }, { 'interactions.employeeID': ?0 },{'resolvedOn' : { $gte: ?0, $lte: ?1 } } ] }")
    List<Report> getResolvedByCSRID(String employeeID,Date from, Date to);

    @Query("{ lastUpdateBy: CSR }")
    List<Report> getToBeReviewed();

    @Query("{ 'interactions.with': DEV }")
    List<Report> getReviewedByDEV();

    @Query("{ $and: [ { resolvedBy: CSR }, {'createdOn' : { $gte: ?0, $lte: ?1 } } ] }")
    List<Report> getResolvedByCSRTimeFrame(Date from, Date to);

    @Query("{ $and: [ { status: RESOLVED }, {'createdOn' : { $gte: ?0, $lte: ?1 } } ] }")
    public List<Report> getReportsBetween(Date from, Date to);



}
