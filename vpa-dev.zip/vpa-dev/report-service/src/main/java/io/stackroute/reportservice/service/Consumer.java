package io.stackroute.reportservice.service;

import io.stackroute.reportservice.exception.ReportNotFoundException;
import io.stackroute.reportservice.model.Report;
import io.stackroute.reportservice.model.Ticket;
import org.apache.kafka.clients.producer.Producer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class Consumer {

//    private Producer producer;
    private ReportService reportService;
    private final Logger logger = LoggerFactory.getLogger(Consumer.class);

    @Autowired
    public Consumer(ReportService reportService) {
//        this.producer = producer;
        this.reportService = reportService;
    }

    @KafkaListener(topics = "ticket-reports", groupId = "group_id11")
    public void consume1(Ticket message) throws IOException, ReportNotFoundException {
        logger.info(String.format("#### -> Consumed message -> %s", message));
        reportService.addReport(message);
        System.out.println("----------------TICKET RECEIVED-----------------");
    }
}
