package io.stackroute.clientservicerepresentation.controller;

import io.stackroute.clientservicerepresentation.domain.WaitQueue;
import io.stackroute.clientservicerepresentation.domain.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashSet;

@CrossOrigin(value = "*")
@RestController
public class ChatController {

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    private HashSet<String> hash_Set = new HashSet<String>();
    WaitQueue csrQueue = new WaitQueue();
    WaitQueue userQueue = new WaitQueue();
    String user;
    String csr;

    @PostMapping("/api/v1/cs/enqueuecsr/{employeeID}")
    public void enqueueCSR(@PathVariable String employeeID) {
        csrQueue.enqueue(employeeID);
        System.out.println("----------------------" + employeeID + " added to Queue");
        if (!userQueue.isEmpty()) {
            System.out.println(userQueue.get(0));
            user = userQueue.dequeue();
            csr = csrQueue.dequeue();
            System.out.println("----------------------" + "Assigning " + csr + " to " + user);
            messagingTemplate.convertAndSendToUser(csr + "userName", "/reply", user);
            messagingTemplate.convertAndSendToUser(user + "csrName", "/reply", csr);

            Message enterMessage = new Message();
            enterMessage.setFromName("SYSTEM");
            enterMessage.setContent(user + " has entered the chat");
            messagingTemplate.convertAndSendToUser(csr, "/reply", enterMessage);
            System.out.println("-----------------Informing CSR " + enterMessage.toString());
            enterMessage.setContent(csr + " has entered the chat");
            messagingTemplate.convertAndSendToUser(user, "/reply", enterMessage);
            System.out.println("------------------Informing USER " + enterMessage.toString());
        }
    }


    @PostMapping("/api/v1/cs/removecsr/{employeeID}")
    public void removeFromQueue(@PathVariable String employeeID) {
        System.out.println(employeeID + " removed from queue");
        csrQueue.removeFromQueue(employeeID);
//        return new ResponseEntity<String>("Removed from Queue", HttpStatus.OK);
    }

    @MessageMapping("/chat.sendMessage/alert")
    public void sendUserList(@Payload Message message) {
        System.out.println(message.toString());
        if (message.getType().equals("newUser")) {
            userQueue.enqueue(message.getFromName());
            System.out.println("----------------------" + message.getFromName() + " added to Queue");
            if (!csrQueue.isEmpty()) {
                user = userQueue.dequeue();
                csr = csrQueue.dequeue();
                System.out.println("----------------------" + "Assigning " + csr + " to " + user);
                messagingTemplate.convertAndSendToUser(csr + "userName", "/reply", user);
                messagingTemplate.convertAndSendToUser(user + "csrName", "/reply", csr);

                Message enterMessage = new Message();
                enterMessage.setFromName("SYSTEM");
                enterMessage.setContent(user + " has entered the chat");
                messagingTemplate.convertAndSendToUser(csr, "/reply", enterMessage);
                System.out.println("-----------------Informing CSR " + enterMessage.toString());
                enterMessage.setContent(csr + " has entered the chat");
                messagingTemplate.convertAndSendToUser(user, "/reply", enterMessage);
                System.out.println("------------------Informing USER " + enterMessage.toString());
            }
        }
    }

    @MessageMapping("/chat.sendMessage/toCsr/{fromName}/{toName}")
    public void fromUser(@DestinationVariable String toName, @Payload Message message) {
        System.out.println(message.toString());
        if (message.getType().equals("newUser")) {
            hash_Set.add(message.getFromName());
            System.out.println(message.getFromName() + " entered " + LocalDateTime.now());
            System.out.println(hash_Set);
        }
        if (message.getType().equals("Leave")) {
            hash_Set.remove(message.getFromName());
            userQueue.removeFromQueue(message.getFromName());
            System.out.println(message.getFromName() + " left " + LocalDateTime.now());
            System.out.println(hash_Set);
            if (message.getToName() != null) {
                messagingTemplate.convertAndSendToUser(message.getToName(), "/reply", message);
            }
            return;
        }
        System.out.println(hash_Set.size());
        System.out.println("----------------------MESSAGE FROM: " + message.getFromName() + " TO: " + message.getToName());
        messagingTemplate.convertAndSendToUser(message.getToName(), "/reply", message);
    }

    @MessageMapping("/chat.sendMessage/toUser/{fromName}/{toName}")
    public void fromCsr(@DestinationVariable String toName, @Payload Message message) {
        System.out.println(message.toString());
        if (message.getType().equals("newUser")) {
            hash_Set.add(message.getFromName());
            System.out.println(message.getFromName() + " entered " + LocalDateTime.now());
            System.out.println(hash_Set);
        }
        if (message.getType().equals("Leave")) {
            hash_Set.remove(message.getFromName());
            csrQueue.removeFromQueue(message.getFromName());
            System.out.println(message.getFromName() + " left " + LocalDateTime.now());
            System.out.println(hash_Set);
            if (message.getToName() != null) {
                messagingTemplate.convertAndSendToUser(message.getToName(), "/reply", message);
            }
            return;
        }
        System.out.println(hash_Set.size());
        System.out.println("----------------------MESSAGE FROM: " + message.getFromName() + " TO: " + message.getToName());
        messagingTemplate.convertAndSendToUser(message.getToName(), "/reply", message);
    }

}
