package io.stackroute.clientservicerepresentation.domain;

import java.time.LocalDateTime;

public class Message {

    private String fromName;
    private String toName;
    private String content;
    private String type;
    private LocalDateTime dateTime;
    public Message(String fromName, String toName, String content, String type) {
        this.fromName = fromName;
        this.toName = toName;
        this.content = content;
        this.type = type;
        this.dateTime = LocalDateTime.now();
    }
    public Message() {
        this.dateTime = LocalDateTime.now();
        this.fromName = "bot";
    }
    public String getFromName() {
        return fromName;
    }
    public void setFromName(String fromName) {
        this.fromName = fromName;
    }
    public String getToName() {
        return toName;
    }
    public void setToName(String toName) {
        this.toName = toName;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public LocalDateTime getDateTime() {
        return dateTime;
    }
    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }
    @Override
    public String toString() {
        return "Message{" +
                "fromName='" + fromName + '\'' +
                ", toName='" + toName + '\'' +
                ", content='" + content + '\'' +
                ", type='" + type + '\'' +
                '}';
    }
}
