package io.stackroute.clientservicerepresentation.services;

import io.stackroute.clientservicerepresentation.domain.ClientRepresentative;
import io.stackroute.clientservicerepresentation.domain.Interaction;
import io.stackroute.clientservicerepresentation.domain.Ticket;
import io.stackroute.clientservicerepresentation.repository.ClientInfoRepository;
import io.stackroute.clientservicerepresentation.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


@Service
public class ClientServiceImpl implements ClientServices {

    ClientRepository clientRepository;
    ClientInfoRepository csrInfo;
    private final Producer producer;

    @Autowired
    public ClientServiceImpl(ClientRepository clientRepository, ClientInfoRepository csrInfo, Producer producer) {
        this.clientRepository = clientRepository;
        this.csrInfo = csrInfo;
        this.producer = producer;
    }

    @Override
    public ClientRepresentative saveUser(ClientRepresentative user) {
        ClientRepresentative userinfo = clientRepository.save(user);
        return userinfo;
    }

    @Override
    public List<ClientRepresentative> getInfo(int limit) {
        List<ClientRepresentative> list = clientRepository.findAll();
        List<ClientRepresentative> list1 = new ArrayList<>();

        for (int i = 0; i < limit; i++) {
            if (list.get(i).getStatus() == ClientRepresentative.status.UNRESOLVED) {
                list1.add(list.get(i));
            }
        }

        return list1;
    }

    @Override
    public List<ClientRepresentative> getAllList() {
        List<ClientRepresentative> list = clientRepository.findAll();
        List<ClientRepresentative> list1 = new ArrayList<>();

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getStatus() == ClientRepresentative.status.UNRESOLVED) {
                list1.add(list.get(i));
            }
        }   
        Collections.reverse(list1);
        return list1;
    }

    @Override
    public ClientRepresentative updateFeedback(ClientRepresentative client, String feedback) {
        return null;
    }

//    @Override
//    public ClientRepresentative updateFeedback(ClientRepresentative client, String feedback) {
//        client.setFeedback(feedback);
//        return clientRepository.save(client);
//
//    }

    @Override
    public List<ClientRepresentative> fetchAssignedTickets(String raisedBy) {
        List<ClientRepresentative> list = clientRepository.getListToCsr(raisedBy);
        Collections.reverse(list);
        List<ClientRepresentative> list1 = new ArrayList<>();
        if (list.size() < 5) {
            int j = 0;
            while (j < list.size()) {
                if (list.get(j).getStatus() == ClientRepresentative.status.UNRESOLVED) {

                    list1.add(list.get(j));
                }
                j++;
            }
            return list1;
        } else {

//            for(int i= 0;i<5;i++)
//            {
//                list1.add(list.get(i));
//            }
            int j = 0, i = 0;
            while (j < list.size() && i < 5) {
                if (list.get(j).getStatus() == ClientRepresentative.status.UNRESOLVED) {

                    list1.add(list.get(j));
                    i++;
                }
                j++;
            }
            return list1;
        }
//        return clientRepository.getListToCsr(raisedBy);
    }

    @Override
    public ClientRepresentative recieveTickets(Ticket ticket) {

        ClientRepresentative client = new ClientRepresentative();
        client.setID(ticket.getID());
        client.setQuery(ticket.getQuery());
        client.setIntent(ticket.getIntent());
        client.setRaisedBy(ticket.getRaisedBy());
        client.setCreatedOn(ticket.getCreatedOn());
        client.setFeedback(null);
        client.setRating(0);
        client.setInteractions(ticket.getInteractions());
        if (ticket.getType() == Ticket.type.QUERY) {
            client.setType(ClientRepresentative.type.QUERY);
        } else {
            client.setType(ClientRepresentative.type.TASK);
        }


        if (ticket.getStatus() == Ticket.status.UNRESOLVED) {
            client.setStatus(ClientRepresentative.status.UNRESOLVED);
        } else {
            client.setStatus(ClientRepresentative.status.RESOLVED);
        }

        if (ticket.getLastUpdateBy() == Ticket.lastUpdateBy.BOT) {
            client.setLastUpdateBy(ClientRepresentative.lastUpdateBy.BOT);
        } else if (ticket.getLastUpdateBy() == Ticket.lastUpdateBy.CSR) {
            client.setLastUpdateBy(null);
        }
        client.setLastUpdateOn(ticket.getLastUpdateOn());

        if (ticket.getResolvedBy() == Ticket.resolvedBy.BOT) {
            client.setResolvedBy(ClientRepresentative.resolvedBy.BOT);
        } else {
            client.setResolvedBy(null);
        }

        client.setResolvedOn(ticket.getResolvedOn());

        clientRepository.save(client);
        return client;

    }

    @Override
    public ClientRepresentative assignToUpdate(String assignedTo, ClientRepresentative client) {
        return null;
    }

//    @Override
//    public ClientRepresentative assignToUpdate(String assignedTo,ClientRepresentative client) {
//
//        client.setAssignedTo(assignedTo);
//        client.setAssignedAt(LocalDateTime.now());
//        clientRepository.save(client);
//        return client;
//    }

    @Override
    public ClientRepresentative Update1(ClientRepresentative client) {
        Ticket ticket = new Ticket();
        ticket.setID(client.getID());
        ticket.setStatus(Ticket.status.RESOLVED);
        ticket.setResolvedBy(Ticket.resolvedBy.CSR);
        ticket.setLastUpdateOn(LocalDateTime.now());
        ticket.setLastUpdateBy(Ticket.lastUpdateBy.CSR);
        ticket.setInteractions(client.getInteractions());
        ticket.setResolvedOn(LocalDateTime.now());
        this.producer.sendMessage(ticket);

        return clientRepository.save(client);
    }

    @Override
    public ClientRepresentative resolvedUpdate(String updatedBy, ClientRepresentative client) {
        return null;
    }

//    @Override
//    public ClientRepresentative resolvedUpdate(String updatedBy, ClientRepresentative client) {
//        client.setUpdatedBy(updatedBy);
//        client.setUpdatedOn(LocalDateTime.now());
//        client.setStatus(ClientRepresentative.status.RESOLVED);
//        clientRepository.save(client);
////        this.producer.sendMessage(client);
//        return client;
//    }
}
