package io.stackroute.clientservicerepresentation.controller;

import io.stackroute.clientservicerepresentation.domain.ClientRepresentative;
import io.stackroute.clientservicerepresentation.domain.Message;
import io.stackroute.clientservicerepresentation.services.ClientServices;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@RequestMapping(value = "api/v1")
@CrossOrigin(value = "*")
@RestController
public class ClientController {

    private ClientServices clientServices;

    public ClientController(ClientServices clientServices) {
        this.clientServices = clientServices;
    }




    @GetMapping("cs")
    public ResponseEntity<?> getAllEvents(@RequestParam(value = "limit", required = false) Integer limit){
        ResponseEntity responseEntity;
        if(limit != null) {
            try {

                responseEntity = new ResponseEntity<List<ClientRepresentative>>(clientServices.getInfo(limit), HttpStatus.OK);
            } catch (Exception ex) {
                responseEntity = new ResponseEntity<String>(ex.getMessage(), HttpStatus.NO_CONTENT);
            }
        }else{
            try {

                responseEntity = new ResponseEntity<List<ClientRepresentative>>(clientServices.getAllList(), HttpStatus.OK);
            } catch (Exception ex) {
                responseEntity = new ResponseEntity<String>(ex.getMessage(), HttpStatus.NO_CONTENT);
            }
        }
        return responseEntity;
    }

    @PostMapping("cs/post")
    public ResponseEntity<?>saveEvents(@RequestBody ClientRepresentative clientRepresentative) {
        ResponseEntity responseEntity;

        try {
            clientServices.saveUser(clientRepresentative);
            responseEntity = new ResponseEntity<String>("Successfully created", HttpStatus.CREATED);
        } catch (Exception ex) {
            responseEntity = new ResponseEntity<String>(ex.getMessage(), HttpStatus.CONFLICT);
        }
        return responseEntity;
    }

    @PutMapping("cs/updated")
    public ResponseEntity<?> updateInfo(@RequestBody ClientRepresentative client)
    {
        ResponseEntity responseEntity ;
        try {
            clientServices.Update1(client);
            responseEntity = new ResponseEntity<String>("updated feedback successfully", HttpStatus.CREATED);
        }
        catch (Exception ex)
        {
            responseEntity = new ResponseEntity<String>(ex.getMessage(),HttpStatus.CONFLICT);
        }
        return responseEntity;

    }



    @PutMapping("cs/update")
    public ResponseEntity<?> updateAssigned(@RequestParam(value = "assignedTo" , required = false) String assignedTo,@RequestParam(value = "updatedBy",required = false) String updatedBy, @RequestBody ClientRepresentative client)
    {
        ResponseEntity responseEntity;
        if(assignedTo != null){
        try {
            clientServices.assignToUpdate(assignedTo,client);
            responseEntity = new ResponseEntity<String>("updated assignedTo and assignedOn", HttpStatus.CREATED);
        }
        catch (Exception ex)
        {
            responseEntity = new ResponseEntity<String>(ex.getMessage(),HttpStatus.CONFLICT);
        }
        }
        else
        {
            try {
                clientServices.resolvedUpdate(updatedBy,client);
                responseEntity = new ResponseEntity<String>("updated update and assignedOn", HttpStatus.CREATED);
            }
            catch (Exception ex)
            {
                responseEntity = new ResponseEntity<String>(ex.getMessage(),HttpStatus.CONFLICT);
            }

        }

       return responseEntity;
    }


    @PutMapping("cs")
    public ResponseEntity<?> updateinfo(@RequestParam String feedback,@RequestBody ClientRepresentative client)
    {
        ResponseEntity responseEntity ;
        try {
            clientServices.updateFeedback(client,feedback);
            responseEntity = new ResponseEntity<String>("updated feedback successfully", HttpStatus.CREATED);
        }
        catch (Exception ex)
        {
            responseEntity = new ResponseEntity<String>(ex.getMessage(),HttpStatus.CONFLICT);
        }
        return responseEntity;

    }

    @GetMapping("cs/{raisedBy}")
    public ResponseEntity<?> fetchData(@PathVariable(value = "raisedBy") String raisedBy){
        ResponseEntity responseEntity;

        try {

            responseEntity = new ResponseEntity<List<ClientRepresentative>>(clientServices.fetchAssignedTickets(raisedBy),HttpStatus.OK);
        }catch (Exception ex){
            responseEntity = new ResponseEntity<String>(ex.getMessage(),HttpStatus.NO_CONTENT);
        }

        return responseEntity;
    }

}
