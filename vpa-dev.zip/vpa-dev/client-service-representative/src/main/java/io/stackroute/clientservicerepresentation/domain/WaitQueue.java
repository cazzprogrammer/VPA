package io.stackroute.clientservicerepresentation.domain;

import java.util.ArrayList;
import java.util.List;

public class WaitQueue {

    private List<String> waitQueue = new ArrayList<String>();

    public void enqueue(String employeeID){
        waitQueue.add(employeeID);
    }

    public String dequeue(){
        if(waitQueue.size() != 0){
            String first = waitQueue.get(0);
            waitQueue.remove(first);
            return first;
        }
        return null;
    }

    public void removeFromQueue(String employeeID){
        waitQueue.remove(employeeID);
    }

    public boolean isEmpty(){
        if(waitQueue.size() == 0){
            return true;
        }
        return false;
    }
    public String get(int index){
        return waitQueue.get(index);
    }
}
