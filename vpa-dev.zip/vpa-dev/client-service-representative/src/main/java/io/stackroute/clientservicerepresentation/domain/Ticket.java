package io.stackroute.clientservicerepresentation.domain;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Document
public class Ticket {

    public Ticket() {
    }

    public Ticket(UUID ID, String query, String intent, String raisedBy, LocalDateTime createdOn, List<Interaction> interactions, Ticket.type type, Ticket.status status, Ticket.lastUpdateBy lastUpdateBy, LocalDateTime lastUpdateOn, Ticket.resolvedBy resolvedBy, LocalDateTime resolvedOn) {
        this.ID = ID;
        this.query = query;
        this.intent = intent;
        this.raisedBy = raisedBy;
        this.createdOn = createdOn;
        this.interactions = interactions;
        this.type = type;
        this.status = status;
        this.lastUpdateBy = lastUpdateBy;
        this.lastUpdateOn = lastUpdateOn;
        this.resolvedBy = resolvedBy;
        this.resolvedOn = resolvedOn;
    }



    @Id
    private UUID ID;

    private String query;       // the query the user asks

    private String intent;      // the intent inferred by bot

    private String raisedBy;    // the user who asked the query

    private LocalDateTime createdOn;    // when was this ticket created

    private List<Interaction> interactions; // log of interactions with the ticket (csr/admin/dev)

    private type type;  // type of query asked by user

    public enum type {
        QUERY,
        TASK
    }

    private status status;  // is the ticket resolved or not

    public enum status {
        RESOLVED,
        UNRESOLVED
    }

    private lastUpdateBy lastUpdateBy;  // who made the last update to the ticket

    public enum lastUpdateBy {
        BOT,
        CSR,
        DEV,
        ADMIN
    }

    private LocalDateTime lastUpdateOn; // when was the ticket last updated

    private resolvedBy resolvedBy; // who resolved the ticket

    public enum resolvedBy {
        BOT,
        CSR,
        DEV,
        ADMIN
    }

    private LocalDateTime resolvedOn;   // when was the ticket resolved

    public UUID getID() {
        return ID;
    }

    public void setID(UUID ID) {
        this.ID = ID;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String getIntent() {
        return intent;
    }

    public void setIntent(String intent) {
        this.intent = intent;
    }

    public String getRaisedBy() {
        return raisedBy;
    }

    public void setRaisedBy(String raisedBy) {
        this.raisedBy = raisedBy;
    }

    public LocalDateTime getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(LocalDateTime createdOn) {
        this.createdOn = createdOn;
    }

    public List<Interaction> getInteractions() {
        return interactions;
    }

    public void setInteractions(List<Interaction> interactions) {
        this.interactions = interactions;
    }

    public Ticket.type getType() {
        return type;
    }

    public void setType(Ticket.type type) {
        this.type = type;
    }

    public Ticket.status getStatus() {
        return status;
    }

    public void setStatus(Ticket.status status) {
        this.status = status;
    }

    public Ticket.lastUpdateBy getLastUpdateBy() {
        return lastUpdateBy;
    }

    public void setLastUpdateBy(Ticket.lastUpdateBy lastUpdateBy) {
        this.lastUpdateBy = lastUpdateBy;
    }

    public LocalDateTime getLastUpdateOn() {
        return lastUpdateOn;
    }

    public void setLastUpdateOn(LocalDateTime lastUpdateOn) {
        this.lastUpdateOn = lastUpdateOn;
    }

    public Ticket.resolvedBy getResolvedBy() {
        return resolvedBy;
    }

    public void setResolvedBy(Ticket.resolvedBy resolvedBy) {
        this.resolvedBy = resolvedBy;
    }

    public LocalDateTime getResolvedOn() {
        return resolvedOn;
    }

    public void setResolvedOn(LocalDateTime resolvedOn) {
        this.resolvedOn = resolvedOn;
    }

    @Override
    public String toString() {
        return "Ticket{" +
                "ID=" + ID +
                ", query='" + query + '\'' +
                ", intent='" + intent + '\'' +
                ", raisedBy='" + raisedBy + '\'' +
                ", createdOn=" + createdOn +
                ", interactions=" + interactions +
                ", type=" + type +
                ", status=" + status +
                ", lastUpdateBy=" + lastUpdateBy +
                ", lastUpdateOn=" + lastUpdateOn +
                ", resolvedBy=" + resolvedBy +
                ", resolvedOn=" + resolvedOn +
                '}';
    }
}


