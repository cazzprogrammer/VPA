package io.stackroute.clientservicerepresentation.services;

import io.stackroute.clientservicerepresentation.domain.CsrInfo;
import io.stackroute.clientservicerepresentation.domain.Ticket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class Consumer {

    private ClientServices clientServices;

    private Producer producer;


    @Autowired
    public Consumer(ClientServices clientServices, Producer producer) {
        this.clientServices = clientServices;
        this.producer=producer;
    }

    private final Logger logger = LoggerFactory.getLogger(Consumer.class);

    @KafkaListener(topics = "unresolved-ticket", groupId = "group_id")
    public void consume(Ticket message) throws IOException {
        logger.info(String.format("#### -> Consumed message -> %s", message));
        System.out.println("I am the consumer from ticket");
        clientServices.recieveTickets(message);
//        this.producer.sendMessage(message);

    }
}
