package io.stackroute.clientservicerepresentation.services;

import io.stackroute.clientservicerepresentation.domain.ClientRepresentative;
import io.stackroute.clientservicerepresentation.domain.Ticket;

import java.util.List;
import java.util.UUID;

public interface ClientServices {

    public ClientRepresentative saveUser(ClientRepresentative user);
    public List<ClientRepresentative> getInfo(int limit);
    public List<ClientRepresentative> getAllList();
    public ClientRepresentative updateFeedback(ClientRepresentative client,String feedback);

    public List<ClientRepresentative> fetchAssignedTickets(String raisedBy);

    public ClientRepresentative recieveTickets(Ticket ticket);
    public ClientRepresentative assignToUpdate(String assignedTo, ClientRepresentative client);
    public ClientRepresentative Update1( ClientRepresentative client);
    public  ClientRepresentative resolvedUpdate(String updatedBy, ClientRepresentative client);



}
