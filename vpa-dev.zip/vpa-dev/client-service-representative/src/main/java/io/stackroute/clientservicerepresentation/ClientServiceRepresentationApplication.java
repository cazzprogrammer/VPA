package io.stackroute.clientservicerepresentation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class ClientServiceRepresentationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientServiceRepresentationApplication.class, args);
	}

}
