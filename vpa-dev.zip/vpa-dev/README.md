#VIRTUAL PRODUCTIVITY ASSISTANCE

##NquirIT.

###Description
Personal assistance bot which will primarily focuses on two tasks
1. Provide Information 
2. Perform a Task for the User related to the query. 


