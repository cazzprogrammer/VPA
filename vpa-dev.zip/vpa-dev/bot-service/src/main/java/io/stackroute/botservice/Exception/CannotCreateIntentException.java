package io.stackroute.botservice.Exception;

public class CannotCreateIntentException extends Exception {

    public CannotCreateIntentException() {
    }
    public CannotCreateIntentException(String message) {
        super(message);
    }
}
