package io.stackroute.botservice.Service;

import io.stackroute.botservice.Model.DFDataModel.Post.IntentPost;
import io.stackroute.botservice.Repository.DFRepository;
import io.stackroute.botservice.Model.DFDataModel.GetAll.IntentGet;
import io.stackroute.botservice.Model.DFDataModel.Post.IntentPostResponse;
import io.stackroute.botservice.Model.DFDataModel.ProcessQuery.QueryContainer;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DFService {

    @Autowired
    private DFRepository dfRepository;

    public IntentPostResponse addIntent(IntentPost intentPost) {
        return dfRepository.addIntent(intentPost);
    }

    public List<IntentGet> findAllIntents() {
        // fetch all the intents from dialogflow
        return dfRepository.findAllIntents();
    }

    public String processQuery(String query) {
        QueryContainer queryContainer = new QueryContainer(query);
        return dfRepository.processQuery(queryContainer);
    }

    public String getTheIntent(String query) throws JSONException{
        JSONObject jsonObject = new JSONObject(processQuery(query));
        String intent =  jsonObject.getJSONObject("result").getJSONObject("metadata").getString("intentName");
        return intent;
    }


    public void deleteIntent(String id) {
        dfRepository.deleteIntent(id);
    }

    public IntentPost getIntentPost(String id) {
        IntentPost  intentPost = dfRepository.getIntent(id);
        return intentPost;
    }
}
