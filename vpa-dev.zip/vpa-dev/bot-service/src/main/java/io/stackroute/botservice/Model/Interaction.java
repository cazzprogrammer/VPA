package io.stackroute.botservice.Model;


import java.time.LocalDateTime;

public class Interaction {

    private with with;

    public Interaction() {
    }

    public Interaction(Interaction.with with, LocalDateTime timeStamp) {
        this.with = with;
        this.timeStamp = timeStamp;
    }

    public Interaction(Interaction.with with, String employeeID, String summary, LocalDateTime timeStamp) {
        this.with = with;
        this.employeeID = employeeID;
        this.summary = summary;
        this.timeStamp = timeStamp;
    }

    public enum with {
        BOT,
        CSR,
        DEV,
        ADMIN;
    }

    private String employeeID;
    private String summary;
    private LocalDateTime timeStamp;

    @Override
    public String toString() {
        return "Interaction{" +
                "with=" + with +
                ", employeeID='" + employeeID + '\'' +
                ", summary='" + summary + '\'' +
                ", timeStamp=" + timeStamp +
                '}';
    }

    public Interaction.with getWith() {
        return with;
    }

    public void setWith(Interaction.with with) {
        this.with = with;
    }

    public String getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(String employeeID) {
        this.employeeID = employeeID;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public LocalDateTime getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(LocalDateTime timeStamp) {
        this.timeStamp = timeStamp;
    }

    //    BOT
//    BOT
//    answer
//    dateTime

//    CSR
//    csr id
//    answer
//    dateTime

//    DEV
//    dev id
//    reviewed
//    dataTime

//    ADMIN
//    admin id
//    reviewed
//    dataTime


}
