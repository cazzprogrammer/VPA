package io.stackroute.botservice.Service;

import io.stackroute.botservice.Exception.CannotCreateIntentException;
import io.stackroute.botservice.Model.BotDataModel.BotIntent;
import io.stackroute.botservice.Model.BotDataModel.Message;
import io.stackroute.botservice.Model.DFDataModel.Post.IntentPost;
import io.stackroute.botservice.Model.DFDataModel.Post.IntentPostResponse;
import io.stackroute.botservice.Model.Interaction;
import io.stackroute.botservice.Model.KBDataModel.Intent;
import io.stackroute.botservice.Model.KBDataModel.ResponsePost;
import io.stackroute.botservice.Model.Ticket;
import org.json.JSONException;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class BotService {

    private KBService kbService;
    private DFService dfService;
    private KafkaProducer kafkaProducer;

    public BotService(KBService kbService, DFService dfService, KafkaProducer kafkaProducer) {
        this.kbService = kbService;
        this.dfService = dfService;
        this.kafkaProducer = kafkaProducer;
    }

    public Message getResponse(String query, String userName) throws JSONException {
        // extract the intent
        String intentName = dfService.getTheIntent(query);
        System.out.println(intentName);

        Message message = new Message();
        message.setIntent(intentName);
        message.setToName(userName);

        // retrieve the corresponding tasks and answers of that intent from knowledge base
        Intent intent = kbService.getIntent(intentName);
        System.out.println(intent);
        if (intent != null) {
            if (intent.getTasks() != null && intent.getTasks().size() > 0) {
                message.setContent(intent.getTasks().get(0).getTask());
                message.setParams(intent.getTasks().get(0).getParams());
                message.setType("TASK");
            } else if(intent.getAnswers() != null && intent.getAnswers().size() > 0){
                message.setContent(intent.getAnswers().get(0).getAnswer());
                System.out.println(message.getContent());
                message.setType("ANSWER");
            }
        } else {
            message.setIntent("Fallback");
            message.setType("ANSWER");
            message.setContent("I don't know");
        }

        try {
            generateTicket(query, intentName, userName);
        } catch (Exception e){
            System.out.println("Failed to generate Ticket");
        }
        return message;
    }

    private void generateTicket(String query, String intentName, String userName) {
        Ticket ticket = new Ticket();
        ticket.setLastUpdateOn(LocalDateTime.now());
        ticket.setLastUpdateBy(Ticket.lastUpdateBy.BOT);
        ticket.setIntent(intentName);
        ticket.setQuery(query);
        ticket.setRaisedBy(userName);
        ticket.setType(Ticket.type.QUERY);
        ticket.setCreatedOn(LocalDateTime.now());
        if(!intentName.equals("DefaultFallbackIntent")) {
            ticket.setStatus(Ticket.status.RESOLVED);
            ticket.setResolvedBy(Ticket.resolvedBy.BOT);
            ticket.setResolvedOn(LocalDateTime.now());
        } else {
            ticket.setStatus(Ticket.status.UNRESOLVED);
        }
        List<Interaction> interactions = new ArrayList<Interaction>();
        interactions.add(new Interaction(Interaction.with.BOT, "12345", "Botwa Bewakoof Hai", LocalDateTime.now()));
        ticket.setInteractions(interactions);
        System.out.println(ticket);
        kafkaProducer.sendMessage(ticket);
//
    }

//    public void addAnswer(BotIntent botIntent) {
//        IntentPostResponse response = dfService.addIntent(botIntent.getIntentPost());
//        String id = response.getId();
//        kbService.addAnswer(botIntent.getIntentPost().getName(), botIntent.getResponsePost());
//    }
//
//    public void addTask(BotIntent botIntent){
//        IntentPostResponse response = dfService.addIntent(botIntent.getIntentPost());
//        String id = response.getId();
//        kbService.addTask(botIntent.getIntentPost().getName(), botIntent.getResponsePost());
//    }

    public void addIntent(BotIntent botIntent) throws CannotCreateIntentException {
        IntentPostResponse response = dfService.addIntent(botIntent.getIntentPost());
        if (response.getStatus().getErrorType().equals("success")) {
            System.out.println("Intent Added To DialogFlow");
            ResponsePost responsePost = botIntent.getResponsePost();
            Intent intentAnswer = null, intentTask = null;
            if (responsePost.getAnswer() != null) {
                intentAnswer = kbService.addAnswer(response.getId(), responsePost);
            } if (responsePost.getTask() != null){
                intentTask = kbService.addTask(response.getId(), responsePost);
            }
            if (intentAnswer != null || intentTask != null) {
                System.out.println("Intent Added To KnowledgeBase");
                return;
            }else{
                System.out.println("ERROR: Failed to create Intent. Problem encountered in neo4j");
            }
        }
        dfService.deleteIntent(response.getId());
        System.out.println("ERROR: Failed to create Intent. Problem encountered in dialogflow");
    }

    // delete intent
    public void deleteIntent(String id) {
        kbService.deleteIntent(id);
        dfService.deleteIntent(id);
    }

    public BotIntent getIntent(String id) {
        IntentPost intentPost = dfService.getIntentPost(id);
        ResponsePost responsePost = kbService.getResponsePost(id);
        return new BotIntent(intentPost, responsePost);
    }
}
