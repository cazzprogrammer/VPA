package io.stackroute.botservice.Model.KBDataModel;

import java.util.List;

public class ResponsePost {

    private String name;
    private String answer;
    private String task;
    private List<String> params;

    public ResponsePost() {
    }

    public ResponsePost(String name, String answer, String task, List<String> params) {
        this.name = name;
        this.answer = answer;
        this.task = task;
        this.params = params;
    }

    public List<String> getParams() {
        return params;
    }

    public void setParams(List<String> params) {
        this.params = params;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    @Override
    public String toString() {
        return "ResponsePost{" +
                "name='" + name + '\'' +
                ", answer='" + answer + '\'' +
                ", task='" + task + '\'' +
                '}';
    }
}
