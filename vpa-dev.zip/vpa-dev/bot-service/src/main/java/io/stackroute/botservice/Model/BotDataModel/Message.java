package io.stackroute.botservice.Model.BotDataModel;


import java.time.LocalDateTime;
import java.util.List;

public class Message {
    private String fromName;
    private String toName;
    private String content;
    private String type;
    private String intent;
    private LocalDateTime dateTime;
    private List<String> params;


    public List<String> getParams() {
        return params;
    }

    public void setParams(List<String> params) {
        this.params = params;
    }

    public void setFromName(String fromName) {
        this.fromName = fromName;
    }

    public Message() {
        this.dateTime = LocalDateTime.now();
        this.fromName = "BOT";
    }

    public String getFromName() {
        return fromName;
    }

    public String getToName() {
        return toName;
    }

    public void setToName(String toName) {
        this.toName = toName;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }

    public String getIntent() {
        return intent;
    }

    public void setIntent(String intent) {
        this.intent = intent;
    }


    @Override
    public String toString() {
        return "Message{" +
                "fromName='" + fromName + '\'' +
                ", toName='" + toName + '\'' +
                ", content='" + content + '\'' +
                ", type='" + type + '\'' +
                ", intent='" + intent + '\'' +
                ", dateTime=" + dateTime +
                ", params=" + params +
                '}';
    }
}