package io.stackroute.botservice.Model.KBDataModel;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Property;

import java.util.Date;
import java.util.List;

@NodeEntity
public class Task {

    @Id
    @GeneratedValue
    private Long id;

    @Property(name = "task")
    private String task;

//    @Property(name = "created_at")
//    private Date createdAt;
//
//    @Property(name = "updated_at")
//    private Date updatedAt

    @Property(name = "params")
    private List<String> params;

    public Task() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }


    public List<String> getParams() {
        return params;
    }

    public void setParams(List<String> params) {
        this.params = params;
    }

    @Override
    public String toString() {
        return "Task{" +
                "id=" + id +
                ", task='" + task + '\'' +
                ", params=" + params +
                '}';
    }
}
