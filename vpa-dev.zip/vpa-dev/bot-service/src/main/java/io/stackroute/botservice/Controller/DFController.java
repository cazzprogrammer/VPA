package io.stackroute.botservice.Controller;


import io.stackroute.botservice.Model.DFDataModel.GetAll.IntentGet;
import io.stackroute.botservice.Model.DFDataModel.Post.IntentPost;
import io.stackroute.botservice.Model.DFDataModel.Post.IntentPostResponse;
import io.stackroute.botservice.Service.DFService;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping("api/v1/bot/dialogflow")
public class DFController {

    @Autowired
    private DFService dfService;

    // create new intent
    @PostMapping("/addIntent")
    public IntentPostResponse addIntentDF(@RequestBody IntentPost intentPost) {
        System.out.println("Adding Intent To DialogFlow");
        // add the intent to the dialogflow
        return dfService.addIntent(intentPost);
    }

    // retrieve all intents
    @GetMapping("/getIntents")
    public List<IntentGet> getAllIntentDF() {
        System.out.println("Fetching Intents From DialogFlow");
        return dfService.findAllIntents();
    }

    @PostMapping("/processQuery")
    public String processQuery(@RequestParam("query") String query) throws JSONException {
        System.out.println("Getting Intent Of Query: " + query);
        return dfService.processQuery(query);
    }

}
