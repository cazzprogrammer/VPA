package io.stackroute.botservice.Service;

import io.stackroute.botservice.Model.KBDataModel.Answer;
import io.stackroute.botservice.Model.KBDataModel.Intent;
import io.stackroute.botservice.Model.KBDataModel.ResponsePost;
import io.stackroute.botservice.Model.KBDataModel.Task;
import io.stackroute.botservice.Repository.KBRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class KBService {

    @Autowired
    private KBRepository kbRepository;

    public List<String> findAllIntents() {
        return kbRepository.findAllIntents();
    }

    public Intent addAnswer(String id, ResponsePost responsePost) {
        return kbRepository.addAnswer(responsePost.getName(), id, responsePost.getAnswer());
    }

    public Intent addTask(String id, ResponsePost responsePost) {
        return kbRepository.addTask(responsePost.getName(), id, responsePost.getTask(), responsePost.getParams());
    }

    public Intent getIntent(String intent) {
        return kbRepository.getIntentByName(intent);
    }


    public Intent deleteIntent(String id) {
        return kbRepository.deleteIntent(id);
    }

    public ResponsePost getResponsePost(String id) {
        Intent intent = kbRepository.getIntentById(id);
        List<Answer> answers = intent.getAnswers();
        List<Task> tasks = intent.getTasks();
        String answer = "";
        String task = "";
        List<String> params = new ArrayList<>();
        if (intent != null) {
            if (answers != null && answers.size() > 0) {
                answer = answers.get(0).getAnswer();
            }
            if (tasks != null && tasks.size() > 0) {
                task = tasks.get(0).getTask();
                params = tasks.get(0).getParams();
            }

        }
        return new ResponsePost(intent.getIntent(), answer, task, params);
    }
}
