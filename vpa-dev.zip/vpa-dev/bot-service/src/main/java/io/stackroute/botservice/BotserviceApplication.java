package io.stackroute.botservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableEurekaClient
@ComponentScan("io.stackroute.botservice")
public class BotserviceApplication {

    public static void main(String[] args) {
        SpringApplication.run(BotserviceApplication.class, args);
    }

}
