package io.stackroute.botservice.Model.BotDataModel;

import io.stackroute.botservice.Model.DFDataModel.Post.IntentPost;
import io.stackroute.botservice.Model.KBDataModel.ResponsePost;

public class BotIntent {
    private IntentPost intentPost;
    private ResponsePost responsePost;

    public BotIntent() {
    }

    public BotIntent(IntentPost intentPost, ResponsePost responsePost) {
        this.intentPost = intentPost;
        this.responsePost = responsePost;
    }

    public IntentPost getIntentPost() {
        return intentPost;
    }

    public void setIntentPost(IntentPost intentPost) {
        this.intentPost = intentPost;
    }

    public ResponsePost getResponsePost() {
        return responsePost;
    }

    public void setResponsePost(ResponsePost responsePost) {
        this.responsePost = responsePost;
    }

    @Override
    public String toString() {
        return "BotIntent{" +
                "intentPost=" + intentPost +
                ", responsePost=" + responsePost +
                '}';
    }
}
