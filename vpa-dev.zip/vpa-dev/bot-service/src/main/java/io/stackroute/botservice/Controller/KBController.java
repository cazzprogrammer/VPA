package io.stackroute.botservice.Controller;

import io.stackroute.botservice.Model.KBDataModel.Intent;
import io.stackroute.botservice.Model.KBDataModel.ResponsePost;
import io.stackroute.botservice.Repository.KBRepository;
import io.stackroute.botservice.Service.KBService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping("api/v1/bot/graph")
public class KBController {

    @Autowired
    private KBRepository kbRepository;

    @Autowired
    private KBService kbService;

    // get all intents
    @GetMapping("/getIntents")
    public List<String> getAllIntentsKB() {
        return kbService.findAllIntents();
    }

    // get specific intent (with it's corresponding tasks and answers)
    @GetMapping("/getIntent")
    public Intent getIntent(@RequestParam(name = "intent") String intent) {
        return kbService.getIntent(intent);
    }

    @PostMapping("/addAnswer")
    public void addAnswer(@RequestParam(name = "intent") String id, @RequestBody ResponsePost responsePost) {
        kbService.addAnswer(id, responsePost);
    }

    @PostMapping("/addTask")
    public Intent addTask(@RequestParam(name = "intent") String id, @RequestBody ResponsePost responsePost) {
        return kbService.addTask(id, responsePost);
    }


    // create a new Intent

}

