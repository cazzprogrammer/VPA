package io.stackroute.botservice.Repository;

import io.stackroute.botservice.Model.KBDataModel.Intent;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface KBRepository extends Neo4jRepository<Intent, Long> {

    Intent findByIntent(String intent);

    @Query("MATCH (i:Intent) return i.intent")
    List<String> findAllIntents();



    @Query("MERGE(i:Intent {intent: {intent} }) ON CREATE SET i.id={id} CREATE (a:Answer {answer:{answer}}) MERGE (i)-[r:HAS_ANSWER]->(a) RETURN i, r, a;")
    Intent addAnswer(String intent, String id, String answer);

    // Find an intent and add a new task to it
    @Query("MERGE(i:Intent {intent: {intent} }) ON CREATE SET i.id={id} CREATE (t:Task {task:{task}, params:{params}}) MERGE (i)-[r:HAS_TASK]->(t) RETURN i, r, t;")
    Intent addTask(String intent, String id, String task, List<String> params);

    @Query("match (i:Intent {id:{id}}) optional match (i)-[r]->(b) delete i, r, b;")
    Intent deleteIntent(String id);

    @Query("match (i:Intent {id:{id}}) optional match (i)-[r]->(b) return i, r, b;")
    Intent getIntentById(String id);

    @Query("match (i:Intent {intent:{intent}}) optional match (i)-[r]->(b) return i, r, b;")
    Intent getIntentByName(String intent);
}
