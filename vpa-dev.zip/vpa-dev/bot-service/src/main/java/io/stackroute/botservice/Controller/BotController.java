package io.stackroute.botservice.Controller;

import io.stackroute.botservice.Exception.CannotCreateIntentException;
import io.stackroute.botservice.Model.BotDataModel.BotIntent;
import io.stackroute.botservice.Model.BotDataModel.Message;
import io.stackroute.botservice.Service.BotService;
import org.json.JSONException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.Set;


@RestController
@CrossOrigin("*")
@RequestMapping("api/v1/bot")
public class BotController {

    private BotService botService;

    BotController(BotService botService) {
        this.botService = botService;
    }

    private Set<String> hash_Set = new HashSet<String>();

    @MessageMapping("/chat.sendMessage/{fromName}/bot")
    @SendTo("/message/{fromName}")
    public Message sendMessage(@DestinationVariable String fromName, @Payload Message message) throws JSONException {
        if (message.getType().equals("newUser")) {
            hash_Set.add(message.getFromName());
            System.out.println(message.getFromName() + " entered");
            System.out.println(hash_Set);
        }
        if (message.getType().equals("Leave")) {
            hash_Set.remove(message.getFromName());
            System.out.println(message.getFromName() + " left");
            System.out.println(hash_Set);
        }
//        System.out.println(hash_Set.size());
        System.out.println(message);
        Message returnMessage = botService.getResponse(message.getContent(), message.getFromName());
        System.out.println("Incoming : " + message + " Return : " + returnMessage);
        return returnMessage;
    }

    @GetMapping("/getResponse")
    public Message response(@RequestParam("query") String query) throws JSONException {
        Message returnMessage = botService.getResponse(query, "wadu");
        System.out.println("Incoming : " + query + " Return : " + returnMessage);
        return returnMessage;
    }
    @PostMapping("/addIntent")
    private ResponseEntity<?> addIntent(@RequestBody BotIntent botIntent) throws CannotCreateIntentException {
        System.out.println("Adding Intent... ");
        botService.addIntent(botIntent);
        System.out.println("Intent added Successfully");
        return new ResponseEntity<>("Intent added Successfully", HttpStatus.OK);
    }

    @DeleteMapping("/deleteIntent/{id}")
    private void deleteIntent(@PathVariable("id") String id) {
        botService.deleteIntent(id);
    }

    @GetMapping("/getIntent/{id}")
    private BotIntent getIntent(@PathVariable("id") String id){
        return botService.getIntent(id);

    }
}
