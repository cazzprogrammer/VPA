import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-chat-start',
  templateUrl: './chat-start.component.html',
  styleUrls: ['./chat-start.component.css']
})
export class ChatStartComponent implements OnInit {

  private id;
  constructor(private router:Router) { }

  ngOnInit() {
  }

  // closeConversation() {
  //   this.router.navigate(['closeticket/:id'])
  // }
}
