import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  
  assignTime:string;

  constructor() { }

  saveTime(time) {
    this.assignTime=time;
  }
  getTime() {
    return this.assignTime;
  }
}
