import { Component, OnInit, AfterViewInit, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServiceService } from '../service.service';

import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';
import $ from 'jquery';
import { IQuestions } from '../questions';
import { HttpClient } from '@angular/common/http';
import * as moment from 'moment';
import { environment } from 'src/environments/environment';
import { Interactions } from '../questions';
import { CommunicationService } from '../communication.service';
import { SharedService } from '../shared.service';

@Component({
  selector: 'app-chat-log',
  templateUrl: './chat-log.component.html',
  styleUrls: ['./chat-log.component.css']
})
export class ChatLogComponent implements OnInit {

  private serverUrl = environment.socketUrl; // write url correctly
  private title = 'WebSockets chat';   //topic
  private stompClient;
  recipient;
  display: boolean;
  temp:boolean=true;
  concernedTicket;
  private domain: string = environment.ticketUrl; // write url correctly
  public Id;
  Bool: boolean;
  textareaValue = '';
  messages = [];
  addMsg(message) {
    this.messages.push(message);
  }

  constructor(private route: ActivatedRoute, private router: Router, private _serviceService: ServiceService, private http: HttpClient, private communication: CommunicationService, private sharedService: SharedService) {
    this.route.params.subscribe(
      params => {
        this.display = params.bool;
        this.recipient=params.id;
        console.log(this.recipient);
      });
  }

  ngOnInit() {
    this.initializeWebSocketConnection();
    this.connect();
  }

  onClickEnd() {
    this.display = !this.display;
    this.temp=!this.temp;

    const sender = localStorage.getItem('sender');
    // const recipient = localStorage.getItem('recipient');
    const chatMessage = {
      fromName: 'SYSTEM',
      toName: this.recipient,
      type: 'Leave',
      content: sender + ' left the chat'
    };
    this.stompClient.send(`/app/chat.sendMessage/toUser/${sender}/${this.recipient}`, {}, JSON.stringify(chatMessage));
  }


  toggledisplay() {
    this.display = !this.display;
  }

  onClickClose(Answer) {
    console.log("concerned ticket" + this.concernedTicket);
    Math.floor(Math.random() * .999);
    const ticket: IQuestions = this.concernedTicket[0];
    console.log("ticket is raised by :"+ticket.raisedBy)
    console.log('to see the time');
    var temp: Interactions = new Interactions();
    temp.with = "CSR";
    temp.username = localStorage.getItem('sender');
    // console.log(temp.username+" is username");
    // var randNum = Math.floor(Math.random() * .999)
    // var correctedTimeStamp=moment().format().substring(0,19)+randNum;
    var assignTime=this.sharedService.getTime();
    var endTime = moment().format().substring(0, 19) + ".000";
    console.log("catch time is here"+assignTime);
    console.log(endTime)
    console.log(assignTime)
    temp.releaseTime = endTime;
    temp.catchTime=assignTime;
    temp.summary = Answer;
    console.log(temp.summary)

    if (ticket.interactions !== null) {
      ticket.interactions.push(temp);
    } else {
      ticket.interactions = [temp];
    }
    ticket.status = 'RESOLVED';
    // ticket.interactions = array
    console.log(environment.ticketUrl + 'updated');
    this._serviceService.post(ticket)
      .subscribe(data => {
        console.log(JSON.stringify(data));
      });

    this.router.navigate(['/chathome']);
  }

  initializeWebSocketConnection() {
    const ws = new SockJS(this.serverUrl);
    let sender = localStorage.getItem('sender');
    console.log('sender is: ' + sender);
    // this.recipient=sender;
    this.stompClient = Stomp.over(ws);
    const that = this;
    this.stompClient.connect({}, (frame) => {
      that.stompClient.subscribe(`/user/${sender}/reply`, (message) => {

        if (message.body) {
          let messageBody = JSON.parse(message.body)
          messageBody.orientation = 'left';
            this.addMsg(messageBody);
          console.log(messageBody.content);
        }
      });
    });
  }

  sendMessage(message) {
    let sender = localStorage.getItem('sender');
    let messageTemplate = {
      'content': message,
      'fromName': sender,
      'toName': this.recipient,
      'type': "CHAT",
      'orientation': ''
    }

    // let recipient = localStorage.getItem('sender');
    // $(".chat").append("<div class='message'>" + message + "</div>")
    messageTemplate.orientation = 'right';
    console.log(messageTemplate);
    this.addMsg(messageTemplate);
    this.stompClient.send(`/app/chat.sendMessage/toUser/${sender}/${this.recipient}`, {}, JSON.stringify(messageTemplate));
    this.textareaValue = '';
  }

  connect() {
    this.http.get(this.domain.concat(this.recipient)).subscribe((data: IQuestions[]) => {
      this.concernedTicket = data;
      this.concernedTicket.map(e => {
      });
    });
  }

  @HostListener('window:beforeunload', ['$event'])
  beforeunloadHandler(event) {
    // this.onClickEnd();
    const sender = localStorage.getItem('sender');
    // const recipient = localStorage.getItem('recipient');
    const chatMessage = {
      fromName: 'SYSTEM',
      toName: this.recipient,
      type: 'Leave',
      content: sender + ' has left the chat'
    };
    this.stompClient.send(`/app/chat.sendMessage/toUser/${sender}/${this.recipient}`, {}, JSON.stringify(chatMessage));
    return null;

  }
}
