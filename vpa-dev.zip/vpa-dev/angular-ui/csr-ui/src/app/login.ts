export interface ILogin {
    role:string,
    username:string,
    password:string
}