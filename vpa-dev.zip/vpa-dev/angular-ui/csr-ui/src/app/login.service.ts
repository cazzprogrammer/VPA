import { Injectable } from '@angular/core';
import { tap } from 'rxjs/operators';
import { ILogin } from './login';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private httpclient: HttpClient) { }
//   login(email:string, password:string) {
//     return this.httpclient.post<{access_token:  string}>('http://www.your-server.com/auth/login', {email, password}).pipe(tap(res => {
//     localStorage.setItem('access_token', res.access_token);
// }))
// }
  private _url_login;
   loginPost(loginDetails: ILogin): Observable<ILogin> {
     return this.httpclient.post<ILogin>('http://localhost:3000/login', loginDetails)
   }

}

