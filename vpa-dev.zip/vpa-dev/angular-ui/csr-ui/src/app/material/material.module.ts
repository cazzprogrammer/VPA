//this file is being used only for export and imports material modules

import { NgModule } from '@angular/core';
import { MatButtonModule, MatInputModule } from'@angular/material';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatListModule} from '@angular/material/list';
import {TextFieldModule} from '@angular/cdk/text-field';
import {AutosizeModule} from 'ngx-autosize';
import {MatCardModule} from '@angular/material/card';
import {MatIconModule} from '@angular/material/icon';
import {MatCheckboxModule} from '@angular/material/checkbox';



const MaterialComponents=[
  MatButtonModule
]

@NgModule({
  // declarations: [],
  imports: [
    MaterialComponents,
    MatExpansionModule,
    MatToolbarModule,
    MatSidenavModule,
    MatGridListModule,
    MatButtonToggleModule,
    MatFormFieldModule,
    MatListModule,
    TextFieldModule,
    AutosizeModule,
    MatCardModule,
    MatIconModule,
    MatCheckboxModule,
    MatInputModule,
  ],

  exports: [
    MaterialComponents,
    MatExpansionModule,
    MatToolbarModule,
    MatSidenavModule,
    MatGridListModule,
    MatButtonToggleModule,
    MatFormFieldModule,
    MatListModule,
    TextFieldModule,
    AutosizeModule,
    MatCardModule,
    MatIconModule,
    MatCheckboxModule,
    MatInputModule,
  ]
})
export class MaterialModule { }
