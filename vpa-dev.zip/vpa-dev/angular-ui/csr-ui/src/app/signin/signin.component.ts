import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RouteConfigLoadEnd, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { CommunicationService } from '../communication.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
  
  
  jwttoken;
  login_url:string= environment.URL_LOGIN;
  constructor(private router:Router,private http:HttpClient,private transfer:CommunicationService) { 
    this.route();
  }


  ngOnInit() {
  }
  username:string;

  authenticate(username,password)
  {
    this.username=username;
    var login_data={
      "username":username,
      "password":password
    }
    console.log("into authenticate")
    this.http.post(this.login_url,login_data).subscribe((data: any)=>
    {
      console.log(data)
      this.jwttoken = data.token;
      localStorage.setItem('token', this.jwttoken);
      localStorage.setItem('sender',login_data.username)
      this.route();
      this.fire();
    });
  }
  route(){
    this.router.navigateByUrl('/chathome');
  }
  fire(){
    console.log(this.username)
    this.transfer.raiseEvent(this.username);
  }

}
