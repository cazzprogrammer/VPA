import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Nquireit-Csr';
constructor(private router: Router) {

}

  onClickLogout() {
    localStorage.setItem("token","invalid");
    this.router.navigateByUrl('/login');
  }
}
