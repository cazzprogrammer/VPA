import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ServiceService } from '../service.service';
import { HttpClient } from '@angular/common/http';
import { IQuestions } from '../questions';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-ticket-info',
  templateUrl: './ticket-info.component.html',
  styleUrls: ['./ticket-info.component.css']
})
export class TicketInfoComponent implements OnInit {

  private domain: string = environment.ticketUrl // write url correctly
  public Id;
  concernedTicketList: IQuestions[];
  concernedTicket:IQuestions[];
  ticket:IQuestions;
  private isCollapsed: boolean = true;



  constructor(private route: ActivatedRoute, private http: HttpClient) {
    console.log("Inside Constructor");
  }

  ngOnInit() {
    console.log("inside ticket-info")
    this.route.params.subscribe(
      params => {
        console.log(params)
        this.Id = params.id;
        this.connect();
      });
  }

  serverurl: string;



  toggleCollapse() {
    this.isCollapsed = !this.isCollapsed;
  }

  connect() {
    this.http.get(this.domain.concat(this.Id)).subscribe((data: IQuestions[]) => {
      this.concernedTicketList = data;
      this.concernedTicket=[data[0]];
      this.ticket=this.concernedTicketList[0]
      console.log(this.concernedTicketList);
      this.concernedTicketList.map(e => {
      });
    });
  }
}
