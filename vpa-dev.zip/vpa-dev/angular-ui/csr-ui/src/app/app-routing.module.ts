import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ChatLogComponent } from './chat-log/chat-log.component';
import { ChatHomeComponent } from './chat-home/chat-home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ChatStartComponent } from './chat-start/chat-start.component';
import { AuthguardService } from './guards/authguard.service';
import { SigninComponent } from './signin/signin.component';

const routes: Routes = [
  { path: '', redirectTo: '/chathome', pathMatch: 'full' , canActivate: [AuthguardService]},
  // { path: '', redirectTo: '/chathome', pathMatch: 'full'},
  { path: 'login', component: SigninComponent },
  { path: 'chathome', component: ChatHomeComponent , canActivate: [AuthguardService]},
  { path: 'chatstart/:id/:bool', component: ChatStartComponent , canActivate: [AuthguardService]},
  { path: "**", component: PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [
  ChatHomeComponent,
  ChatLogComponent,
  PageNotFoundComponent,
  ChatStartComponent,
  SigninComponent
];
