export class IQuestions {
    id:string;
    query:string;
    intent:string;
    raisedBy:string;
    createdOn:string;
    interactions: Interactions[];
    type:string;
    status:string;
    lastUpdateBy:string;
    lastUpdateOn:string;
    resolvedBy:string;
    resolvedOn:string;
    rating:number;
    feedback:string;
}

export class Interactions {
    with:string;
    username:string;
    summary:string;
    catchTime:string;
    releaseTime:string;
}

// -------------------------------OLD DATA MODEL IS BELOW --------

// export interface IQuestions {
//     id:number,
//     username:string,
//     question:string,
//     answer:string
// }
// export interface IQuestions {
//     id: string,
//     ticket_Id: string,
//     query: string,
//     intend: string[],
//     raisedBy: string,
//     ticketraisedOn: string;
//     assignedAt:string,
//     assignedTo: string,
//     feedback: string,
//     rating: number,
//     commandUsed: string,
//     updatedBy: string,
//     updatedOn: string,
//     type: string,
//     status: string
// }

