import { Component, OnInit, Input, HostListener } from '@angular/core';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';
import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';
import { FormsModule } from '@angular/forms';
import * as moment from 'moment';
import { CommunicationService } from '../communication.service';
import { SharedService } from '../shared.service';
import { IQuestions } from '../questions';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-chat-home',
  templateUrl: './chat-home.component.html',
  styleUrls: ['./chat-home.component.css']
})
export class ChatHomeComponent implements OnInit {

  True: true;
  next: boolean = false;
  offline:boolean=false;
  private stompClient;
  private serverUrl = environment.socketUrl;
  users = [];
  user: string;
  unresolvedTickets = [];
  recipient;

  constructor(private _serviceService: ServiceService, private router: Router, private communication: CommunicationService, private sharedService: SharedService) {
    var randNum = Math.floor(Math.random() * .999)
    var correctedTimeStamp = moment().format().substring(0, 19) + randNum;
    console.log(correctedTimeStamp);
  }

  ngOnInit() {
    this.initializeWebSocketConnection();
  }
  userlistuserlist
  onClickAssign(id, bool) {
    var assignTime = moment().format().substring(0, 19) + ".000";
    this.sharedService.saveTime(assignTime);
    this.router.navigateByUrl(`/chatstart/${id}/${true}`)
    // this.recipient=localStorage.setItem("recipient",)
  }

  onClickNext() {
    let sender = localStorage.getItem('sender');
    this._serviceService.addToQueue(sender);
    this.next = true;
    this.offline=false;
  }

  onClickOffline() {
    this.offline=true;
    this._serviceService.getUnresolvedTickets()
      .subscribe(data => {
        this.unresolvedTickets = data;
        console.log(data)
      });
  }
  
  onClickRemove(){
    // this.online = false;
    this.next = false;
    console.log("we are here"+this.next);
    let sender = localStorage.getItem('sender');
    this._serviceService.removeFromQueue(sender);
  }

  onClickResolve(id, bool) {
    
    this.onClickRemove();
    this.router.navigateByUrl(`/chatstart/${id}/${false}`);
  }

  initializeWebSocketConnection() {
    let ws = new SockJS(this.serverUrl);
    let sender = localStorage.getItem('sender');
    this.stompClient = Stomp.over(ws);
    let that = this;
    this.stompClient.connect({}, (frame) => {
      // console.log("we are here")
      this.stompClient.subscribe(`/user/${sender}userName/reply`, (message) => {
        
        this.user = message.body;
        if (this.user != null) {
                  this.onClickAssign(this.user, true);
        }
        // let onlineUsers = JSON.parse(message.body);
        // onlineUsers.map(e => {
        //   console.log(e)
        //   console.log(this.users, "USERS ARRAY is accessible here ??")
        //   this.users = JSON.parse(message.body)
        //   if (this.users.length > 0){
        //     this.onClickAssign(this.users[0], true);
        //   }
        // });
      });
      
      //this.stompClient.send(`/app/chat.sendMessage/alert`, {}, JSON.stringify(messageTemplate));
      // console.log(this.users);
    });
  }

  @HostListener('window:beforeunload', ['$event'])
  beforeunloadHandler(event) {
    this.onClickRemove();
    return null;
  }
}
