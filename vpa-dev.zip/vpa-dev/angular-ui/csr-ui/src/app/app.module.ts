import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule, routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
// import { ChatLogComponent } from './chat-log/chat-log.component';
// import { ChatHomeComponent } from './chat-home/chat-home.component';
import { ChatStartComponent } from './chat-start/chat-start.component';
import { ServiceService } from './service.service';
import { HttpClientModule } from '@angular/common/http';
// import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
// import { CloseTicketComponent } from './close-ticket/close-ticket.component';
// import { LoginComponent } from './login/login.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material/material.module';
import { TicketInfoComponent } from './ticket-info/ticket-info.component';
import { FormsModule } from '@angular/forms';
import { JwtModule, JwtModuleOptions, JwtHelperService, JWT_OPTIONS } from '@auth0/angular-jwt';
import { AuthguardService } from './guards/authguard.service';
import { AuthService } from './guards/auth.service';


// const JWT_Module_Options: JwtModuleOptions = {
//   config: { 
//     tokenGetter: () => {
//       return localStorage.getItem('token');
//     }
//   }
// }

export function jwtOptionsFactory(tokenService) {
  return {
    tokenGetter: () => {
      return localStorage.getItem('token')
    }
  }
}


@NgModule({
  declarations: [
    AppComponent,
    // ChatLogComponent,
    // ChatHomeComponent,
    routingComponents,
    ChatStartComponent,
    TicketInfoComponent,
    // LoginComponent,
    // CloseTicketComponent,
    // PageNotFoundComponent

  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    FormsModule,
    JwtModule.forRoot({
      jwtOptionsProvider: {
        provide: JWT_OPTIONS,
        useFactory: jwtOptionsFactory,
        deps: []
      }
    }),
  ],
  providers: [ServiceService, AuthguardService, AuthService,JwtHelperService],
  bootstrap: [AppComponent]
})
export class AppModule { }
