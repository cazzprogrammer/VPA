import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IQuestions } from './questions';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  private _url_questions:string="assets/data/questions.json";
  private _url_answers:string="assets/data/questions.json";

  constructor(private http: HttpClient) { }
  // public myData: BehaviorSubject<IQuestions[]> = new BehaviorSubject<IQuestions[]>([]);


  // getOnlineUsers() {
  //   return this.http.get('http://172.23.239.119:9002/Socket');
  // }
  getQuestions() {
    return this.http.get<IQuestions[]>('http://172.23.239.119:9002/api/v1/cs');
    // return this.http.get<IQuestions[]>(this._url_questions+"/cs");

  }
  getUnresolvedTickets() {
    return this.http.get<IQuestions[]>(environment.ticketUrl);
    // return this.http.get<IQuestions[]>(this._url_questions+"/cs");

  }

  getQuestionById(id) {
    return this.http.get(`http://localhost:3000/cs/${id}`)
    //return this.http.get(`http://172.23.239.119:9002/Socket`)

  }

  getOfflineQuestionsById(id) {
    return this.http.get<IQuestions[]>(`http://localhost:3000/offline/${id}`);
    // return this.http.get<IQuestions[]>(this._url_questions+"/cs");

  }

  post (answer: IQuestions){
    return this.http.put(environment.ticketUrl+"updated", answer, {responseType: "text"});
    // return this.http.post<IAnswers>(this._url_answers, answer)
  }

  addToQueue(employeeId: string): void{
     this.http.post(environment.ticketUrl + "enqueuecsr/" + employeeId , employeeId).subscribe();
  }

  removeFromQueue(employeeId: string): void{
    this.http.post(environment.ticketUrl + "removecsr/" + employeeId , employeeId).subscribe();
 }
}