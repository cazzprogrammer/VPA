export const environment = {
  production: true,
  ticketUrl: 'http://15.206.110.2:8081/api/v1/cs/',
  socketUrl: 'http://15.206.110.2:8081/Socket',
  unresolvedTickets: 'http://15.206.110.2:8081/api/v1/getallunresolvedtickets',
  URL_LOGIN: 'http://15.206.110.2:8090/authenticate'
};
