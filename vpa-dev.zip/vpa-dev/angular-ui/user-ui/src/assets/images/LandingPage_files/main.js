(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<nav class=\"navbar navbar-expand-md navbar-dark fixed-top\" style=\"background-color: #673ab7;\">\n    <a class=\"navbar-brand\" href=\"#\">\n        <img id=\"nav-logo\" src=\"/assets/images/Ntrans.png\" alt=\"Logo\">\n    </a>\n\n    <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarTogglerDemo\" aria-controls=\"navbarTogglerDemo\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">\n        <span class=\"navbar-toggler-icon\"></span>\n    </button>\n    \n    <div class=\"collapse navbar-collapse justify-content-end\" id=\"navbarTogglerDemo\">\n        <ul class=\"nav navbar-nav\" id=\"nav-elements\">\n            <li>\n                <a class=\"nav-link \" href=\"#\">Home</a>\n            </li>\n            <li>\n                <a class=\"nav-link \" href=\"#\">About</a>\n            </li>\n            <li>\n                <a class=\"nav-link \" href=\"#\">Contact Us</a>\n            </li>\n            <li>\n                <a class=\"nav-link \" href=\"#\">Download</a>\n            </li>\n        </ul>\n    </div>\n</nav>\n\n<div id=\"demo-button\" (click)=\"demo()\">\n    <img id=\"demo-button-image\" src=\"/assets/images/bot.gif\">\n</div>\n\n<!--jumbotron-->\n<section class=\"--container-fluid mr-0 ml-0\">\n    <h1 class=\"d-none\"> My Intro</h1>\n    <div class=\"jumbotron jumbotron-fluid bg-light\">\n    \n        <div class=\"jumbotron-background\">\n        <img src=\"/assets/images/chat.svg\" class=\"j-image\" alt=\"sunset\" >\n        </div>\n    \n        <div class=\"container text-white\">\n        <section class=\"css-typing\" id=\"jumbotron-content\">\n            <!-- <hr class=\"my-4\"> -->\n            <p>N'QUIREIT</p> \n            <p class=\"sub-text\">provides you a virtual assistance to your organization</p>\n            <p class=\"saying\">Smart query engine which provides a quick interface to resolve and performs tasks for the users </p>\n            <br>\n            <a class=\"btn btn-primary btn-lg\" data-toggle=\"modal\" data-target=\"#btnModal\" role=\"button\">Don't Click</a>\n        </section>\n        </div>\n        <!-- container ends here --> \n    \n        <!-- The Modal -->\n        <div class=\"modal fade\" id=\"btnModal\">\n            <div class=\"modal-dialog\">\n            <div class=\"modal-content\">\n            \n                <!-- Modal Header -->\n                <div class=\"modal-header\">\n                <h4 class=\"modal-title\">I knew, </h4>\n                <button type=\"button\" class=\"close\" data-dismiss=\"modal\">×</button>\n                </div>\n                \n                <!-- Modal body -->\n                <div class=\"modal-body\">\n                you would..!\n                </div>\n                \n                <!-- Modal footer -->\n                <div class=\"modal-footer\">\n                <button type=\"button\" class=\"btn btn-danger\" data-dismiss=\"modal\">Close</button>\n                </div>\n                \n            </div>\n            </div>\n        </div>\n        <!--Modal window ends here-->\n        \n    </div>\n</section>\n    <!--jumbotron ends here-->\n\n\n<section class=\"container-fluid \" id=\"some-more\">\n    <div class=\"row\">\n        <div class=\"col\">\n        <h1 >Scroll down to check what our query engine can provide!!!.</h1>\n        </div><!--1st row ends here-->\n    </div>\n</section><!--container-fluid  ends here-->\n<br/>\n<article>\n    <div class=\"row featurette mr-0\" id=\"info\">\n        <div class=\"col-md-5\" id=\"info-left\">\n        <h2 class=\"featurette-heading \" id=\"question\">Proactive + Available 24/7</h2>\n        </div>\n        <!--info-right-->\n        <div class=\"col-md-7 shadow\" id=\"info-right\">\n            <p>\n                    Conversational marketing is proactive,\n                     triggering conversations on specific behaviors. \n                     Also, conversational marketing tools are available 24 hours a day,\n                      7 days a week and able to answer questions as well as provide \n                      people with information they need when you're not available.\n\n            </p>\n        </div>     \n        <!--info-right ends-->\n    </div>\n</article>\n\n<div class=\"row featurette mr-0\" id=\"info\">\n        <div class=\"col-md-7 shadow\" id=\"info-right\">\n                <p>\n            Employees spend a lot of time with operational issues and that \n            impacts their productivity by bringing it down by at least 30%. \n            Check out how its possible to reduce that by actually involving fewer resources.\n                </p>\n\n            </div>    \n\n            <div class=\"col-md-5\" id=\"info-left\">\n                <h2 class=\"featurette-heading \" id=\"question\">Employee engagement</h2>\n            </div>\n\n        <!--info-right ends-->\n</div>\n\n\n\n<div class=\"row featurette mr-0\" id=\"info\">\n        <div class=\"col-md-5\" id=\"info-left\">\n        <h2 class=\"featurette-heading \" id=\"question\">Varied use cases</h2>\n        </div>\n        <!--info-right-->\n        <div class=\"col-md-7 shadow\" id=\"info-right\">\n            <p>\n                    Users can interact with NLPBOTS® to ask about company policy that relates to them,\n                     leave and benefits information and much more. The system can be configured to offer personalized information \n                    depending on the user profile/level in the organization.\n            </p>\n        </div>     \n        <!--info-right ends-->\n    </div>\n    <div class=\"row featurette mr-0\" id=\"info\">\n            <div class=\"col-md-7 shadow\" id=\"info-right\">\n                    <p>\n                            NQUIREIT integrates with your website, mobile applications as well as collaborative or social platforms. Leverage the power of \n                            intelligent bots across Slack, Facebook, Skype, Telegram and more.\n    \n                </div>    \n    \n                <div class=\"col-md-5\" id=\"info-left\">\n                    <h2 class=\"featurette-heading \" id=\"question\">Omni-channel</h2>\n                </div>\n    \n            <!--info-right ends-->\n    </div>\n    \n<div class=\"row featurette mr-0\" id=\"info\">\n        <div class=\"col-md-5\" id=\"info-left\">\n        <h2 class=\"featurette-heading \" id=\"question\">Easy integrations</h2>\n        </div>\n        <!--info-right-->\n        <div class=\"col-md-7 shadow\" id=\"info-right\">\n            <p>\n                    NLPBOTS® easily integrates with globally popular enterprise HR products such as HRMS, LMS, ATS, DMS, etc. This helps enterprises leverage user and process data to \n                    deliver highly focused experiences across their Automation initiatives. NLPBOTS® powerful algorithms work with both structured and unstructured data sources to deliver potent application experiences. Integrations via Web Services and APIs are available for the following products, with many more being added.\n            </p>\n        </div>     \n        <!--info-right ends-->\n    </div>\n\n<!--grid -->\n<section class=\"container-fluid \" id=\"some-more\">\n        <div class=\"row\">\n            <div class=\"col\">\n            <h1>Quick Installation guide.</h1>\n            </div><!--1st row ends here-->\n        </div>\n    </section><!--container-fluid  ends here-->\n\n    \n    \n<!--Carousel Wrapper-->\n\n    \n<!--footer-->\n<footer class=\"page-footer font-small stylish-color-dark pt-4\">\n\n    <!-- Footer row1 -->\n    <div class=\"container text-center text-md-left\">\n    \n        <!-- Grid row -->\n        <div class=\"row\">\n    \n        <!-- Grid text-column -->\n        <div class=\"col-md-4 mx-auto\">\n            <!-- Content -->\n            <p class=\"mt-3 mb-4 foot-text\">\n            Great design isn’t just my job, it’s also my passion.\n            I write about design on Medium, and share my work on my Instagram, Dribbble, and Behance accounts. \n            <p class=\"foot-text\">\n            I also share work and articles that inspire me on Twitter and Facebook.\n            If you want to follow along or <b>say hi, please do!</b>\n            </p>\n        </div>\n    \n        <!-- Grid text-column  ends here-->\n\n        <!-- Grid address-column -->\n        <div class=\"col-md-4 mx-auto\" style=\"background-color: #ffcc00;\">\n            <h5 class=\"font-weight-bold  text-center text-uppercase mt-4 mb-4\">Address</h5>\n    \n            <p class=\"foot-text mt-5 mb-3 text-center\">\n            <b>Hotel Hibiscus Inn</b>, Kormangla,Bangalore,Karnataka, India.\n            </p>\n        </div>\n        <!-- Grid address-column ends here-->\n    \n        <hr class=\"clearfix w-100 d-md-none\">\n    \n        <!-- Grid map-column -->\n        <div class=\"col-md-4 mx-auto\">\n    \n            <!--Google map-->\n            <div class=\"z-depth-1-half map-container-5\" style=\"height: 300px\">\n                <iframe src=\"https://maps.google.com/maps?q=Hotel%20Hibiscus%20Inn%2C%20&t=&z=13&ie=UTF8&iwloc=&output=embed\"\n                style=\"border:0\" allowfullscreen>\n                </iframe>\n            </div>\n            <!--google map end-->\n        </div>\n        <!--grid map-column end-->\n        </div>\n        <!-- Grid row end-->\n\n    </div>\n    <!-- Footer row1 end -->\n    \n    <hr>\n\n    <!-- mail-me action -->\n    <ul class=\"list-unstyled text-center py-2\">\n        <li>\n        <h5 class=\"mb-1\">I'm currently available for new projects</h5>\n        <p>Let's discuss how can I help you.</p>\n        </li>\n        <li>\n        <a href=\"#\" class=\"btn btn-success btn-rounded\">Mail Me</a>\n        </li>\n    </ul>\n    <!-- mail-me action ends here-->\n\n<!-- Social buttons -->\n<ul class=\"list-unstyled list-inline text-center social-list\" id=\"connect\">\n    <li class=\"list-inline-item\">\n    <a class=\"btn-floating btn-behance mx-1\">\n        <i class=\"fab fa-behance\"> </i>\n    </a>\n    </li>\n    <li class=\"list-inline-item\">\n        <a class=\"btn-floating btn-li mx-1\">\n        <i class=\"fab fa-linkedin-in\"> </i>\n        </a>\n    </li>\n    <li class=\"list-inline-item\">\n    <a class=\"btn-floating btn-fb mx-1\">\n        <i class=\"fab fa-facebook-f\"> </i>\n    </a>\n    </li>\n    <li class=\"list-inline-item\">\n    <a class=\"btn-floating btn-git mx-1\">\n        <i class=\"fab fa-github\"> </i>\n    </a>\n    </li> \n    <li class=\"list-inline-item\">\n        <a class=\"btn-floating btn-insta mx-1\">\n        <i class=\"fab fa-instagram\"></i>\n        </a>\n    </li>\n</ul>\n<!-- Social buttons  ends here-->\n\n<!-- Copyright section -->\n<div class=\"footer-copyright text-center py-3\">Copyright © 2019\n    <a href=\"#\"> Nagar.com</a>\n</div>\n<!-- Copyright section ends here-->\n\n</footer>\n\n\n\n\n\n\n<router-outlet></router-outlet>");

/***/ }),

/***/ "./node_modules/tslib/tslib.es6.js":
/*!*****************************************!*\
  !*** ./node_modules/tslib/tslib.es6.js ***!
  \*****************************************/
/*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __exportStar, __values, __read, __spread, __spreadArrays, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__extends", function() { return __extends; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__assign", function() { return __assign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__rest", function() { return __rest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__decorate", function() { return __decorate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__param", function() { return __param; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__metadata", function() { return __metadata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__awaiter", function() { return __awaiter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__generator", function() { return __generator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__exportStar", function() { return __exportStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__values", function() { return __values; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__read", function() { return __read; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spread", function() { return __spread; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spreadArrays", function() { return __spreadArrays; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__await", function() { return __await; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function() { return __asyncGenerator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function() { return __asyncDelegator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncValues", function() { return __asyncValues; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function() { return __makeTemplateObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importStar", function() { return __importStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importDefault", function() { return __importDefault; });
/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return extendStatics(d, b);
};

function __extends(d, b) {
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    }
    return __assign.apply(this, arguments);
}

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
}

function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

function __exportStar(m, exports) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}

function __values(o) {
    var m = typeof Symbol === "function" && o[Symbol.iterator], i = 0;
    if (m) return m.call(o);
    return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
}

function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};

function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result.default = mod;
    return result;
}

function __importDefault(mod) {
    return (mod && mod.__esModule) ? mod : { default: mod };
}


/***/ }),

/***/ "./node_modules/webpack/hot sync ^\\.\\/log$":
/*!*************************************************!*\
  !*** (webpack)/hot sync nonrecursive ^\.\/log$ ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./log": "./node_modules/webpack/hot/log.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/webpack/hot sync ^\\.\\/log$";

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



const routes = [];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".nav-wrapper{\n    background-color: blueviolet;\n}\n\n#nav-logo{\n    height: auto;\n    width: 120px;\n}\n\n#nav-elements li a{\n    color: rgb(255, 255, 255);\n    font-weight: 500;\n}\n\n#nav-elements li :hover{\n    font-weight: 700;\n}\n\n.nav-link{\n    margin-left: 10px;\n}\n\nspan#nagar\n{\n  font-family: 'Comfortaa', cursive;\n  background-color: #ffcc00;\n  font-size: 2em;\n  color: black;\n}\n\n#jumbotron-content p.saying\n{\n  font-family: 'Comfortaa', cursive;\n  font-weight: 500;\n  color: rgb(253, 253, 253);\n}\n\n/*Jumnotron css*/\n\n.jumbotron {\n  position:relative;\n  height: 100vh;\n  width: 100%;\n  overflow:hidden;\n}\n\n.jumbotron .container {\n  position:relative;\n  z-index:2;\n  width: 50%;\n  margin-left: 5%;\n  margin-top: 45px;\n  background:rgba(177, 141, 240, 0.685);\n  padding:2rem;\n  border:1px solid rgba(168, 166, 166, 0.1);\n  border-radius:3px;\n}\n\n.text-white .display-4\n{\n  font-family: 'Comfortaa', cursive;\n  color: rgb(255, 255, 255);\n  font-size: 1.5em;\n}\n\n.sub-text\n{\n  font-family: 'Comfortaa', cursive;\n  font-size: 1.5em;\n  color: rgb(255, 255, 255);\n  \n}\n\n.jumbotron-background {\n  -o-object-fit: scale-down;\n     object-fit: scale-down;\n  position: absolute;\n  top:0px;\n  z-index:1;\n  width:100%;\n  height:100%;\n  opacity:0.8;\n}\n\nimg.j-image\n{\n  width: 100%;\n  height: 70%;\n  \n}\n\n/*jumbotron css ends here*/\n\ndiv#info-left\n{\n  padding: 5rem 3rem;\n  text-align: center;\n  font-family: 'Montserrat', sans-serif;\n}\n\ndiv#info\n{\n  margin-bottom: 2rem;\n}\n\n#info-right\n{\n  background-color: #673ab7;\n  \n}\n\n#info-list li\n{\n  list-style-type:circle;\n  font-weight: bold;\n  font-family: 'Comfortaa', cursive;\n  padding: 5px;\n  margin-left: 30px;\n  color: #ffffffee;\n  \n}\n\n#info-right ul\n{\n  padding: 2.5rem;\n  line-height: 20px;\n}\n\nh2#question\n{\n  font-size: 5em;\n  \n}\n\n#some-more\n{\n  background-color: #673ab7;\n}\n\n#some-more h1\n{\n  font-family: 'Montserrat', sans-serif;\n  color:#ffffffee;\n  font-size: 4em;\n  text-align: center;\n  padding:7rem;\n  margin: 0;\n  font-weight: 500;\n}\n\nhtml,\nbody,\n.full-page\n{\n  height: 100%;\n}\n\n#demo-button{\n  position: fixed;\n  right: 20px;\n  bottom: 20px;\n  width: 80px;\n  height: 80px;\n  background-color: #ffffff;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  box-shadow: 0 4px 8px 0 rgba(94, 94, 95, 0.486), 0 6px 20px 0 rgba(86, 60, 98, 0.19);\n  z-index: 12;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n\n#demo-button :hover{\n  width: 50px;\n  height: 50px;\n}\n\n#demo-button-image{\n  height: 56px;\n  width: 56px;\n}\n\n.foot-text\n{\n  font-family: 'Montserrat';\n}\n\n.map-container-5\n{\n  overflow:hidden;\n  padding-bottom:56.25%;\n  position:relative;\n  height:0;\n}\n\n.map-container-5 iframe\n{\n  left:0;\n  top:0;\n  height:100%;\n  width:100%;\n  position:absolute;\n}\n\n.social-list>li>a\n{\n  display: block;\n  text-align: center;\n  margin: auto;\n  text-decoration: none;\n  width: 30px;\n  padding: 5px;\n  \n  border-radius: 50%;\n}\n\n/*social links effects*/\n\n.social-list>li>a.btn-behance:hover\n{\n  color: white;\n  background-color:#053eff; \n}\n\n.social-list>li>a.btn-insta:hover\n{\n  color:white;\n  background: radial-gradient(circle at 30% 107%, #fdf497 0%, #fdf497 5%, #fd5949 45%,#d6249f 60%,#285AEB 90%);\n}\n\n.social-list>li>a.btn-fb:hover\n{\n  color: white;\n  background-color: #3B5998; \n}\n\n.social-list>li>a.btn-git:hover\n{\n  color: white ;\n  background-color: #333333; \n}\n\n.social-list>li>a.btn-li:hover\n{\n  color:white;\n  background-color: #007bb5; \n}\n\n/* typewriter effect */\n\n.css-typing p {\n  border-right: .15em solid orange;\n  font-family: \"Courier\";\n  font-size: 14px;\n  white-space: nowrap;\n  overflow: hidden;\n}\n\n.css-typing p:nth-child(1) {\n  width: 7.3em;\n  -webkit-animation: type 2s steps(40, end);\n  animation: type 2s steps(40, end);\n  -webkit-animation-fill-mode: forwards;\n  animation-fill-mode: forwards;\n}\n\n.css-typing p:nth-child(2) {\n  width: 100%;\n  opacity: 0;\n  -webkit-animation: type2 2s steps(40, end);\n  animation: type2 2s steps(40, end);\n  -webkit-animation-delay: 2s;\n  animation-delay: 2s;\n  -webkit-animation-fill-mode: forwards;\n  animation-fill-mode: forwards;\n}\n\n.css-typing p:nth-child(3) {\n  width: auto;\n  opacity: 0;\n  -webkit-animation: type3 5s steps(20, end), blink .5s step-end infinite alternate;\n  animation: type3 5s steps(20, end), blink .5s step-end infinite alternate;\n  -webkit-animation-delay: 4s;\n  animation-delay: 4s;\n  -webkit-animation-fill-mode: forwards;\n  animation-fill-mode: forwards;\n}\n\n@keyframes type {\n  0% {\n    width: 0;\n  }\n  99.9% {\n    border-right: .15em solid orange;\n  }\n  100% {\n    border: none;\n  }\n}\n\n@-webkit-keyframes type {\n  0% {\n    width: 0;\n  }\n  99.9% {\n    border-right: .15em solid orange;\n  }\n  100% {\n    border: none;\n  }\n}\n\n@keyframes type2 {\n  0% {\n    width: 0;\n  }\n  1% {\n    opacity: 1;\n  }\n  99.9% {\n    border-right: .15em solid orange;\n  }\n  100% {\n    opacity: 1;\n    border: none;\n  }\n}\n\n@-webkit-keyframes type2 {\n  0% {\n    width: 0;\n  }\n  1% {\n    opacity: 1;\n  }\n  99.9% {\n    border-right: .15em solid orange;\n  }\n  100% {\n    opacity: 1;\n    border: none;\n  }\n}\n\n@keyframes type3 {\n  0% {\n    width: 0;\n  }\n  1% {\n    opacity: 1;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n\n@-webkit-keyframes type3 {\n  0% {\n    width: 0;\n  }\n  1% {\n    opacity: 1;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n\n@keyframes blink {\n  50% {\n    border-color: transparent;\n  }\n}\n\n@-webkit-keyframes blink {\n  50% {\n    border-color: tranparent;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSw0QkFBNEI7QUFDaEM7O0FBRUE7SUFDSSxZQUFZO0lBQ1osWUFBWTtBQUNoQjs7QUFDQTtJQUNJLHlCQUF5QjtJQUN6QixnQkFBZ0I7QUFDcEI7O0FBQ0E7SUFDSSxnQkFBZ0I7QUFDcEI7O0FBQ0E7SUFDSSxpQkFBaUI7QUFDckI7O0FBR0E7O0VBRUUsaUNBQWlDO0VBQ2pDLHlCQUF5QjtFQUN6QixjQUFjO0VBQ2QsWUFBWTtBQUNkOztBQUNBOztFQUVFLGlDQUFpQztFQUNqQyxnQkFBZ0I7RUFDaEIseUJBQXlCO0FBQzNCOztBQUVBLGdCQUFnQjs7QUFDaEI7RUFDRSxpQkFBaUI7RUFDakIsYUFBYTtFQUNiLFdBQVc7RUFDWCxlQUFlO0FBQ2pCOztBQUVBO0VBQ0UsaUJBQWlCO0VBQ2pCLFNBQVM7RUFDVCxVQUFVO0VBQ1YsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixxQ0FBcUM7RUFDckMsWUFBWTtFQUNaLHlDQUF5QztFQUN6QyxpQkFBaUI7QUFDbkI7O0FBQ0E7O0VBRUUsaUNBQWlDO0VBQ2pDLHlCQUF5QjtFQUN6QixnQkFBZ0I7QUFDbEI7O0FBRUE7O0VBRUUsaUNBQWlDO0VBQ2pDLGdCQUFnQjtFQUNoQix5QkFBeUI7O0FBRTNCOztBQUdBO0VBQ0UseUJBQXNCO0tBQXRCLHNCQUFzQjtFQUN0QixrQkFBa0I7RUFDbEIsT0FBTztFQUNQLFNBQVM7RUFDVCxVQUFVO0VBQ1YsV0FBVztFQUNYLFdBQVc7QUFDYjs7QUFFQTs7RUFFRSxXQUFXO0VBQ1gsV0FBVzs7QUFFYjs7QUFDQSwwQkFBMEI7O0FBRTFCOztFQUVFLGtCQUFrQjtFQUNsQixrQkFBa0I7RUFDbEIscUNBQXFDO0FBQ3ZDOztBQUNBOztFQUVFLG1CQUFtQjtBQUNyQjs7QUFFQTs7RUFFRSx5QkFBeUI7O0FBRTNCOztBQUNBOztFQUVFLHNCQUFzQjtFQUN0QixpQkFBaUI7RUFDakIsaUNBQWlDO0VBQ2pDLFlBQVk7RUFDWixpQkFBaUI7RUFDakIsZ0JBQWdCOztBQUVsQjs7QUFDQTs7RUFFRSxlQUFlO0VBQ2YsaUJBQWlCO0FBQ25COztBQUNBOztFQUVFLGNBQWM7O0FBRWhCOztBQUdBOztFQUVFLHlCQUF5QjtBQUMzQjs7QUFDQTs7RUFFRSxxQ0FBcUM7RUFDckMsZUFBZTtFQUNmLGNBQWM7RUFDZCxrQkFBa0I7RUFDbEIsWUFBWTtFQUNaLFNBQVM7RUFDVCxnQkFBZ0I7QUFDbEI7O0FBRUE7Ozs7RUFJRSxZQUFZO0FBQ2Q7O0FBRUE7RUFDRSxlQUFlO0VBQ2YsV0FBVztFQUNYLFlBQVk7RUFDWixXQUFXO0VBQ1gsWUFBWTtFQUNaLHlCQUF5QjtFQUN6QixrQkFBa0I7RUFDbEIsYUFBYTtFQUNiLG1CQUFtQjtFQUNuQix1QkFBdUI7RUFDdkIsb0ZBQW9GO0VBQ3BGLFdBQVc7RUFDWCxvQkFBaUI7S0FBakIsaUJBQWlCO0FBQ25COztBQUVBO0VBQ0UsV0FBVztFQUNYLFlBQVk7QUFDZDs7QUFFQTtFQUNFLFlBQVk7RUFDWixXQUFXO0FBQ2I7O0FBR0E7O0VBRUUseUJBQXlCO0FBQzNCOztBQUVBOztFQUVFLGVBQWU7RUFDZixxQkFBcUI7RUFDckIsaUJBQWlCO0VBQ2pCLFFBQVE7QUFDVjs7QUFDQTs7RUFFRSxNQUFNO0VBQ04sS0FBSztFQUNMLFdBQVc7RUFDWCxVQUFVO0VBQ1YsaUJBQWlCO0FBQ25COztBQUVBOztFQUVFLGNBQWM7RUFDZCxrQkFBa0I7RUFDbEIsWUFBWTtFQUNaLHFCQUFxQjtFQUNyQixXQUFXO0VBQ1gsWUFBWTs7RUFFWixrQkFBa0I7QUFDcEI7O0FBRUEsdUJBQXVCOztBQUN2Qjs7RUFFRSxZQUFZO0VBQ1osd0JBQXdCO0FBQzFCOztBQUNBOztFQUVFLFdBQVc7RUFDWCw0R0FBNEc7QUFDOUc7O0FBQ0E7O0VBRUUsWUFBWTtFQUNaLHlCQUF5QjtBQUMzQjs7QUFDQTs7RUFFRSxhQUFhO0VBQ2IseUJBQXlCO0FBQzNCOztBQUNBOztFQUVFLFdBQVc7RUFDWCx5QkFBeUI7QUFDM0I7O0FBRUEsc0JBQXNCOztBQUN0QjtFQUNFLGdDQUFnQztFQUNoQyxzQkFBc0I7RUFDdEIsZUFBZTtFQUNmLG1CQUFtQjtFQUNuQixnQkFBZ0I7QUFDbEI7O0FBQ0E7RUFDRSxZQUFZO0VBQ1oseUNBQXlDO0VBQ3pDLGlDQUFpQztFQUNqQyxxQ0FBcUM7RUFDckMsNkJBQTZCO0FBQy9COztBQUVBO0VBQ0UsV0FBVztFQUNYLFVBQVU7RUFDViwwQ0FBMEM7RUFDMUMsa0NBQWtDO0VBQ2xDLDJCQUEyQjtFQUMzQixtQkFBbUI7RUFDbkIscUNBQXFDO0VBQ3JDLDZCQUE2QjtBQUMvQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxVQUFVO0VBQ1YsaUZBQWlGO0VBQ2pGLHlFQUF5RTtFQUN6RSwyQkFBMkI7RUFDM0IsbUJBQW1CO0VBQ25CLHFDQUFxQztFQUNyQyw2QkFBNkI7QUFDL0I7O0FBRUE7RUFDRTtJQUNFLFFBQVE7RUFDVjtFQUNBO0lBQ0UsZ0NBQWdDO0VBQ2xDO0VBQ0E7SUFDRSxZQUFZO0VBQ2Q7QUFDRjs7QUFFQTtFQUNFO0lBQ0UsUUFBUTtFQUNWO0VBQ0E7SUFDRSxnQ0FBZ0M7RUFDbEM7RUFDQTtJQUNFLFlBQVk7RUFDZDtBQUNGOztBQUVBO0VBQ0U7SUFDRSxRQUFRO0VBQ1Y7RUFDQTtJQUNFLFVBQVU7RUFDWjtFQUNBO0lBQ0UsZ0NBQWdDO0VBQ2xDO0VBQ0E7SUFDRSxVQUFVO0lBQ1YsWUFBWTtFQUNkO0FBQ0Y7O0FBRUE7RUFDRTtJQUNFLFFBQVE7RUFDVjtFQUNBO0lBQ0UsVUFBVTtFQUNaO0VBQ0E7SUFDRSxnQ0FBZ0M7RUFDbEM7RUFDQTtJQUNFLFVBQVU7SUFDVixZQUFZO0VBQ2Q7QUFDRjs7QUFFQTtFQUNFO0lBQ0UsUUFBUTtFQUNWO0VBQ0E7SUFDRSxVQUFVO0VBQ1o7RUFDQTtJQUNFLFVBQVU7RUFDWjtBQUNGOztBQUVBO0VBQ0U7SUFDRSxRQUFRO0VBQ1Y7RUFDQTtJQUNFLFVBQVU7RUFDWjtFQUNBO0lBQ0UsVUFBVTtFQUNaO0FBQ0Y7O0FBRUE7RUFDRTtJQUNFLHlCQUF5QjtFQUMzQjtBQUNGOztBQUNBO0VBQ0U7SUFDRSx3QkFBd0I7RUFDMUI7QUFDRiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm5hdi13cmFwcGVye1xuICAgIGJhY2tncm91bmQtY29sb3I6IGJsdWV2aW9sZXQ7XG59XG5cbiNuYXYtbG9nb3tcbiAgICBoZWlnaHQ6IGF1dG87XG4gICAgd2lkdGg6IDEyMHB4O1xufVxuI25hdi1lbGVtZW50cyBsaSBhe1xuICAgIGNvbG9yOiByZ2IoMjU1LCAyNTUsIDI1NSk7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cbiNuYXYtZWxlbWVudHMgbGkgOmhvdmVye1xuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG59XG4ubmF2LWxpbmt7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG59XG5cblxuc3BhbiNuYWdhclxue1xuICBmb250LWZhbWlseTogJ0NvbWZvcnRhYScsIGN1cnNpdmU7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmNjMDA7XG4gIGZvbnQtc2l6ZTogMmVtO1xuICBjb2xvcjogYmxhY2s7XG59XG4janVtYm90cm9uLWNvbnRlbnQgcC5zYXlpbmdcbntcbiAgZm9udC1mYW1pbHk6ICdDb21mb3J0YWEnLCBjdXJzaXZlO1xuICBmb250LXdlaWdodDogNTAwO1xuICBjb2xvcjogcmdiKDI1MywgMjUzLCAyNTMpO1xufVxuXG4vKkp1bW5vdHJvbiBjc3MqL1xuLmp1bWJvdHJvbiB7XG4gIHBvc2l0aW9uOnJlbGF0aXZlO1xuICBoZWlnaHQ6IDEwMHZoO1xuICB3aWR0aDogMTAwJTtcbiAgb3ZlcmZsb3c6aGlkZGVuO1xufVxuXG4uanVtYm90cm9uIC5jb250YWluZXIge1xuICBwb3NpdGlvbjpyZWxhdGl2ZTtcbiAgei1pbmRleDoyO1xuICB3aWR0aDogNTAlO1xuICBtYXJnaW4tbGVmdDogNSU7XG4gIG1hcmdpbi10b3A6IDQ1cHg7XG4gIGJhY2tncm91bmQ6cmdiYSgxNzcsIDE0MSwgMjQwLCAwLjY4NSk7XG4gIHBhZGRpbmc6MnJlbTtcbiAgYm9yZGVyOjFweCBzb2xpZCByZ2JhKDE2OCwgMTY2LCAxNjYsIDAuMSk7XG4gIGJvcmRlci1yYWRpdXM6M3B4O1xufVxuLnRleHQtd2hpdGUgLmRpc3BsYXktNFxue1xuICBmb250LWZhbWlseTogJ0NvbWZvcnRhYScsIGN1cnNpdmU7XG4gIGNvbG9yOiByZ2IoMjU1LCAyNTUsIDI1NSk7XG4gIGZvbnQtc2l6ZTogMS41ZW07XG59XG5cbi5zdWItdGV4dFxue1xuICBmb250LWZhbWlseTogJ0NvbWZvcnRhYScsIGN1cnNpdmU7XG4gIGZvbnQtc2l6ZTogMS41ZW07XG4gIGNvbG9yOiByZ2IoMjU1LCAyNTUsIDI1NSk7XG4gIFxufVxuXG5cbi5qdW1ib3Ryb24tYmFja2dyb3VuZCB7XG4gIG9iamVjdC1maXQ6IHNjYWxlLWRvd247XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOjBweDtcbiAgei1pbmRleDoxO1xuICB3aWR0aDoxMDAlO1xuICBoZWlnaHQ6MTAwJTtcbiAgb3BhY2l0eTowLjg7XG59XG5cbmltZy5qLWltYWdlXG57XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDcwJTtcbiAgXG59XG4vKmp1bWJvdHJvbiBjc3MgZW5kcyBoZXJlKi9cbiAgXG5kaXYjaW5mby1sZWZ0XG57XG4gIHBhZGRpbmc6IDVyZW0gM3JlbTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LWZhbWlseTogJ01vbnRzZXJyYXQnLCBzYW5zLXNlcmlmO1xufVxuZGl2I2luZm9cbntcbiAgbWFyZ2luLWJvdHRvbTogMnJlbTtcbn1cblxuI2luZm8tcmlnaHRcbntcbiAgYmFja2dyb3VuZC1jb2xvcjogIzY3M2FiNztcbiAgXG59XG4jaW5mby1saXN0IGxpXG57XG4gIGxpc3Qtc3R5bGUtdHlwZTpjaXJjbGU7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBmb250LWZhbWlseTogJ0NvbWZvcnRhYScsIGN1cnNpdmU7XG4gIHBhZGRpbmc6IDVweDtcbiAgbWFyZ2luLWxlZnQ6IDMwcHg7XG4gIGNvbG9yOiAjZmZmZmZmZWU7XG4gIFxufVxuI2luZm8tcmlnaHQgdWxcbntcbiAgcGFkZGluZzogMi41cmVtO1xuICBsaW5lLWhlaWdodDogMjBweDtcbn1cbmgyI3F1ZXN0aW9uXG57XG4gIGZvbnQtc2l6ZTogNWVtO1xuICBcbn1cblxuXG4jc29tZS1tb3JlXG57XG4gIGJhY2tncm91bmQtY29sb3I6ICM2NzNhYjc7XG59XG4jc29tZS1tb3JlIGgxXG57XG4gIGZvbnQtZmFtaWx5OiAnTW9udHNlcnJhdCcsIHNhbnMtc2VyaWY7XG4gIGNvbG9yOiNmZmZmZmZlZTtcbiAgZm9udC1zaXplOiA0ZW07XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZzo3cmVtO1xuICBtYXJnaW46IDA7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbmh0bWwsXG5ib2R5LFxuLmZ1bGwtcGFnZVxue1xuICBoZWlnaHQ6IDEwMCU7XG59XG5cbiNkZW1vLWJ1dHRvbntcbiAgcG9zaXRpb246IGZpeGVkO1xuICByaWdodDogMjBweDtcbiAgYm90dG9tOiAyMHB4O1xuICB3aWR0aDogODBweDtcbiAgaGVpZ2h0OiA4MHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBib3gtc2hhZG93OiAwIDRweCA4cHggMCByZ2JhKDk0LCA5NCwgOTUsIDAuNDg2KSwgMCA2cHggMjBweCAwIHJnYmEoODYsIDYwLCA5OCwgMC4xOSk7XG4gIHotaW5kZXg6IDEyO1xuICBvYmplY3QtZml0OiBjb3Zlcjtcbn1cblxuI2RlbW8tYnV0dG9uIDpob3ZlcntcbiAgd2lkdGg6IDUwcHg7XG4gIGhlaWdodDogNTBweDtcbn1cblxuI2RlbW8tYnV0dG9uLWltYWdle1xuICBoZWlnaHQ6IDU2cHg7XG4gIHdpZHRoOiA1NnB4O1xufVxuXG5cbi5mb290LXRleHRcbntcbiAgZm9udC1mYW1pbHk6ICdNb250c2VycmF0Jztcbn1cblxuLm1hcC1jb250YWluZXItNVxue1xuICBvdmVyZmxvdzpoaWRkZW47XG4gIHBhZGRpbmctYm90dG9tOjU2LjI1JTtcbiAgcG9zaXRpb246cmVsYXRpdmU7XG4gIGhlaWdodDowO1xufVxuLm1hcC1jb250YWluZXItNSBpZnJhbWVcbntcbiAgbGVmdDowO1xuICB0b3A6MDtcbiAgaGVpZ2h0OjEwMCU7XG4gIHdpZHRoOjEwMCU7XG4gIHBvc2l0aW9uOmFic29sdXRlO1xufVxuXG4uc29jaWFsLWxpc3Q+bGk+YVxue1xuICBkaXNwbGF5OiBibG9jaztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW46IGF1dG87XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiAgd2lkdGg6IDMwcHg7XG4gIHBhZGRpbmc6IDVweDtcbiAgXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbn1cblxuLypzb2NpYWwgbGlua3MgZWZmZWN0cyovXG4uc29jaWFsLWxpc3Q+bGk+YS5idG4tYmVoYW5jZTpob3Zlclxue1xuICBjb2xvcjogd2hpdGU7XG4gIGJhY2tncm91bmQtY29sb3I6IzA1M2VmZjsgXG59XG4uc29jaWFsLWxpc3Q+bGk+YS5idG4taW5zdGE6aG92ZXJcbntcbiAgY29sb3I6d2hpdGU7XG4gIGJhY2tncm91bmQ6IHJhZGlhbC1ncmFkaWVudChjaXJjbGUgYXQgMzAlIDEwNyUsICNmZGY0OTcgMCUsICNmZGY0OTcgNSUsICNmZDU5NDkgNDUlLCNkNjI0OWYgNjAlLCMyODVBRUIgOTAlKTtcbn1cbi5zb2NpYWwtbGlzdD5saT5hLmJ0bi1mYjpob3Zlclxue1xuICBjb2xvcjogd2hpdGU7XG4gIGJhY2tncm91bmQtY29sb3I6ICMzQjU5OTg7IFxufVxuLnNvY2lhbC1saXN0PmxpPmEuYnRuLWdpdDpob3Zlclxue1xuICBjb2xvcjogd2hpdGUgO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzMzMzMzOyBcbn1cbi5zb2NpYWwtbGlzdD5saT5hLmJ0bi1saTpob3Zlclxue1xuICBjb2xvcjp3aGl0ZTtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAwN2JiNTsgXG59XG5cbi8qIHR5cGV3cml0ZXIgZWZmZWN0ICovXG4uY3NzLXR5cGluZyBwIHtcbiAgYm9yZGVyLXJpZ2h0OiAuMTVlbSBzb2xpZCBvcmFuZ2U7XG4gIGZvbnQtZmFtaWx5OiBcIkNvdXJpZXJcIjtcbiAgZm9udC1zaXplOiAxNHB4O1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuLmNzcy10eXBpbmcgcDpudGgtY2hpbGQoMSkge1xuICB3aWR0aDogNy4zZW07XG4gIC13ZWJraXQtYW5pbWF0aW9uOiB0eXBlIDJzIHN0ZXBzKDQwLCBlbmQpO1xuICBhbmltYXRpb246IHR5cGUgMnMgc3RlcHMoNDAsIGVuZCk7XG4gIC13ZWJraXQtYW5pbWF0aW9uLWZpbGwtbW9kZTogZm9yd2FyZHM7XG4gIGFuaW1hdGlvbi1maWxsLW1vZGU6IGZvcndhcmRzO1xufVxuXG4uY3NzLXR5cGluZyBwOm50aC1jaGlsZCgyKSB7XG4gIHdpZHRoOiAxMDAlO1xuICBvcGFjaXR5OiAwO1xuICAtd2Via2l0LWFuaW1hdGlvbjogdHlwZTIgMnMgc3RlcHMoNDAsIGVuZCk7XG4gIGFuaW1hdGlvbjogdHlwZTIgMnMgc3RlcHMoNDAsIGVuZCk7XG4gIC13ZWJraXQtYW5pbWF0aW9uLWRlbGF5OiAycztcbiAgYW5pbWF0aW9uLWRlbGF5OiAycztcbiAgLXdlYmtpdC1hbmltYXRpb24tZmlsbC1tb2RlOiBmb3J3YXJkcztcbiAgYW5pbWF0aW9uLWZpbGwtbW9kZTogZm9yd2FyZHM7XG59XG5cbi5jc3MtdHlwaW5nIHA6bnRoLWNoaWxkKDMpIHtcbiAgd2lkdGg6IGF1dG87XG4gIG9wYWNpdHk6IDA7XG4gIC13ZWJraXQtYW5pbWF0aW9uOiB0eXBlMyA1cyBzdGVwcygyMCwgZW5kKSwgYmxpbmsgLjVzIHN0ZXAtZW5kIGluZmluaXRlIGFsdGVybmF0ZTtcbiAgYW5pbWF0aW9uOiB0eXBlMyA1cyBzdGVwcygyMCwgZW5kKSwgYmxpbmsgLjVzIHN0ZXAtZW5kIGluZmluaXRlIGFsdGVybmF0ZTtcbiAgLXdlYmtpdC1hbmltYXRpb24tZGVsYXk6IDRzO1xuICBhbmltYXRpb24tZGVsYXk6IDRzO1xuICAtd2Via2l0LWFuaW1hdGlvbi1maWxsLW1vZGU6IGZvcndhcmRzO1xuICBhbmltYXRpb24tZmlsbC1tb2RlOiBmb3J3YXJkcztcbn1cblxuQGtleWZyYW1lcyB0eXBlIHtcbiAgMCUge1xuICAgIHdpZHRoOiAwO1xuICB9XG4gIDk5LjklIHtcbiAgICBib3JkZXItcmlnaHQ6IC4xNWVtIHNvbGlkIG9yYW5nZTtcbiAgfVxuICAxMDAlIHtcbiAgICBib3JkZXI6IG5vbmU7XG4gIH1cbn1cblxuQC13ZWJraXQta2V5ZnJhbWVzIHR5cGUge1xuICAwJSB7XG4gICAgd2lkdGg6IDA7XG4gIH1cbiAgOTkuOSUge1xuICAgIGJvcmRlci1yaWdodDogLjE1ZW0gc29saWQgb3JhbmdlO1xuICB9XG4gIDEwMCUge1xuICAgIGJvcmRlcjogbm9uZTtcbiAgfVxufVxuXG5Aa2V5ZnJhbWVzIHR5cGUyIHtcbiAgMCUge1xuICAgIHdpZHRoOiAwO1xuICB9XG4gIDElIHtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG4gIDk5LjklIHtcbiAgICBib3JkZXItcmlnaHQ6IC4xNWVtIHNvbGlkIG9yYW5nZTtcbiAgfVxuICAxMDAlIHtcbiAgICBvcGFjaXR5OiAxO1xuICAgIGJvcmRlcjogbm9uZTtcbiAgfVxufVxuXG5ALXdlYmtpdC1rZXlmcmFtZXMgdHlwZTIge1xuICAwJSB7XG4gICAgd2lkdGg6IDA7XG4gIH1cbiAgMSUge1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cbiAgOTkuOSUge1xuICAgIGJvcmRlci1yaWdodDogLjE1ZW0gc29saWQgb3JhbmdlO1xuICB9XG4gIDEwMCUge1xuICAgIG9wYWNpdHk6IDE7XG4gICAgYm9yZGVyOiBub25lO1xuICB9XG59XG5cbkBrZXlmcmFtZXMgdHlwZTMge1xuICAwJSB7XG4gICAgd2lkdGg6IDA7XG4gIH1cbiAgMSUge1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cbiAgMTAwJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxufVxuXG5ALXdlYmtpdC1rZXlmcmFtZXMgdHlwZTMge1xuICAwJSB7XG4gICAgd2lkdGg6IDA7XG4gIH1cbiAgMSUge1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cbiAgMTAwJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxufVxuXG5Aa2V5ZnJhbWVzIGJsaW5rIHtcbiAgNTAlIHtcbiAgICBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICB9XG59XG5ALXdlYmtpdC1rZXlmcmFtZXMgYmxpbmsge1xuICA1MCUge1xuICAgIGJvcmRlci1jb2xvcjogdHJhbnBhcmVudDtcbiAgfVxufSJdfQ== */");

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let AppComponent = class AppComponent {
    constructor() {
        this.title = 'landing-page';
    }
};
AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-root',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")).default]
    })
], AppComponent);



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");





let AppModule = class AppModule {
};
AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        declarations: [
            _app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]
        ],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
            _app_routing_module__WEBPACK_IMPORTED_MODULE_3__["AppRoutingModule"]
        ],
        providers: [],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]]
    })
], AppModule);



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");





if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ 0:
/*!**********************************************************************************************************!*\
  !*** multi (webpack)-dev-server/client?http://0.0.0.0:0/sockjs-node&sockPath=/sockjs-node ./src/main.ts ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(/*! /home/cgi/virtual-productivity-assistant/angular-ui/landing-page/node_modules/webpack-dev-server/client/index.js?http://0.0.0.0:0/sockjs-node&sockPath=/sockjs-node */"./node_modules/webpack-dev-server/client/index.js?http://0.0.0.0:0/sockjs-node&sockPath=/sockjs-node");
module.exports = __webpack_require__(/*! /home/cgi/virtual-productivity-assistant/angular-ui/landing-page/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map