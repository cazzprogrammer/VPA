import { Component, OnInit, HostListener } from '@angular/core';
import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';
import * as $ from 'jquery';
import { environment } from '../../environments/environment';
import { InteractionService } from '../commmunication/interaction.service';

import { Router } from '@angular/router';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { FeedbackDialogComponent } from '../feedback-dialog/feedback-dialog.component';
import { HttpClient } from '@angular/common/http';
import { CommandService } from '../services/command.service';


@Component({
  selector: 'app-conversation',
  templateUrl: './conversation.component.html',
  styleUrls: ['./conversation.component.css']
})
export class ConversationComponent {

  private sender: string = localStorage.getItem('sender');
  private serverUrlBot = environment.URL_BOT;
  // private serverUrlBot = "http://172.23.239.93:8080/Socket";
  private serverUrlCsr = environment.URL_CSR;
  private stompClient;
  private isBot = true;
  private csrname: string;

  constructor(private router: Router, public dialog: MatDialog, public http: HttpClient,
    public commandService: CommandService) {
    // this.transfer.userevent.subscribe((data: string) => {
    //   console.log(data);
    //   this.setsender(data);
    //   console.log(this.sender)
    // })
    console.log("inside conversation constructor")
    this.initializeWebSocketConnection();
  }


  messages = [];

  addMsg(message) {

    this.messages.push(message);

  }

  initializeWebSocketConnection() {
    const ws = new SockJS(this.serverUrlBot);
    const sender = localStorage.getItem('sender');
    const recipient = localStorage.getItem('recipient');
    this.stompClient = Stomp.over(ws);
    this.stompClient.connect({}, (frame) => {

      this.stompClient.subscribe(`/message/${sender}`, (message) => {
        console.log(message, 'this is the bot reply !!');
        if (message.body) {
          const messageBody = JSON.parse(message.body);
          messageBody.orientation = 'left';
          console.log(messageBody);
          if (messageBody.type === "ANSWER") {
            this.addMsg(messageBody);
          }
          else {

            console.log("type= ", messageBody.type)//for type="task"
            localStorage.setItem('userId', 'aadil@gmail.com');
            let userId = localStorage.getItem('userId');
            this.commandService.executeCommand({
              command: messageBody.content,
              paramBody: { "userId": userId }
            }).subscribe((data: any) => {
              console.log(data);
              if(messageBody.content == "cmd/wallet"){
                let message = {
                  fromName: "BOT",
                  content: sender + ', your balance is ' + data.balance,
                  orientation: "left"
                }
                this.addMsg(message);
              }else if(messageBody.content == "cmd/invoice"){
                let message = {
                  fromName: "BOT",
                  content: sender + ', your last transaction: ' + data.amount + " " +  data.type,
                  orientation: "left"
                }
                this.addMsg(message);
              }

            })

          }
        }
      });

      // var chatMessage = {
      //   fromName : sender,
      //   type : 'newUser'
      //    };
      // this.stompClient.send(`/app/chat.sendMessage/alert`, {}, JSON.stringify(chatMessage));
      $('#chat-with').text('Talking To BOT');
    });

  }




  talkToCsr() {
    $("#input").prop("disabled", true);
    this.isBot = false;
    $('#talk-to-csr').addClass('hideButton');
    const ws2 = new SockJS(this.serverUrlCsr);
    this.stompClient = Stomp.over(ws2);


    const sender = localStorage.getItem('sender');

    this.stompClient.connect({}, (frame) => {

      this.stompClient.subscribe(`/user/${sender}csrName/reply`, (message) => {
        this.csrname = message.body;
        console.log("csr name received: " + this.csrname);
      });

      this.stompClient.subscribe(`/user/${sender}/reply`, (message) => {

        console.log(message, 'from csr');
        if (message.body) {
          $("#input").prop("disabled", false);
          console.log();
          const messageBody = JSON.parse(message.body);
          messageBody.orientation = 'left';
          console.log(messageBody);
          this.addMsg(messageBody);
          if (messageBody.type == 'Leave') {
            this.openDialog();
          }
        }
      });
      const chatMessage = {
        fromName: sender,
        type: 'newUser'
      };
      this.stompClient.send(`/app/chat.sendMessage/alert`, {}, JSON.stringify(chatMessage));

    });
    $('#chat-with').text('Talking To CSR');
  }


  sendMessage(message) {
    const sender = localStorage.getItem('sender');
    const recipient = localStorage.getItem('recipient');

    const messageTemplate = {
      content: message,
      fromName: sender,
      toName: this.csrname,
      type: 'CHAT',
      orientation: ''
    };
    if (this.isBot == true) {
      messageTemplate.toName = 'bot';
      this.stompClient.send(`/app/chat.sendMessage/${sender}/bot`, {}, JSON.stringify(messageTemplate));
    }
    else {
      this.stompClient.send(`/app/chat.sendMessage/toCsr/${sender}/${this.csrname}`, {}, JSON.stringify(messageTemplate));
    }
    $('input').val('');
    messageTemplate.orientation = 'right';
    console.log(messageTemplate);
    this.addMsg(messageTemplate);



  }
  logout() {
    localStorage.setItem('token', "aman");
    this.route();
  }

  route() {
    this.router.navigateByUrl('/login');
  }

  openDialog() {
    this.csrname = null;
    let dialogRef = this.dialog.open(FeedbackDialogComponent, { panelClass: 'custom-dialog-container' });
    dialogRef.afterClosed().subscribe(result => {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.data = {
        csr_userid: 'tej',
        feedbackResponse: result
      };
      console.log(dialogConfig.data);
      this.http.post("http://15.206.110.2:8083/feedback", dialogConfig.data);
    });
  }

  @HostListener('window:beforeunload', ['$event'])
  beforeunloadHandler(event) {
    const sender = localStorage.getItem('sender');
    const recipient = this.csrname;
    const chatMessage = {
      fromName: 'SYSTEM',
      toName: recipient,
      type: 'Leave',
      content: sender + ' has left the chat'
    };
    this.stompClient.send(`/app/chat.sendMessage/toCsr/${sender}/${recipient}`, {}, JSON.stringify(chatMessage));
    return null;

  }

}
