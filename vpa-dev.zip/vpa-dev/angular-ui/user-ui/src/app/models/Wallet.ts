export class Wallet{
    userId: string;
    balance: number;
}