export class Invoice{
    // private String transactionID;
    // private String userID;
    // private String bookingID;
    // private double amount;
    // private LocalDateTime timeStamp;
    // private type type;
    // public enum type{
    //     CREDIT,
    //     DEBIT
    // }
    transactionID: string;
    userID: string;
    bookingID: string;
    amount: number;
    timeStamp: string;
    type: string;
}