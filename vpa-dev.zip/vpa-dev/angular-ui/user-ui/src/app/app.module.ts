import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule, routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material/material.module';
import { HttpClientModule } from '@angular/common/http';
import { SigninComponent } from './signin/signin.component';
import { JwtHelperService, JwtModule, JwtModuleOptions } from '@auth0/angular-jwt';
import { AuthguardService } from './guards/authguard.service';
import { AuthService } from './guards/auth.service';
import { ConversationComponent } from './conversation/conversation.component';
import { FeedbackDialogComponent } from './feedback-dialog/feedback-dialog.component';
import { LandingPageComponent } from './landing-page/landing-page.component';

const JWT_Module_Options: JwtModuleOptions = {
  config: { 
    tokenGetter: () => {
      return localStorage.getItem('token');
    }
  }
}

@NgModule({
  declarations: [
    AppComponent,
    SigninComponent,
    routingComponents,
    ConversationComponent,
    FeedbackDialogComponent,
    LandingPageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    FormsModule,
    HttpClientModule,    
    JwtModule.forRoot(JWT_Module_Options),
  ],
  providers: [
    AuthguardService, AuthService,JwtHelperService
  ],
  exports: [],
  entryComponents: [FeedbackDialogComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
