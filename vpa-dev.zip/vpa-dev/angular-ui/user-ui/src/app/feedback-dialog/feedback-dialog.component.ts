import { Component, OnInit} from '@angular/core';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-feedback-dialog',
  templateUrl: './feedback-dialog.component.html',
  styleUrls: ['./feedback-dialog.component.css']
})
export class FeedbackDialogComponent implements OnInit {

  constructor(private snackbar: MatSnackBar) { }

  ngOnInit() {
  }
  
  openSnackBar(message, action){
    this.snackbar.open(message, action, {duration: 3000});
  }


}
