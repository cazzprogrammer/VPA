import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ConversationComponent } from './conversation/conversation.component';
import { SigninComponent } from './signin/signin.component';
import { AuthguardService } from './guards/authguard.service';
import { LandingPageComponent } from './landing-page/landing-page.component';

const routes: Routes = [
  { path: 'login', component: SigninComponent },
  { path: 'home', component: LandingPageComponent },
  { path: 'user', component: ConversationComponent ,canActivate: [AuthguardService]},
  { path: '', redirectTo: 'home', pathMatch: 'full' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [ConversationComponent, SigninComponent]

// ,canActivate:[AuthguardService]