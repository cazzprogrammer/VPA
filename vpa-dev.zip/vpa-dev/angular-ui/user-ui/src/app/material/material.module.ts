import { NgModule } from '@angular/core';
import { MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatDividerModule,
  MatCardModule,
  MatCheckboxModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatStepperModule,
  MatChipsModule,
  MatBottomSheetModule
 } from '@angular/material';
 

 const Material=[MatTabsModule,
  MatCardModule,
  MatGridListModule,
  MatButtonModule,
  MatInputModule,
  MatListModule,
  MatIconModule,
  MatBottomSheetModule,
  MatSidenavModule,
  MatProgressSpinnerModule,
  MatTooltipModule,
  MatDialogModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDividerModule,
  MatSnackBarModule
  
 ];


@NgModule({
  declarations: [],
  imports: [Material],
  exports: [Material]
})
export class MaterialModule { }
