export const environment = {
  production: true,
  URL_BOT: 'http://15.206.110.2:8080/Socket',
  URL_CSR: 'http://15.206.110.2:8081/Socket',
  URL_LOGIN: 'http://15.206.110.2:8090/authenticate',
  URL_COMMAND_PATTERN: 'http://15.206.110.2:8086/'
};
