export const environment = {
  production: false,

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
  URL_BOT: 'http://15.206.110.2:8080/Socket',
  URL_CSR: 'http://15.206.110.2:8081/Socket',
  URL_LOGIN: 'http://15.206.110.2:8090/authenticate',
  URL_COMMAND_REGISTRY: 'http://15.206.110.2:8085/',
};
