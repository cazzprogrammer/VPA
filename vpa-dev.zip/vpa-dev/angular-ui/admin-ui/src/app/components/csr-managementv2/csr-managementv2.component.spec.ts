import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CsrManagementv2Component } from './csr-managementv2.component';

describe('CsrManagementv2Component', () => {
  let component: CsrManagementv2Component;
  let fixture: ComponentFixture<CsrManagementv2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CsrManagementv2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CsrManagementv2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
