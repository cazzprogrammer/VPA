import { Pipe, PipeTransform } from '@angular/core';
import { CSR } from '../models/csr.model';

@Pipe({
  name: 'filter'
})

export class FilterPipe implements PipeTransform {
  transform(items: CSR[], searchText: string): any[] {
    if (!items) {
      return [];
    }
    if (!searchText) {
      return items;
    }

    searchText = searchText.toLowerCase();
    return items.filter(csr => {
      return csr.firstName.toLowerCase().includes(searchText) || csr.lastName.toLowerCase().includes(searchText);
    });
  }
}
