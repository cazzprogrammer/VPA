import { Component, OnInit } from '@angular/core';
import { CSR } from '../models/csr.model';
import { CommunicationService } from 'src/app/services/communication.service';
import { Router } from '@angular/router';
import { VerificationService } from 'src/app/services/verification.service';

@Component({
  selector: 'app-list-csr',
  templateUrl: './list-csr.component.html',
  styleUrls: ['./list-csr.component.css']
})
export class ListCsrComponent implements OnInit {
  allCSR;
  searchText: string;
  constructor(private comServ: CommunicationService, private router: Router, private verificationService: VerificationService) {
    verificationService.getAllCsr().subscribe((data) =>
      this.allCSR = data
    );
  }

  // allCSR = [new CSR("95d0b001-1ca3-11ea-9840-d3650e1ea449", 'rajuchacha@kachua.co', 'Tejveer', 'Singh'),
  // new CSR("95d0b002-1ca3-11ea-9840-4f76f44c388c", 'Kachua', 'Chhap'),
  // new CSR("95d0b003-1ca3-11ea-9840-fd6fb3e9475f", 'A', 'Gupta'),
  // new CSR("95d0b004-1ca3-11ea-9840-b11121d93fbb", 'B', 'Gupta'),
  // new CSR("95d0b005-1ca3-11ea-9840-6deed1050836", 'C', 'Gupta'),
  // new CSR("95d0b006-1ca3-11ea-9840-0f30ef97ef46", 'D', 'Gupta'),
  // new CSR("95d0b007-1ca3-11ea-9840-bd131c37fe2a", 'E', 'Gupta'),
  // new CSR("95d0b008-1ca3-11ea-9840-17a727355ddb", 'F', 'Gupta'),
  // new CSR("95d0b009-1ca3-11ea-9840-3fe1323edd96", 'G', 'Gupta'),
  // new CSR("95d0b00a-1ca3-11ea-9840-b3c60607b049", 'H', 'Gupta'),
  // ];





  ngOnInit(): void {
  }

  showCSR(csr: CSR) {
    this.comServ.selectedCSR = csr;
    this.router.navigate(['/csr', csr.employeeId]);
  }

  addNewCSR() {
    this.comServ.selectedCSR = new CSR();
    this.router.navigate(['/csr']);
  }


}
