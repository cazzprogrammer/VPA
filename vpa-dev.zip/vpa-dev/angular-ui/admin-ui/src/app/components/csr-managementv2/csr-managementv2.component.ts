import { Component, OnInit, ViewChild } from '@angular/core';
import { CSR } from './models/csr.model';
import { MatDrawer, MatSidenav } from '@angular/material/sidenav';
import { ChartOptions, ChartType, ChartDataSets, ChartData } from 'chart.js';
import { Label, Color } from 'ng2-charts';
import { Router, ActivatedRoute } from '@angular/router';
import { CommunicationService } from 'src/app/services/communication.service';
import { ReportService } from 'src/app/services/report.service';
import { Report } from './models/report.model';
import { VerificationService } from 'src/app/services/verification.service';

@Component({
  selector: 'app-csr-managementv2',
  templateUrl: './csr-managementv2.component.html',
  styleUrls: ['./csr-managementv2.component.css']
})
export class CsrManagementv2Component implements OnInit {
  constructor(private route: ActivatedRoute, private comServ: CommunicationService,
    private reportService: ReportService, private verificationService: VerificationService, private router: Router) { }
  disabled = true;
  selectedCSR = new CSR();

  // BAR CHART (AVERAGE TIME TO RESOLVE QUERIES (IN SECONDS) AND AVERAGE RATING)
  public barChartOptions: ChartOptions = {
    responsive: true,
  };
  public timeBarChartLabels: Label[];
  public ratingBarChartLabels: Label[];
  public barChartType: ChartType = 'bar';
  public barChartLegend = true;
  public barChartPlugins = [];
  public timeframe = 1;

  public ratingBarChartData: ChartDataSets[];
  public timeBarChartData: ChartDataSets[];

  // LINE CHART FOR TIME FOR EACH QUERY FOR EACH CSR
  public lineChartData: ChartDataSets[];
  public lineChartLabels: Label[];

  public lineChartOptions;

  public lineChartColors: Color[] = [
    {
      borderColor: 'black',
      backgroundColor: 'rgba(255,0,0,0.3)',
    },
  ];
  public lineChartLegend = true;
  public lineChartType = 'line';
  public lineChartPlugins = [];

  reports: Report[];

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.selectedCSR = this.comServ.selectedCSR;
      console.log(this.selectedCSR);
      if (this.selectedCSR.employeeId !== undefined) {
        console.log('getting employee details');
        this.setGraphData();
        this.getEmployee();

      } else {
        console.log('adding new csr');
        this.AddNewCsr();
      }

    });

  }





  setGraphData() {
    this.ratingBarChartLabels = ['All CSR', this.selectedCSR.firstName + this.selectedCSR.lastName];
    this.ratingBarChartData = [
      { data: [56, 33, 0], label: 'Positive' },
      { data: [45, 23, 0], label: 'Negative' }
    ];
    this.timeBarChartLabels = ['Average Time to Resolve Queries'];
    this.timeBarChartData = [
      { data: [33, 0], label: 'All CSR' },
      { data: [54, 0], label: this.selectedCSR.firstName + this.selectedCSR.lastName }
    ];

    this.lineChartData = [
      { data: [65, 59, 80, 81, 56, 55, 40, 0], label: 'Time / Query' }];

    const query = ['How to generate an Invoice', 'How to kill a deer', 'How to hide a dead body ? Asking for a friend',
      'How to complete GOT in 1 day', 'How to drink your own pee to survive', 'How to drink someone else\'s pee to survive?',
      'Am I a unique snowflake ?'];
    this.lineChartLabels = ['1', '2', '3', '4', '5', '6', '7'];

    this.lineChartOptions = {
      responsive: true,
      tooltips: {
        enabled: true,
        mode: 'single',
        callbacks: {
          label(tooltipItems, data) {
            const multistringText = ['Rating ' + tooltipItems.yLabel];
            multistringText.push('Query: ' + query[tooltipItems.index]);
            return multistringText;
          }
        }
      },
    };
  }











  getEmployee() {
    this.disabled = true;
    // this.setBarChartData();

    this.setLineChartData();

    this.ratingBarChartLabels = ['All CSR', this.selectedCSR.firstName + this.selectedCSR.lastName];
    this.ratingBarChartData = [
      { data: [56, 33, 0], label: 'Positive' },
      { data: [45, 23, 0], label: 'Negative' }
    ];
    this.timeBarChartLabels = ['Average Time to Resolve Queries'];
    this.timeBarChartData = [
      { data: [33, 0], label: 'All CSR' },
      { data: [54, 0], label: this.selectedCSR.firstName + this.selectedCSR.lastName }
    ];

    this.lineChartData = [
      { data: [65, 59, 80, 81, 56, 55, 40, 0], label: 'Time / Query' }];

    const query = ['How to generate an Invoice', 'How to kill a deer', 'How to hide a dead body ? Asking for a friend',
      'How to complete GOT in 1 day', 'How to drink your own pee to survive', 'How to drink someone else\'s pee to survive?',
      'Am I a unique snowflake ?'];
    this.lineChartLabels = ['1', '2', '3', '4', '5', '6', '7'];

    this.lineChartOptions = {
      responsive: true,
      tooltips: {
        enabled: true,
        mode: 'single',
        callbacks: {
          label(tooltipItems, data) {
            const multistringText = ['Rating ' + tooltipItems.yLabel];
            multistringText.push('Query: ' + query[tooltipItems.index]);
            return multistringText;
          }
        }
      },
    };

  }

  setBarChartData() {
    let username = this.selectedCSR.username;
    const toDate: Date = new Date();
    const fromDate: Date = new Date();
    fromDate.setMonth(fromDate.getMonth() - this.timeframe);
    console.log(fromDate, toDate);
    this.reportService.getReportsOfCSR(fromDate.getTime(), toDate.getTime()).subscribe((data: Report[]) => {
      this.reports = data;
      console.log(this.reports);
      let postiveRatingOfAllCSR = 0;
      let negativeRatingOfAllCSR = 0;
      let postiveRatingOfSelectedCSR = 0;
      let negativeRatingOfSelectedCSR = 0;

      let totalTicketsResolvedByAllCSR = 0;
      let totalTicketsResolvedBySelectedCSR = 0;

      let totalTimeToResolveAllCSR = 0;
      let totalTimeToResolveSelectedCSR = 0;

      this.reports.forEach(report => {
        if (report.interactions.length >= 2) {
          postiveRatingOfAllCSR += report.feedback === 'True' ? 1 : 0;
          negativeRatingOfAllCSR += report.feedback === ('False' || 'false') ? 1 : 0;


          if (report.resolvedBy === 'CSR') {
            totalTimeToResolveAllCSR += new Date(report.interactions[1].releaseTime).getTime() - new Date(report.interactions[1].catchTime).getTime();
            // time in milliseconds
            totalTicketsResolvedByAllCSR += 1;
            if (report.interactions[1].username === username) {
              totalTicketsResolvedBySelectedCSR += 1;
              totalTimeToResolveSelectedCSR += new Date(report.interactions[1].releaseTime).getTime() - new Date(report.interactions[1].catchTime).getTime();
            }
          }
          if (report.interactions[1].username === username) {
            postiveRatingOfSelectedCSR += report.feedback === ('True' || 'true') ? 1 : 0;
            negativeRatingOfSelectedCSR += report.feedback === ('False' || 'false') ? 1 : 0;
          }
        }
      });

      // this.ratingBarChartLabels = ['All CSR', this.selectedCSR.firstName + this.selectedCSR.lastName];
      // this.ratingBarChartData = [
      //   { data: [postiveRatingOfAllCSR, postiveRatingOfSelectedCSR, 0], label: 'Positive' },
      //   { data: [negativeRatingOfAllCSR, negativeRatingOfSelectedCSR, 0], label: 'Negative' }
      // ];

      let numberOfCSR = 4;

      this.ratingBarChartLabels = ['Average Queries Resolved'];
      this.ratingBarChartData = [
        { data: [totalTicketsResolvedByAllCSR / 4, 0], label: 'All CSR' },
        { data: [totalTicketsResolvedBySelectedCSR, 0], label: this.selectedCSR.firstName + this.selectedCSR.lastName }
      ]


      const avgTimeToResolveAllCSR = totalTimeToResolveAllCSR / totalTicketsResolvedByAllCSR;
      const avgTimeToResolveSelectedCSR = totalTimeToResolveSelectedCSR / totalTicketsResolvedBySelectedCSR;

      this.timeBarChartLabels = ['Average Time to Resolve Queries'];
      this.timeBarChartData = [
        { data: [avgTimeToResolveAllCSR, 0], label: 'All CSR' },
        { data: [avgTimeToResolveSelectedCSR, 0], label: this.selectedCSR.firstName + this.selectedCSR.lastName }
      ];
    })

    // console.log(this.reports);


    // this.verificationService.getAllCsr().subscribe((csrList: CSR[]) => {
    //   return numberOfCSR = csrList.length;
    // });




    // for each report, extract the feedback while checking the employeeId of the report
  }

  setLineChartData() {
    let username = this.selectedCSR.username;
    const toDate: Date = new Date();
    const fromDate: Date = new Date();
    fromDate.setDate(fromDate.getDate() - 1);
    console.log(fromDate, toDate);

    let reports: Report[];

    // get all the reports of the CSR
    this.reportService.getReportsOfCSR(fromDate.getTime(), toDate.getTime()).subscribe((data: Report[]) => {
      console.log(data);
      reports = data;
      let query = new Array();
      let resolvedStatus = new Array();
      let timeTaken = new Array();


      for (let i = 0; i < reports.length; i++) {
        if (reports[i].interactions[1].username === this.selectedCSR.username) {
          query.push(reports[i].query);
          this.lineChartLabels.push(JSON.stringify(i));
          if (reports[i].status === 'RESOLVED') {
            resolvedStatus.push('resolved');
          } else {
            resolvedStatus.push('unresolved');
          }
          if (reports[i].interactions.length >= 2) {
            console.log(reports[i].interactions[1].catchTime)
            console.log(reports[i].interactions[1].releaseTime)
            timeTaken.push(new Date(reports[i].interactions[1].releaseTime).getTime() - new Date(reports[i].interactions[1].catchTime).getTime());
            // timeTaken.push(new Date(reports[i].interactions[1].releaseTime).getTime() - new Date(reports[i].interactions[1].releaseTime).getTime());
          }
        }
      
      }

      console.log('query')
      console.log(query);
      console.log(resolvedStatus);
      console.log(timeTaken);


      this.lineChartData = [
        { data: timeTaken, label: 'Time / Query' }];

      this.lineChartOptions = {
        responsive: true,
        tooltips: {
          enabled: true,
          mode: 'single',
          callbacks: {
            label(tooltipItems, data) {
              const multistringText = ['Time Taken: ' + tooltipItems.yLabel];
              multistringText.push('Query: ' + query[tooltipItems.index]);
              multistringText.push('Status: ' + resolvedStatus[tooltipItems.index]);
              return multistringText;
            }
          }
        },
      };
    });

  }

  onSave() {
    if (this.selectedCSR.employeeId === undefined) {
      // make a post request
      console.log(this.selectedCSR);
      this.verificationService.addNewEmployee(this.selectedCSR);
    } else {
      console.log(this.selectedCSR);
      this.verificationService.updateEmployee(this.selectedCSR);
    }
    this.router.navigateByUrl('list-csr');

  }

  AddNewCsr() {
    console.log('adding new csr');
    this.disabled = false;
  }
}
