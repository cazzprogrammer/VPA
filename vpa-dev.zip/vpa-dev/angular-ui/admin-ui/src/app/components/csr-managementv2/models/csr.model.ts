export class CSR {
    constructor(public employeeId?: string,
        public emailId?: string,
        public firstName?: string,
        public lastName?: string,
        public birthDate?: Date,
        public gender?: string,
        public address?: string,
        public username?: string,
        public password?: string,
        public role = 'CSR') {
    }
}
