
export class Report {

    constructor(
        public reportID?: string,
        public ticketID?: string,
        public query?: string,
        public intent?: string,
        public raisedBy?: string,
        public createdOn?: Date,
        public interactions?: Interaction[],
        public type?: string,
        public feedback?: string,
        public commandUsed?: string,
        public status?: string,
        public lastUpdatedBy?: string,
        public lastUpdateOn?: Date,
        public resolvedBy?: string,
        public resolvedOn?: Date
    ) {

    }
}

export class Interaction {
    constructor(public username?: string, public summary?: string, public catchTime?: Date, public releaseTime?: Date) { }
}