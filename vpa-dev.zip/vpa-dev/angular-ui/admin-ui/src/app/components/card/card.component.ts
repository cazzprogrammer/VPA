import { Component, OnInit } from '@angular/core';
import { ReportService } from 'src/app/services/report.service';
import { ChartType } from 'chart.js';
import { Label } from 'ng2-charts';
import { Report } from '../csr-managementv2/models/report.model';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})

export class CardComponent implements OnInit {
  // timeframe: string;

  constructor(private reportService: ReportService) { }


  day = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12',
    '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '0'];
  week = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  month = ['Week 1', 'Week 2', 'Week 3', 'Week 4'];

  public lineChartColors: Array<any> = [
    {
      backgroundColor: 'rgba(0, 137, 132, .2)',
      borderColor: 'rgba(0, 10, 130, .7)',
      borderWidth: 2,
    },
    {
      backgroundColor: 'rgba(105, 0, 132, .2)',
      borderColor: 'rgba(200, 99, 132, .7)',
      borderWidth: 2,
    }

  ];

  // public chartColorsBOT: Array<any> = [
  //   {
  //     backgroundColor: 'rgba(0, 137, 132, .2)',
  //     borderColor: 'rgba(0, 10, 130, .7)',
  //     borderWidth: 2,
  //   }
  // ];

  public lineChartOptions: any = {
    responsive: true
  };

  linechartDatasets = [
    {
      data: [65, 59, 80, 81, 56, 55, 40], label: 'Tickets Resolved By CSR',
    },
    {
      data: [33, 234, 25, 12, 34, 12, 54, 12], label: 'Tickets Resolved By BOT',
    }
  ];

  linechartLabels = this.day;

  public doughnutChartLabels: Label[] = ['Resolved By Bot', 'Resolved By CSR'];

  public doughnutChartData = [
    [350, 450]
  ];

  public doughtnutChartOptions: any = {
    responsive: false
  };
  public doughnutChartType: ChartType = 'doughnut';

  getPreviousMonday() {
    const date = new Date();
    const day = date.getDay();
    let prevMonday;
    if (date.getDay() === 1) {
      prevMonday = new Date();
    } else {
      prevMonday = new Date().setDate(date.getDate() - day + 1);
    }

    return new Date(prevMonday);

  }

  setTimeToZero(date: Date) {
    date.setHours(0);
    date.setMinutes(0);
    date.setSeconds(0);
    date.setMilliseconds(0);
    return date;
  }


  avgTimeToResolve: string;
  avgTimeToConnect: string;

  renderGraph1() {
    // console.log("we are in renderGrap gh1") 
    const toDate = new Date();
    const fromDate = this.setTimeToZero(new Date());
    console.log(toDate);
    console.log(fromDate)
    let reports: Report[];
    let totalTimeToResolve = 0;
    let totalTimeToConnect = 0;
    this.reportService.getAllReports(fromDate.getTime(), toDate.getTime()).subscribe((reportsfromdb: Report[]) => {
      reports = reportsfromdb;
      console.log(reports)
      const reportsResolvedByBOT = new Array(24).fill(0);
      const reportsResolvedByCSR = new Array(24).fill(0);
      let countResolvedByBOT = 0;
      let countResolvedByCSR = 0;
      reports.forEach(report => {
        console.log();
        if (report.resolvedBy === 'BOT') {
          countResolvedByBOT += 1
          reportsResolvedByBOT[new Date(report.resolvedOn).getHours()] += 1;
        } else if (report.resolvedBy === 'CSR') {
          countResolvedByCSR += 1
          reportsResolvedByCSR[new Date(report.resolvedOn).getHours()] += 1;
          totalTimeToConnect += (new Date(report.interactions[1].catchTime).getTime() - new Date(report.createdOn).getTime()) / (1000 * 60);
        }
        totalTimeToResolve += (new Date(report.resolvedOn).getTime() - new Date(report.createdOn).getTime()) / (1000 * 60);
      });
      this.avgTimeToResolve = (totalTimeToResolve / (countResolvedByBOT + countResolvedByCSR)).toFixed(2);
      this.avgTimeToConnect = (totalTimeToConnect / (countResolvedByCSR)).toFixed(2);
      // reports.sort((a, b) => (a.resolvedOn < b.resolvedOn) ? 1 : -1);
      this.linechartDatasets = [
        {
          data: reportsResolvedByCSR, label: 'Tickets Resolved By CSR',
        },
        {
          data: reportsResolvedByBOT, label: 'Tickets Resolved By BOT',
        }
      ];
      this.linechartLabels = this.day;
      this.doughnutChartData = [
        [countResolvedByBOT, countResolvedByCSR]
      ]

    });
  }

  renderGraph2() {
    console.log("we are in renderGrapgh2")
    const toDate = new Date();
    const fromDate = this.setTimeToZero(this.getPreviousMonday());
    console.log(fromDate);
    console.log(toDate);
    let totalTimeToResolve = 0;
    let totalTimeToConnect = 0;
    let reports: Report[];
    this.reportService.getAllReports(fromDate.getTime(), toDate.getTime()).subscribe((reportsfromdb: Report[]) => {
      reports = reportsfromdb;
      const reportsResolvedByBOT = new Array(7).fill(0);
      const reportsResolvedByCSR = new Array(7).fill(0);
      let countResolvedByBOT = 0;
      let countResolvedByCSR = 0;
      
      reports.forEach(report => {
        if (report.resolvedBy === 'BOT') {
          countResolvedByBOT += 1;
          reportsResolvedByBOT[new Date(report.resolvedOn).getDay() - 1] += 1;
        } else if (report.resolvedBy === 'CSR') {
          countResolvedByCSR += 1;
          reportsResolvedByCSR[new Date(report.resolvedOn).getDay() - 1] += 1;
          totalTimeToConnect += (new Date(report.interactions[1].catchTime).getTime() - new Date(report.createdOn).getTime()) / (1000 * 60);
        }
        totalTimeToResolve += (new Date(report.resolvedOn).getTime() - new Date(report.createdOn).getTime()) / (1000 * 60);
     
      });
      this.avgTimeToResolve = (totalTimeToResolve / (countResolvedByBOT + countResolvedByCSR)).toFixed(2);
      this.avgTimeToConnect = (totalTimeToConnect / (countResolvedByCSR)).toFixed(2);
  

      this.linechartDatasets = [
        {
          data: reportsResolvedByCSR, label: 'Tickets Resolved By CSR',
        },
        {
          data: reportsResolvedByBOT, label: 'Tickets Resolved By BOT',
        }
      ];
      this.linechartLabels = this.week;
      this.doughnutChartData = [
        [countResolvedByBOT, countResolvedByCSR]
      ]
      this.doughnutChartLabels = ['Resolved By Bot', 'Resolved By CSR'];
    });
  }

  ngOnInit() {
    this.oneDay();

  }

  public chartClicked(e: any): void { }
  public chartHovered(e: any): void { }

  oneDay() {

  }

}
