import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommunicationService } from 'src/app/services/communication.service';
import { VerificationService } from 'src/app/services/verification.service';
import { DEV } from './models/dev.model';

@Component({
  selector: 'app-dev-management',
  templateUrl: './dev-management.component.html',
  styleUrls: ['./dev-management.component.css']
})
export class DevManagementComponent implements OnInit {

  selectedDEV = new DEV();
  disabled = true;

  constructor(private route: ActivatedRoute, private comServ: CommunicationService, private verificationService: VerificationService) {
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.selectedDEV = this.comServ.selectedDEV;
      console.log(this.selectedDEV);
      if (this.selectedDEV.employeeId !== undefined) {
        this.getEmployee();
      } else {
        this.AddNewDev();
      }
    });

  }

  onSave() {
    if (this.selectedDEV.employeeId !== undefined) {
      this.verificationService.updateEmployee(this.selectedDEV);
    } else {
      this.verificationService.addNewEmployee(this.selectedDEV);
    }
  }

  getEmployee() {
    this.disabled = true;
  }

  AddNewDev() {
    this.selectedDEV = new DEV();
    this.disabled = false;
  }
}
