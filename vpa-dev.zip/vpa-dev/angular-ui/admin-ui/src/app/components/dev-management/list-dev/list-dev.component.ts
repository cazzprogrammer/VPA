import { Component, OnInit } from '@angular/core';
import { CommunicationService } from 'src/app/services/communication.service';
import { Router } from '@angular/router';
import { DEV } from '../models/dev.model';
import { VerificationService } from 'src/app/services/verification.service';

@Component({
  selector: 'app-list-dev',
  templateUrl: './list-dev.component.html',
  styleUrls: ['./list-dev.component.css']
})
export class ListDevComponent implements OnInit {

  searchText: string;
  constructor(private comServ: CommunicationService, private router: Router, private verificationService: VerificationService) { }
  allDev;

  ngOnInit(): void {
    // this.allDev = [new DEV(123456, 'Ananaya', 'Bhattacharya'), new DEV(654321, 'Kachua', 'Chap')];
    this.verificationService.getAllDev().subscribe((devs: DEV[]) => {
      this.allDev = devs;
    });
  }

  showDEV(dev: DEV) {
    this.comServ.selectedDEV = dev;
    this.router.navigate(['/dev', dev.employeeId]);
  }

  addNewDEV() {
    this.comServ.selectedDEV = new DEV();
    this.router.navigate(['/dev']);
  }
}
