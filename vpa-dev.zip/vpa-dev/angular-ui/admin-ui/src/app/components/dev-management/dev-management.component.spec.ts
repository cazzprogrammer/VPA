import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DevManagementComponent } from './dev-management.component';

describe('DevManagementComponent', () => {
  let component: DevManagementComponent;
  let fixture: ComponentFixture<DevManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DevManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DevManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
