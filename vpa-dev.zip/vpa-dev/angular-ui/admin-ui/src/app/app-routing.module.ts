import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CardComponent } from './components/card/card.component';
import { DevManagementComponent } from './components/dev-management/dev-management.component';
import { CsrManagementv2Component } from './components/csr-managementv2/csr-managementv2.component';
import { ListCsrComponent } from './components/csr-managementv2/list-csr/list-csr.component';
import { ListDevComponent } from './components/dev-management/list-dev/list-dev.component';



const routes: Routes = [
  {
    path: '',
    component: CardComponent
  },
  {
    path: 'csr/:id',
    component: CsrManagementv2Component
  },
  {
    path: 'csr',
    component: CsrManagementv2Component
  },
  {
    path: 'list-csr',
    component: ListCsrComponent
  },
  {
    path: 'list-dev',
    component: ListDevComponent
  },
  {
    path: 'dev/:id',
    component: DevManagementComponent
  },
  {
    path: 'dev',
    component: DevManagementComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
