import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LayoutModule } from '@angular/cdk/layout';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { CardComponent } from './components/card/card.component';
import { HttpClientModule } from '@angular/common/http';
import { ReportService } from './services/report.service';
import { DevManagementComponent } from './components/dev-management/dev-management.component';
import { MaterialModule } from './material.module';
import { ChartsModule } from 'ng2-charts';
import { CsrManagementv2Component } from './components/csr-managementv2/csr-managementv2.component';
import { ListCsrComponent } from './components/csr-managementv2/list-csr/list-csr.component';
import { FilterPipe } from './components/csr-managementv2/list-csr/filter.pipe';
import { VerificationService } from './services/verification.service';
import { ListDevComponent } from './components/dev-management/list-dev/list-dev.component';

@NgModule({
  declarations: [
    AppComponent,
    CardComponent,
    DevManagementComponent,
    CsrManagementv2Component,
    ListCsrComponent,
    FilterPipe,
    ListDevComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    LayoutModule,
    HttpClientModule,
    FormsModule,
    MaterialModule,
    ChartsModule,
    ReactiveFormsModule,

  ],
  providers: [ReportService, VerificationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
