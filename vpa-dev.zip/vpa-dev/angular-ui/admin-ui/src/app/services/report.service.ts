import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Report } from '../components/csr-managementv2/models/report.model';

@Injectable({
  providedIn: 'root'
})
export class ReportService {

  constructor(private http: HttpClient) { }

  getAllReports(fromDate: number, toDate: number ): Observable<any> {
    return this.http.get(environment.reportService + 'getAllReports', {
      params: {
        fromDate: JSON.stringify(fromDate),
        toDate: JSON.stringify(toDate),
      }
    });
  }

  getReportsByCSR(fromDate: Date, toDate: Date, employeeId: Date): Observable<any> {
    return this.http.get(environment.reportService + 'getReportsByCsrId', {
      params: {
        fromDate: JSON.stringify(fromDate),
        toDate: JSON.stringify(toDate),
        Id: JSON.stringify(employeeId)
      }
    });
  }
  
  getReportsOfCSR(fromDate, toDate): Observable<any> {
    return this.http.get(environment.reportService + 'getCsrReports', {
      params: {
        fromDate: JSON.stringify(fromDate),
        toDate: JSON.stringify(toDate),
      }
    });
  }




}
