import { Injectable } from '@angular/core';
import { CSR } from '../components/csr-managementv2/models/csr.model';
import { DEV } from '../components/dev-management/models/dev.model';

@Injectable({
  providedIn: 'root'
})
export class CommunicationService {
  selectedCSR = new CSR();
  selectedDEV = new DEV();

  setSelectedCSR(selectedCSR: CSR) {
    this.selectedCSR = selectedCSR;

  }

  setSelectedDEV(selectedDEV: DEV) {
    this.selectedDEV = selectedDEV;
  }

  constructor() { }
}
