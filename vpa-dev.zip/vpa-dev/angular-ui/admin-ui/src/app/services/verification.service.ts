import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { DEV } from '../components/dev-management/models/dev.model';

@Injectable({
  providedIn: 'root'
})
export class VerificationService {
  updateEmployee(object: any) {
    return this.http.post(environment.verificationService + 'register', object).subscribe((data: any) =>
    console.log(data)
  );
  }

  constructor(private http: HttpClient) { }

  addNewEmployee(object: any) {
    return this.http.post(environment.verificationService + 'register', object).subscribe((data: any) =>
      console.log(data)
    );
  }

  getAllDev(): Observable<any> {
    return this.http.get(environment.verificationService + 'getAllDev');
  }

  getAllCsr(): Observable<any> {
    return this.http.get(environment.verificationService + 'getAllCsr');
  }

}
