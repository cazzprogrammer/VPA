export const environment = {
  production: true,
  reportService: "http://15.206.110.2:8083/reports/",
  verificationService: "http://15.206.110.2:8090/",
};
