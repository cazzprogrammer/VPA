export const environment = {
  production: true,
  botService: 'http://15.206.110.2:8080/api/v1/bot/',
  ticketService: 'http://15.206.110.2:8082/tickets/',
  commandService: 'http://15.206.110.2:8085/',
  URL_LOGIN: 'http://15.206.110.2:8090/authenticate',
};
