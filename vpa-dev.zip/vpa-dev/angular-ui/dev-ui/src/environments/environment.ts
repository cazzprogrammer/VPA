// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  // botService: "http://127.0.0.1:8080/api/v1/bot/",
  // ticketService: "http://127.0.0.1:8082/tickets/",
  // commandService: "http://172.23.239.99:8085/",
  botService: 'http://15.206.110.2:8080/api/v1/bot/',
  ticketService: 'http://15.206.110.2:8082/tickets/',
  commandService: "http://15.206.110.2:8085/command/",
  URL_LOGIN: 'http://15.206.110.2:8090/authenticate',
  // botService: 'http://172.23.239.93:8080/api/v1/bot/',
  // ticketService: 'http://172.23.239.93:8082/tickets/',
  // commandService: "http://172.23.239.93:8085/",
};


