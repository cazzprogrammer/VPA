import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators, FormControl } from '@angular/forms';
import { map, startWith } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { IntentPost } from './Models/IntentPost.model';
import { ResponsePost } from './Models/ResponsePost.model';
import { Data } from './Models/Data.model';
import { UserSays } from './Models/UserSays.model';
import { BotService } from 'src/app/services/bot.service';
import { CommunicationService } from 'src/app/services/app.communication.service';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { Router } from '@angular/router';
import { Ticket, Interactions } from 'src/app/models/model';
import { TicketService } from 'src/app/services/ticket.service';
import { SelectionModel } from '@angular/cdk/collections';
import { CommandService } from 'src/app/services/command.service';

export class FormData {
  name: string;
  data: [];
  answer: string;
  entities: [];
  task: string;
  params: [];
}

export class BotIntent {
  intentPost: IntentPost;
  responsePost: ResponsePost;

  constructor(intentPost: IntentPost, responsePost: ResponsePost) {
    this.intentPost = intentPost;
    this.responsePost = responsePost;
  }
}

export class Command {
  constructor(public command?: string, public params?: string[], public description?: string) { }
}

export class Entity {
  entityText: string;
  entityType: string;

  constructor(entityText: string, entityType: string) {
    this.entityText = entityText;
    this.entityType = entityType;
  }
}

@Component({
  selector: 'app-intentv2',
  templateUrl: './intentv2.component.html',
  styleUrls: ['./intentv2.component.css']
})
export class Intentv2Component implements OnInit {

  constructor(private fb: FormBuilder, private botService: BotService,
    private serv: CommunicationService, private router: Router,
    private ticketService: TicketService, public commandService: CommandService) {

    // console.log("Is it working");
    let commands;
    this.commandService.getAllCommands().subscribe(data => {
      console.log(data);
      commands = data;
      this.commandDataSource = new MatTableDataSource(commands);
    });
    // const commands = [
    //   new Command('bottle', ['abc', 'def', 'ghi'], 'something to bottle in'),
    //   new Command('tottle', ['abc', 'def', 'ghi'], 'something to tottle in'),
    //   new Command('rottle', ['abc', 'def', 'ghi'], 'something to rottle in'),
    //   new Command('bottle', ['abc', 'def', 'ghi'], 'something to bottle in'),
    //   new Command('tottle', ['abc', 'def', 'ghi'], 'something to tottle in'),
    //   new Command('rottle', ['abc', 'def', 'ghi'], 'something to rottle in'),]
    // this.commandDataSource = new MatTableDataSource(commands);

  }

  get dataArray() {
    return this.phrases.get('data') as FormArray;
  }

  get entitiesArray() {
    return this.phrases.get('entities') as FormArray;
  }

  commandDisplayedColumns: string[] = ['select', 'command', 'params', 'description'];
  commandDataSource: MatTableDataSource<Command>;
  selection = new SelectionModel<Command>(false, []);


  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;


  phrases: FormGroup;
  phrase: string;

  candidateEntity: string;
  entityList = [];
  entityListText = [];


  dataSource = new MatTableDataSource<any[]>();
  displayedColumns = ['entityText', 'entityType'];

  myControl = new FormControl();
  options: string[] =
    ['@sys.date-time', '@sys.date', '@sys.date-period',
      '@sys.time', '@sys.time-period', '@sys.number',
      '@sys.cardinal', '@sys.ordinal', '@sys.number-sequence', '@sys.number-integer',
      '@sys.flight-number', '@sys.unit-area', '@sys.unit-currency', '@sys.unit-length',
      '@sys.unit-speed', '@sys.unit-volume', '@sys.unit-weight', '@sys.unit-information',
      '@sys.percentage', '@sys.temperature', '@sys.duration', '@sys.age', '@sys.currency-name',
      '@sys.unit-area-name', '@sys.unit-length-name', '@sys.unit-speed-name', '@sys.unit-volume-name',
      '@sys.unit-weight-name', '@sys.unit-information-name', '@sys.address', '@sys.street-address',
      '@sys.zip-code', '@sys.geo-capital', '@sys.geo-country', '@sys.geo-country-code',
      '@sys.geo-city', '@sys.geo-state', '@sys.airport', '@sys.location', '@sys.email',
      '@sys.phone-number', '@sys.given-name', '@sys.last-name', '@sys.person',
      '@sys.music-artist', '@sys.music-genre', '@sys.color', '@sys.language',
      '@sys.any', '@sys.url'
    ];

  filteredOptions: Observable<string[]>;

  typeSelected: string;
  userSays: UserSays[] = [];
  intentId: string;
  intentDetails: BotIntent;
  intentName: string;
  trainingData: UserSays[] = [];
  queryData: string[] = [];
  intentResponse: string;
  ticketIds: string[] = [];
  recievedTickets: Ticket[] = [];
  public currentTicket: Ticket;
  messg;

  command: Command = new Command();

  ngOnInit() {

    // add data from ticket list
    this.serv.recievedFilter.subscribe((param: string) => {
      // this.addNewData(param);
      this.phrase = param;
    });

    // get intent from default page
    this.serv.receivedIntentId.subscribe((param: string) => {
      this.intentId = param;
      console.log("Intent selected: " + this.intentId);
      // this.getIntentDetails(this.intentId);

      this.commandDataSource.paginator = this.paginator;
      this.commandDataSource.sort = this.sort;
    });

    // the main form group
    this.phrases = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(2)]],
      data: this.fb.array([]),
      entities: this.fb.array([]),
      answer: []
    });

    // FOR ENTITIES
    this.filteredOptions = this.myControl.valueChanges
      .pipe(
        startWith(''),
        map(value => this._filter(value))
      );

    //FOR ADD BUTTON
    this.serv.buttonToggle(false)
  }



  // FOR ENTITIES
  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().includes(filterValue));
  }

  dataGroup(input) {
    return this.fb.group({
      text: input,
    });
  }

  addNewData(input) {
    this.phrase = '';
    return this.dataArray.push(this.dataGroup(input));
  }

  entityGroup(input) {
    return this.fb.array(input);
  }

  addNewEntities(input) {
    this.entitiesArray.push(this.entityGroup(input));
    this.entityList = [];
    this.entityListText = [];
    this.dataSource = new MatTableDataSource(this.entityList);
  }

  addNewDatawEntities() {
    console.log(this.entitiesArray.controls);
    this.addNewData(this.phrase);
    this.addNewEntities(this.entityList);

    //get ticket details from selected ticket
    if (this.serv.ticketId != null) {
      this.ticketIds.push(this.serv.ticketId);
      this.serv.ticketId = null;
    }
    console.log(this.ticketIds);

  }

  deleteData(index) {
    this.dataArray.removeAt(index);
    this.entitiesArray.removeAt(index);
  }

  createEntity() {
    this.candidateEntity = window.getSelection().toString();
    if (this.candidateEntity.length > 0) {
      // console.log(window.getSelection().toString());
    }
  }

  addEntity() {
    this.entityList.push({ entityText: this.candidateEntity, entityType: this.myControl.value });
    this.entityListText.push({ entityText: this.candidateEntity })
    this.candidateEntity = '';
    this.typeSelected = '';
    this.dataSource = new MatTableDataSource(this.entityList);

    console.log(this.entityListText);
  }

  deleteEntity(index) {
    this.dataSource.data = this.dataSource.data.filter(i => i !== index);
    this.entityList = [];
  }


  onSubmit(formData: FormData) {
    const name = formData.name;
    const entitiesArray: Entity[][] = formData.entities;
    const dataArray: Data[] = formData.data;

    for (let sample = 0; sample < dataArray.length; sample++) {
      const data: Data[] = [];
      // getting the handle on text and list of entities of each sample
      const text = dataArray[sample].text;
      const entities = entitiesArray[sample];
      if (entities.length !== 0) {

        let orderedEntities = [];
        for (let entityIndex = 0; entityIndex < entities.length; entityIndex++) {
          orderedEntities.push([text.indexOf(entities[entityIndex].entityText), entities[entityIndex]])
        }

        orderedEntities = orderedEntities.sort((a, b) => a[0] - b[0]);
        // console.log(orderedEntities);
        // entities are now in order and I have the corresponding indexes
        let entityIndex = 0
        // console.log(text);
        let buffer = ''
        for (let charAt = 0; charAt < text.length; charAt++) {
          let stopIndex = orderedEntities[entityIndex][0];
          let alias: string = orderedEntities[entityIndex][1].entityType.split(".")[1];
          let meta = orderedEntities[entityIndex][1].entityType;
          let entityText = orderedEntities[entityIndex][1].entityText;

          // console.log('charAt ' + charAt);
          if (charAt != stopIndex) {
            buffer += text[charAt];
            // console.log('buffer ' + buffer);
          } else if (charAt == stopIndex || charAt == text.length - 1) {
            if (buffer.length > 0) {
              // console.log(new Data(buffer, null, null, true))
              data.push(new Data(buffer, null, null, true))
              buffer = '';
            }
            // console.log(new Data(entityText, alias, meta, true))
            data.push(new Data(entityText, alias, meta, true));
            charAt += entityText.length - 1;
            // console.log('length orderedEn' + orderedEntities.length);
            if ((entityIndex + 1) < orderedEntities.length) {
              entityIndex++;
              // console.log('entityIndex' + entityIndex);
            }

          }

        }
        if (buffer.length > 0) {
          data.push(new Data(buffer, null, null, true));
        }
      } else {
        // console.log(new Data(text, null, null, true));
        data.push(new Data(text, null, null, true))
      }
      this.userSays.push(new UserSays(data));
      console.log(data);
    }

    const intentPost: IntentPost = new IntentPost(name, this.userSays);
    const responsePost: ResponsePost = new ResponsePost(name, formData.answer, this.command.command, this.command.params);
    const botIntent: BotIntent = new BotIntent(intentPost, responsePost);

    console.log(botIntent);
    this.botService.addIntent(botIntent);

    this.getTicketDetails(this.ticketIds);
  }

  applyFilter(filterValue: string) {
    this.commandDataSource.filter = filterValue.trim().toLowerCase();

    if (this.commandDataSource.paginator) {
      this.commandDataSource.paginator.firstPage();
    }
  }

  getTicketDetails(ticketIds: string[]) {

    ticketIds.forEach(id => {
      this.ticketService.getTicketById(id).subscribe((res: Ticket) => {
        this.currentTicket = res;
        let temp = new Interactions("DEV", "09876")
        if (this.currentTicket.interactions != null) {
          this.currentTicket.interactions.push(temp);
          this.currentTicket.lastUpdateBy = "DEV";
        }
        else {
          this.currentTicket.interactions = [temp];
        }
        console.log("current ticket:")
        console.log(this.currentTicket);
        // this.recievedTickets.push(this.currentTicket);
        this.ticketService.updateTicket(this.currentTicket).subscribe(msg => this.messg = msg);
        // console.log(this.messg)
      })
    });
    // console.log("All tickets:")
    // console.log(this.recievedTickets)

  }
  showSelectedCommand(row) {
    this.command = row;
  }
}
