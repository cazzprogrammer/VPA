import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';

@Component({
  selector: 'app-intent',
  templateUrl: './intent.component.html',
  styleUrls: ['./intent.component.css']
})
export class IntentComponent implements OnInit {

  phrases: FormGroup;

  ngOnInit() {
    this.addNewUserSays();

  }

  constructor(private fb: FormBuilder) {
    this.phrases = this.fb.group({
      // you can also set initial formgroup inside if you like
      fallbackIntent: false,
      name: [],
      priority: 500000,
      userSays: this.fb.array([])
    });
  }

  addNewUserSays() {
    const control = this.phrases.controls.userSays as FormArray;
    control.push(
      this.fb.group({
        count: 0,
        // nested form array, you could also add a form group initially
        data: this.fb.array([])
      })
    );
  }

  deleteUserSays(index) {
    const control = this.phrases.controls.userSays as FormArray;
    control.removeAt(index);
  }

  addNewData(control) {
    control.push(
      this.fb.group({
        text: ['']
      })
    );

  }

  deleteData(control, index) {
    control.removeAt(index);
  }

  onSubmit(object) {
    console.log(object);
  }
}

  // setCompanies() {
  //   let control = <FormArray>this.myForm.controls.companies;
  //   this.data.companies.forEach(x => {
  //     control.push(this.fb.group({
  //       company: x.company,
  //       projects: this.setProjects(x)
  //     }))
  //   })
  // }

  // setProjects(x) {
  //   let arr = new FormArray([])
  //   x.projects.forEach(y => {
  //     arr.push(this.fb.group({
  //       projectName: y.projectName
  //     }))
  //   })
  //   return arr;
  // }

