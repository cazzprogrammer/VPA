import { UserSays } from './UserSays.model';



export class IntentPost {
    name: string;
    auto: boolean;
    userSays: UserSays[];

    constructor(name: string, userSays: UserSays[]) {
        this.name = name;
        this.auto = true;
        this.userSays = userSays;
    }


}