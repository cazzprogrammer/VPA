import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-center-container-component',
  templateUrl: './center-container-component.component.html',
  styleUrls: ['./center-container-component.component.css']
})
export class CenterContainerComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
