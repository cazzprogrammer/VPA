import { Data } from './Data.model';


export class UserSays {
    data: Data[];

    constructor(data: Data[]) {
        this.data = data;

    }
}