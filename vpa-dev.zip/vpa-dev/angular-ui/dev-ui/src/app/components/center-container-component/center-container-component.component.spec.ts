import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CenterContainerComponentComponent } from './center-container-component.component';

describe('CenterContainerComponentComponent', () => {
  let component: CenterContainerComponentComponent;
  let fixture: ComponentFixture<CenterContainerComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CenterContainerComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CenterContainerComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
