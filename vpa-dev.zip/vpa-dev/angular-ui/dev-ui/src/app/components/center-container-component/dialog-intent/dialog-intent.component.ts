import { Component, OnInit, Inject, HostListener } from '@angular/core';
import { UserSays } from '../intentv2/Models/UserSays.model';
import { BotService } from 'src/app/services/bot.service';
import { CommunicationService } from 'src/app/services/app.communication.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Data } from '../intentv2/Models/Data.model';
import { BotIntent } from '../intentv2/intentv2.component';

@Component({

  selector: 'app-dialog-intent',
  templateUrl: './dialog-intent.component.html',
  styleUrls: ['./dialog-intent.component.css']
})
export class DialogIntentComponent implements OnInit {

  typeSelected: string;
  userSays: UserSays[] = [];
  intentDetails: BotIntent;
  intentName: string;
  trainingData: UserSays[] = [];
  queryData: string[] = [];
  intentResponse: string;
  intentId: string;

  constructor(private botService: BotService, private serv: CommunicationService,
    public dialogRef: MatDialogRef<DialogIntentComponent>,
    @Inject(MAT_DIALOG_DATA) private data: any) {
    // dialogRef.disableClose = true;
    this.intentId = data.id;
    // console.log(this.intentId);
    this.getIntentDetails(this.intentId);
  }

  // @HostListener('window:keyup.esc') onKeyUp() {
  //   this.dialogRef.close();
  // }

  ngOnInit() {

  }

  getIntentDetails(intentId) {
    this.intentName = '';
    this.trainingData = [];
    this.queryData = [];


    this.botService.getIntentValues(intentId).subscribe((res: BotIntent) => {
      this.intentDetails = res;
      console.log(this.intentDetails)

      //INTENT NAME
      this.intentName = this.intentDetails.intentPost.name;
      // console.log("Intent name: " + this.intentName);

      //TRAINING PHRASES
      this.trainingData = this.intentDetails.intentPost.userSays;
      this.trainingData.forEach((element: any) => {

        console.log(element)
        let text = element.data.reduce((acc = "", val, i) => {
          // console.log(acc, val, i)
          acc.text = acc.text + val.text
          return acc
        })

        this.queryData.push(text)

        // console.log(element)
      });

      console.log("query data: ")
      console.log(this.queryData);

      // RESPONSE (Name, Answer, Task, Parameters)
      console.log(this.intentDetails.responsePost)
      if (this.intentDetails.responsePost.task !== "") {
        this.intentResponse = this.intentDetails.responsePost.task;
      }
      else {
        this.intentResponse = this.intentDetails.responsePost.answer;
      }
      // console.log(this.intentResponse)
    });
  }
}
