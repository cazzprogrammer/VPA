export class Data {
    text: string;
    alias: string;
    meta: string;
    userDefined: boolean;

    constructor(text: string, alias: string, meta: string, userDefined: boolean) {
        this.text = text;
        this.alias = alias;
        this.meta = meta;
        this.userDefined = userDefined;
    }

}