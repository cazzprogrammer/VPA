import { Component, OnInit } from '@angular/core';
import { Ticket } from '../../../models/model';
import { Router } from '@angular/router';
import { BotService } from 'src/app/services/bot.service';
import { MatDialog } from '@angular/material/dialog';
import { CommunicationService } from 'src/app/services/app.communication.service';
import { NgZone } from '@angular/core';
import { DialogIntentComponent } from '../dialog-intent/dialog-intent.component';

@Component({
  selector: 'app-view-default',
  templateUrl: './view-default.component.html',
  styleUrls: ['./view-default.component.css']
})

export class ViewDefaultComponent implements OnInit {

  constructor(private zone: NgZone, private botService: BotService, private router: Router, public dialog: MatDialog, private serv: CommunicationService) { }

  result;
  panelOpenState = false;
  searchText: string;
  intentId: string;

  ngOnInit() {

    this.botService.refreshNeeded$.subscribe(() => {
      this.getAllIntents();
    });

    this.getAllIntents();

    this.serv.buttonToggle(true);

  }

  getAllIntents() {
    this.botService.getAllIntentDF().subscribe((res: Ticket) => {
      this.result = res;
    });
  }


  deleteIntent(intentId) {
    this.botService.deleteIntentById(intentId).subscribe(() => {
      console.log('intent deleted');
    }
    );

    // this.router.navigateByUrl(`/`).then(() => {
    //   this.router.navigateByUrl('/createIntent', { skipLocationChange: true }).then(() => {
    //     this.router.navigateByUrl(`/`);
    //   });
    // });
  }

  displayIntent(intentId) {
    this.router.navigateByUrl('/createIntent');
    this.serv.passIntentId(intentId);
  }

  openEditDialog(intentId): void {
    // this.serv.passIntentId(intentId);
    this.zone.run(() => {
      this.dialog.open(DialogIntentComponent, {
        data: { id: intentId }
      });
    });
  }

}

