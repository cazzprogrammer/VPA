export class ResponsePost {
    name: string;
    answer: string;
    task: string;
    params: string[];

    constructor(name: string, answer?: string, task?: string, params?: string[]) {
        this.name = name;
        this.answer = answer;
        this.task = task;
        this.params = params;

    }
}