import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators, FormControl } from '@angular/forms';
import { CommandService } from 'src/app/services/command.service';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})


export class TaskComponent implements OnInit {

  constructor(private fb: FormBuilder, private commandService: CommandService) { }
  taskForm: FormGroup;
  parameter: string;

  ngOnInit() {


    this.taskForm = this.fb.group({
      command: ['', Validators.required],
      params: this.fb.array([]),
      description: [],
    });
  }

  get paramsArray() {
    return this.taskForm.get('params') as FormArray;
  }

  dataGroup(input) {
    return this.fb.group({
      text: input,
    });
  }

  addNewParam() {
    this.paramsArray.push(this.dataGroup(this.parameter));
    this.parameter = '';
  }

  deleteParam(i){
    this.paramsArray.removeAt(i);
  }


  onSubmit(formData) {
    let command = formData.command
    let params = [];
    formData.params.forEach(parameter => {
      console.log(parameter.text);
      params.push(parameter.text);
    });
    console.log(params);
    let description = formData.description;

    const task: Command = new Command(command, params, description);
    console.log(task);

    this.commandService.addNewCommand(task);




  }

}

export class Command {
  constructor(public command?: string, public params?: string[], public description?: string) { }
}
