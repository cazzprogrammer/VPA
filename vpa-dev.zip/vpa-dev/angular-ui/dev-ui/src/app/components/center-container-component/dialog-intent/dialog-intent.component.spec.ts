import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogIntentComponent } from './dialog-intent.component';

describe('DialogIntentComponent', () => {
  let component: DialogIntentComponent;
  let fixture: ComponentFixture<DialogIntentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogIntentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogIntentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
