import { Component, OnInit, ViewChild } from '@angular/core';
import { TicketService } from '../../../services/ticket.service';
import { Router } from '@angular/router';
import { CommunicationService } from 'src/app/services/app.communication.service';
import { Ticket, Interactions } from 'src/app/models/model';
import { element } from 'protractor';


export class result {
  query: string;
  constructor(query: string) {
    this.query = query;
  }
}


@Component({
  selector: 'app-ticket-component',
  templateUrl: './ticket-component.component.html',
  styleUrls: ['./ticket-component.component.css']
})
export class TicketComponentComponent implements OnInit {
  result: Ticket[] = [];
  // result;
  interactedWith;
  buttonDisabled: boolean;
  panelOpenState: boolean;

  constructor(private ticketService: TicketService, private router: Router, private serv: CommunicationService) {
  }
  ngOnInit() {
    this.getTickets();
    this.serv.createEventPageActive.subscribe((data: boolean) => {
      this.buttonDisabled = data;
    })
  }

  getTickets()  {
    this.ticketService.getAllTickets().subscribe((res: Ticket[]) => {
      this.result = res.reverse();
    });
  } 

  // ticketDetails(id) {
  // console.log(id, "CLicked ")
  // this.router.navigateByUrl(`/query/${id}`).then(() => {
  //   this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
  //     this.router.navigateByUrl(`/query/${id}`);
  //   });
  // });
  // }

  fireEvent(query, id) {
    console.log(query);
    console.log(id);
    this.serv.raiseEvent(query);
    this.serv.passTicketId(id);
  }
}

