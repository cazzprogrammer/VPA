import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-left-component',
  templateUrl: './left-component.component.html',
  styleUrls: ['./left-component.component.css']
})
export class LeftComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
