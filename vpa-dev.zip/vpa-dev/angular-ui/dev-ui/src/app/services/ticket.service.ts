import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable, Subject } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Ticket } from '../models/model';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class TicketService {

  constructor(private http: HttpClient) { }

  private _refreshNeeded$ = new Subject<void>();

  get refreshNeeded$() {
    return this._refreshNeeded$;
  }
  
  getAllTickets(): Observable<Ticket[]> {
    return this.http.get<Ticket[]>(environment.ticketService + 'review');
  }
  getTicketById(id): Observable<Ticket> {
    return this.http.get<Ticket>(environment.ticketService + 'id/' + id);
  }
  updateTicket(answer: Ticket): Observable<Ticket> {
    return this.http.put<Ticket>(environment.ticketService + 'update', answer).pipe(
      tap(() => {
        this.refreshNeeded$.next();
      })
    );
  }
}
