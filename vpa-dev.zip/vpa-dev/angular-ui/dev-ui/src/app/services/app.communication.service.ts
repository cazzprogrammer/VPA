import { EventEmitter } from '@angular/core';
import { Subject } from 'rxjs';

export class CommunicationService {
    selectedPhrase: string;
    toggle: boolean;
    intentId: string;
    ticketId: string;

    recievedFilter: EventEmitter<string>
    createEventPageActive: EventEmitter<boolean>
    receivedIntentId: EventEmitter<string>
    receivedTicket: EventEmitter<string>

    constructor() {
        this.recievedFilter = new EventEmitter<string>();
        this.createEventPageActive = new EventEmitter<boolean>();
        this.receivedIntentId = new EventEmitter<string>();
        this.receivedTicket = new EventEmitter<string>();
    };

    raiseEvent(selectedPhrase: string): void {
        this.selectedPhrase = selectedPhrase;
        this.recievedFilter.emit(this.selectedPhrase);
    }

    passIntentId(intentId: string): void {
        this.intentId = intentId;
        this.receivedIntentId.emit(this.intentId);
    }

    buttonToggle(buttonToggle:boolean): void {
        this.toggle = buttonToggle;
        this.createEventPageActive.emit(this.toggle);
    }

    passTicketId(ticketId: string): void{
        this.ticketId = ticketId;
        this.receivedTicket.emit(this.ticketId);
    }

}