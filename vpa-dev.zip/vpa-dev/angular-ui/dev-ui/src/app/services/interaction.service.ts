import { Injectable,EventEmitter } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class InteractionService {

  username: string;
  userevent: EventEmitter<string>

  constructor() { 
    this.userevent= new EventEmitter();
  }

  raiseEvent(username :string): void {
    this.username = username;
    console.log(this.username)
    this.userevent.emit(this.username);

  }
}
