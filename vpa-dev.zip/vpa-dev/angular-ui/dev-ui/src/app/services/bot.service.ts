import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { environment } from 'src/environments/environment';
import { BotIntent } from '../components/center-container-component/intentv2/intentv2.component';
import { tap } from 'rxjs/operators';
import { timeout } from 'q';

@Injectable({
  providedIn: 'root'
})
export class BotService {

  private _refreshNeeded$ = new Subject<void>();

  get refreshNeeded$() {
    return this._refreshNeeded$;
  }
  
  constructor(private http: HttpClient) { }

  getAllIntentDF(): Observable<any> {
    return this.http.get(environment.botService + 'dialogflow/getIntents');
    // return this.http.get('http://172.23.239.120:8079/api/v1/bot/dialogflow/getIntents');
  }

  deleteIntentById(id): Observable<void> {
    return this.http.delete<void>(environment.botService + 'deleteIntent/' + id).pipe(
      tap(() => {
        this.refreshNeeded$.next();
      })
    );
  }

  addIntent(botIntent: BotIntent): any {
    console.log('posting to server');
    this.http.post(environment.botService + 'addIntent', botIntent, {responseType: 'text'}).pipe(
      tap(() => {
        this.refreshNeeded$.next()
      })
    ).subscribe(data => {
      console.log(data)
    });
  }

  getIntentValues(id): Observable<any> {
    return this.http.get(environment.botService + 'getIntent/' + id).pipe(
      tap(() => {
        this.refreshNeeded$.next();
      })
    );
  }

  // return this.http.post(environment.botService + 'addIntent', botIntent).pipe(
  //   tap(() => {
  //     this._refreshNeeded$.next();
  //   })
  // ).subscribe( {

  // });
}
