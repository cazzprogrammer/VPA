import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Command } from 'selenium-webdriver';

@Injectable({
  providedIn: 'root'
})
export class CommandService {
  constructor(private http: HttpClient) {
  }

  getAllCommands() {
    return this.http.get(environment.commandService + 'getall');
  }

  addNewCommand(task): any{
    return this.http.post(environment.commandService+ 'add', task).subscribe();
  }
}
