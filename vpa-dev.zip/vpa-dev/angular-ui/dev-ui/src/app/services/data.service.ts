import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private subject = new Subject<any>();

  sendMessage(message: boolean) {
      this.subject.next(message);
  }
  getMessage(): Observable<any> {
      return this.subject.asObservable();
  }
}
