
import * as moment from 'moment';

export class Ticket {

    id: string;
    query: string;
    intent: string;
    raisedBy: string;
    createdOn: string;
    interactions: Interactions[];
    type: string;
    status: string;
    lastUpdateBy: string;
    lastUpdateOn: string;
    resolvedBy: string;
    resolvedOn: string;
}

export class Interactions {
    with: string;
    username: string;
    summary: string;
    timeStamp;



    constructor (interactedWith: string, username: string){
        this.with = interactedWith;
        this.username = username;
        let randNum=Math.floor(Math.random() * .999);
        this.timeStamp = moment().format().substring(0,19) +".000";
        console.log(this.timeStamp);
    }
}