import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Intentv2Component } from './components/center-container-component/intentv2/intentv2.component';
import { ViewDefaultComponent } from './components/center-container-component/view-default/view-default.component';
import { TaskComponent } from './components/center-container-component/task/task.component';
import { AuthguardService } from './guards/authguard.service';
import { SigninComponent } from './components/signin/signin.component';
import { MainContainerComponent } from './components/main-container/main-container.component';


const routes: Routes = [
  {
    path: '',
    component: MainContainerComponent,
    canActivate: [AuthguardService],
    children: [
      {
        path: 'createIntent',
        component: Intentv2Component,
        // canActivate: [AuthguardService]
      },
      {
        path: 'createTask',
        component: TaskComponent,
        // canActivate: [AuthguardService]
      },
      {
        path: '',
        component: ViewDefaultComponent
      }
    ]
  },
  {
    path: 'login',
    component: SigninComponent,
  },
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
