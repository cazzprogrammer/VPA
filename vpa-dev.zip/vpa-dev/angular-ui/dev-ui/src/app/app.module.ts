import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { FilterPipe } from './components/center-container-component/view-default/filter.pipe';


// Material Imports
import { MatSliderModule } from '@angular/material/slider';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatFormFieldModule } from '@angular/material/form-field';
import { A11yModule } from '@angular/cdk/a11y';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { PortalModule } from '@angular/cdk/portal';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTableModule } from '@angular/cdk/table';
import { CdkTreeModule } from '@angular/cdk/tree';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatBadgeModule } from '@angular/material/badge';
import { MatBottomSheetModule } from '@angular/material/bottom-sheet';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatStepperModule } from '@angular/material/stepper';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule, MatTableModule, MatPaginatorModule } from '@angular/material';



// Component Imports
import { AppComponent } from './app.component';
import { LeftComponentComponent } from './components/left-component/left-component.component';
import { TicketComponentComponent } from './components/left-component/ticket-component/ticket-component.component';
import { ViewDefaultComponent } from './components/center-container-component/view-default/view-default.component';


// Service Imports
import { TicketService } from './services/ticket.service';
import { IntentComponent } from './components/center-container-component/intent/intent.component';
import { Intentv2Component } from './components/center-container-component/intentv2/intentv2.component';
import { BotService } from './services/bot.service';
import { CommunicationService } from './services/app.communication.service';
import { DialogIntentComponent } from './components/center-container-component/dialog-intent/dialog-intent.component';
import { CenterContainerComponentComponent } from './components/center-container-component/center-container-component.component';
import { TaskComponent } from './components/center-container-component/task/task.component';
import { JwtModuleOptions, JwtModule, JwtHelperService } from '@auth0/angular-jwt';
import { AuthguardService } from './guards/authguard.service';
import { AuthService } from './guards/auth.service';
import { SigninComponent } from './components/signin/signin.component';
import { MainContainerComponent } from './components/main-container/main-container.component';


const JWT_Module_Options: JwtModuleOptions = {
  config: { 
    tokenGetter: () => {
      return localStorage.getItem('token');
    }
  }
}


@NgModule({
  declarations: [
    AppComponent,
    CenterContainerComponentComponent,
    LeftComponentComponent,
    TicketComponentComponent,
    ViewDefaultComponent,
    IntentComponent,
    Intentv2Component,
    FilterPipe,
    DialogIntentComponent,
    TaskComponent,
    SigninComponent,
    MainContainerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatSliderModule,
    MatToolbarModule,
    MatSidenavModule,
    HttpClientModule,
    MatCardModule,
    MatButtonModule,
    MatExpansionModule,
    MatFormFieldModule,
    FormsModule,
    MatListModule,
    ReactiveFormsModule,
    MatInputModule,
    MatSelectModule,
    MatAutocompleteModule,
    MatTabsModule,
    MatGridListModule,
    MatIconModule,
    MatDialogModule,
    MatTableModule,
    MatChipsModule,
    MatPaginatorModule,
    MatCheckboxModule,
    JwtModule.forRoot(JWT_Module_Options),
  ],
  exports: [
  ],
  providers: [TicketService, BotService, CommunicationService, AuthguardService, AuthService,JwtHelperService],
  bootstrap: [AppComponent],
  entryComponents: [DialogIntentComponent],
})
export class AppModule { }
