package io.stackroute.verification.dao;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import io.stackroute.verification.model.DAOUser;

import java.util.List;

@Repository
public interface UserDao extends MongoRepository<DAOUser, Integer> {
	
	DAOUser findByUsername(String username);

	@Query("{ role: CSR }")
	List<DAOUser> getAllCsr();

	@Query("{role: DEV }")
	List<DAOUser> getAllDev();
}