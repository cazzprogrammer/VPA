package io.stackroute.verification.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.validator.constraints.ConstraintComposition;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.UUID;


@Document
public class DAOUser {

//	private UUID UUID;
	@Id
    private UUID employeeId;
    private String username;
    private String password;
    private String firstName;
    private String lastName;
    private Date birthDate;
    private Gender gender;
    private Role role;
    private String emailId;
    private String address;

	enum Role {
		CSR, DEV
	}

	enum Gender {
		male, female
	}


	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

	public String getEmailId() { return emailId; }

	public void setEmailId(String emailId) { this.emailId = emailId; }

	public String getAddress() { return address; }

	public void setAddress(String address) { this.address = address; }

	public UUID getEmployeeId() { return employeeId; }

	public void setEmployeeId(UUID employeeId) { this.employeeId = employeeId; }

	public String getFirstName() { return firstName; }

	public void setFirstName(String firstName) { this.firstName = firstName; }

	public String getLastName() { return lastName; }

	public void setLastName(String lastName) { this.lastName = lastName; }

	public Gender getGender() { return gender; }

	public void setGender(Gender gender) { this.gender = gender; }

	public Role getRole() { return role; }

	public void setRole(Role role) { this.role = role; }

	@Override
	public String toString() {
		return "DAOUser{" +
				"employeeId='" + employeeId + '\'' +
				", username='" + username + '\'' +
				", password='" + password + '\'' +
				", firstName='" + firstName + '\'' +
				", lastName='" + lastName + '\'' +
				", birthDate=" + //birthDate +
				", gender=" + gender +
				", role=" + role +
				'}';
	}
}