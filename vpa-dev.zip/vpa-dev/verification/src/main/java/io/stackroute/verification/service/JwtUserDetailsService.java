package io.stackroute.verification.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.fasterxml.uuid.Generators;


import io.stackroute.verification.dao.UserDao;
import io.stackroute.verification.model.DAOUser;

@Service
public class JwtUserDetailsService implements UserDetailsService {
	
	@Autowired
	private UserDao userDao;

	@Autowired
	private PasswordEncoder bcryptEncoder;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		DAOUser user = userDao.findByUsername(username);
		if (user == null) {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
				new ArrayList<>());
	}
	
	public Boolean save(DAOUser user) {
		if(userDao.findByUsername(user.getUsername())==null)
		{
			user.setEmployeeId(Generators.timeBasedGenerator().generate());
			System.out.print(user.getEmployeeId());
//			report.setReportID(Generators.timeBasedGenerator().generate());

			user.setPassword(bcryptEncoder.encode(user.getPassword()));
			userDao.save(user);
			return true;
		}
		return false;
	}

	public List<DAOUser> getAllCsr() {
		return userDao.getAllCsr();
	}

	public List<DAOUser> getAllDev(){
		return userDao.getAllDev();
	}
}
